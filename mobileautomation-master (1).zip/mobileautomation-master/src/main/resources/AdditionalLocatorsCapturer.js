var parent_level = 0;
var child_level = 0;
var preceding_sibling_level = 0;
var following_sibling_level = 0;
var max_parent_level = 5;
var max_preceding_sibling_level = 5;
var max_following_sibling_level = 5;
var max_child_level = 2;
var final_xpaths = [];
var final_xpaths_validated = [];

function generateXpaths(element) {
	var attrs = element.attributes;
	var element_tagName = element.tagName;
	var element_index_in_parent = Array.from(element.parentNode.children).indexOf(element);

	generateElementXpaths(element);

	for (var i = 0; i < final_xpaths.length; i++) {
		try {
			var xpath = "//" + final_xpaths[i];

			var no_of_elements = checkXpathCount(xpath);
			if (no_of_elements === 1) {
				final_xpaths_validated.push(xpath);
			} else {
				getElementIndexOnPage(xpath, element);
			}
		} catch (err) { }
	}
	console.log(final_xpaths_validated);
	return final_xpaths_validated;
}

function getElementIndexOnPage(xpath, actual_element) {
	var no_of_elements = checkXpathCount(xpath);

	for (var i = 0; i < no_of_elements; i++) {
		try {
			xpath = "(" + xpath + ")[" + (i + 1) + "]";
			if (actual_element === document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue && checkXpathCount(xpath) === 1) {
				final_xpaths_validated.push(xpath);
			}
		} catch (err) { }
	}
}

function generateElementXpaths(element, relation = "", initial_xpaths = []) {
	var final_xpaths1 = [];
	var relations = relation.split(",");
	if (relations.length === 2) {
		child_level++;
		var child = element.children[parseInt(relations[1]) - 1];
		var child_xpaths = generateXpathsByAttributes(child, child.attributes, generateOnlyTextXpath = true);
		if (child_xpaths.length === 0) {
			child_xpaths.push(child.tagName.toLowerCase() + "[" + checkTagCountInAParent(child) + "]");
		}

		for (var i = 0; i < initial_xpaths.length; i++) {
			var each_initial_xpath = initial_xpaths[i];
			for (var j = 0; j < child_xpaths.length; j++) {
				var each_child_xpath = child_xpaths[j];
				var xpath = each_child_xpath + "/parent::" + each_initial_xpath;
				final_xpaths1.push(xpath);
			}
		}

		if (child_level < max_child_level) {
			var children = child.children;
			for (var k = 0; k < children.length; k++) {
				generateElementXpaths(child, relation = "0," + (k + 1), final_xpaths1);
			}
		}

		var element_index_in_parent1 = Array.from(child.parentNode.children).indexOf(child);
		for (var l = element_index_in_parent1 + 1; l < child.parentNode.children.length; l++) {
			generateElementXpaths(child, relation = (l - element_index_in_parent1) + "", final_xpaths1);
		}
		for (var m = element_index_in_parent - 1; m >= 0; m--) {
			generateElementXpaths(child, relation = (m - element_index_in_parent1) + "", final_xpaths1);
		}
	} else if (relations.length === 1) {
		var current_relation = parseInt(relations[0]);

		if (current_relation === 0) {
			parent_level++;
			var parent = element.parentNode;
			var parent_xpaths = generateXpathsByAttributes(parent, parent.attributes, generateOnlyTextXpath = true);
			if (parent_xpaths.length === 0) {
				parent_xpaths.push(parent.tagName.toLowerCase() + "[" + checkTagCountInAParent(parent) + "]");
			}
			for (var i = 0; i < initial_xpaths.length; i++) {
				var each_initial_xpath = initial_xpaths[i];
				for (var j = 0; j < parent_xpaths.length; j++) {
					var each_parent_xpath = parent_xpaths[j];
					var xpath = each_parent_xpath + "/" + each_initial_xpath;
					final_xpaths1.push(xpath);
				}
			}

			if (parent.parentNode.children.length > 1) {
				var element_index_in_parent1 = Array.from(parent.parentNode.children).indexOf(parent);
				for (var i = element_index_in_parent1 + 1; i < parent.parentNode.children.length; i++) {
					generateElementXpaths(parent, relation = (i - element_index_in_parent1) + "", final_xpaths1);
				}
				for (var i = element_index_in_parent - 1; i >= 0; i--) {
					generateElementXpaths(parent, relation = (i - element_index_in_parent1) + "", final_xpaths1);
				}
			}

			if (parent_level < max_parent_level) {
				var parent = element.parentNode;
				generateElementXpaths(parent, relation = "0", final_xpaths1);
			}
		} else if (current_relation > 0) {
			var element_index_in_parent = Array.from(element.parentNode.children).indexOf(element);
			var following = element.parentNode.children[element_index_in_parent + current_relation];
			var following_xpaths = generateXpathsByAttributes(following, following.attributes, generateOnlyTextXpath = true);
			if (following_xpaths.length === 0) {
				following_xpaths.push(following.tagName.toLowerCase() + "[" + checkTagCountInAParent(following) + "]");
			}
			for (var i = 0; i < initial_xpaths.length; i++) {
				var each_initial_xpath = initial_xpaths[i];
				for (var j = 0; j < following_xpaths.length; j++) {
					var each_following_xpath = following_xpaths[j];
					var xpath = each_following_xpath + "/preceding-sibling::" + each_initial_xpath;
					final_xpaths1.push(xpath);
				}
			}

			var children = following.children;
			for (var i = 0; i < children.length; i++) {
				generateElementXpaths(following, relation = "0," + (i + 1), final_xpaths1);
			}
		} else if (current_relation < 0) {
			var element_index_in_parent = Array.from(element.parentNode.children).indexOf(element);
			var preceding = element.parentNode.children[element_index_in_parent + current_relation];
			var preceding_xpaths = generateXpathsByAttributes(preceding, preceding.attributes, generateOnlyTextXpath = true);
			if (preceding_xpaths.length === 0) {
				preceding_xpaths.push(preceding.tagName.toLowerCase() + "[" + checkTagCountInAParent(preceding) + "]");
			}
			for (var i = 0; i < initial_xpaths.length; i++) {
				var each_initial_xpath = initial_xpaths[i];
				for (var j = 0; j < preceding_xpaths.length; j++) {
					var each_preceding_xpath = preceding_xpaths[j];
					var xpath = each_preceding_xpath + "/following-sibling::" + each_initial_xpath;
					final_xpaths1.push(xpath);
				}
			}

			var children = preceding.children;
			for (var i = 0; i < children.length; i++) {
				generateElementXpaths(preceding, relation = "0," + (i + 1), final_xpaths1);
			}
		} else {

			var element_xpaths = generateXpathsByAttributes(element, element.attributes);
			final_xpaths1 = final_xpaths1.concat(element_xpaths);

			var children = element.children;
			for (var i = 0; i < children.length; i++) {
				generateElementXpaths(element, relation = "0," + (i + 1), final_xpaths1);
			}

			var element_index_in_parent = Array.from(element.parentNode.children).indexOf(element);

			if (element.parentNode.children.length > 1) {
				for (var i = element_index_in_parent + 1; i < element.parentNode.children.length; i++) {
					preceding_sibling_level++;
					generateElementXpaths(element, relation = (i - element_index_in_parent) + "", final_xpaths1);
					if (preceding_sibling_level > max_preceding_sibling_level) {
						break;
					}
				}
				element_index_in_parent = Array.from(element.parentNode.children).indexOf(element);
				following_sibling_level++;
				for (var i = element_index_in_parent - 1; i >= 0; i--) {
					generateElementXpaths(element, relation = (i - element_index_in_parent) + "", final_xpaths1);
					if (following_sibling_level > max_following_sibling_level) {
						break;
					}
				}
			}
			generateElementXpaths(element, relation = "0", final_xpaths1);
		}
	}
	final_xpaths = final_xpaths.concat(final_xpaths1);
}

function generateXpathsByAttributes(element, attrs, generateOnlyTextXpath = false) {
	var revisit_previous_attribute = false;
	var xpaths_generated = [];
	var xpath = "";
	try {
		if (element.textContent != null && element.textContent != "" && element.children.length === 0) {
			xpath = element.tagName.toLowerCase() + "[text()='" + element.textContent + "']";
			xpaths_generated.push(xpath);
			xpath = "";
		}
		if (!generateOnlyTextXpath) {
			for (var i = 0; i < attrs.length; i++) {
				xpath = "";
				var included_attributes = ["id", "title", "aria-label", "class", "name", "alt"];

				var keyValue = attrs[i];
				if (included_attributes.indexOf(keyValue.nodeName) === -1) {
					continue;
				}
				xpath = xpath + element.tagName.toLowerCase() + "[@" + keyValue.nodeName + "='" + keyValue.nodeValue + "']";
				xpaths_generated.push(xpath);
			}
		}
	} catch (err) {
		console.log(err);
	}
	return xpaths_generated;
}

function checkTagCountInAParent(element) {
	var parent_element = element.parentNode;
	var children = parent_element.children;
	var count = 0;
	for (var i = 0; i < children.length; i++) {
		var each_child = children[i];
		if (each_child.tagName === element.tagName && each_child != element) {
			count++;
		} else if (each_child.tagName === element.tagName && each_child === element) {
			count++;
			break;
		}
	}
	return count;
}

function checkXpathCount(xpath) {
	var iterator = document.evaluate(xpath, document, null, XPathResult.UNORDERED_NODE_ITERATOR_TYPE, null);
	var no_of_elements = 0;
	try {
		var thisNode = iterator.iterateNext();
		while (thisNode) {
			no_of_elements++;
			thisNode = iterator.iterateNext();
		}
	} catch (e) {
		console.log(e);
	}
	return no_of_elements;
}

var final_xpaths_generated = generateXpaths(arguments[0]);
console.log(final_xpaths_generated);
return final_xpaths_generated;