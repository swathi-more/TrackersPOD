function checkXpathCount(xpath) {
    var iterator = document.evaluate(xpath, document, null, XPathResult.UNORDERED_NODE_ITERATOR_TYPE, null);
    var no_of_elements = 0;
    try {
        var thisNode = iterator.iterateNext();
        while (thisNode) {
            no_of_elements++;
            thisNode = iterator.iterateNext();
        }
    } catch (e) {
        console.log(e);
    }
    return no_of_elements;
}

var validated_xpaths = [];
var options = arguments[0];
for (var i = 0; i < options.length; i++) {
    var xpath = options[i];
    if (xpath.startsWith("xpath=") || xpath.startsWith("//")) {
        if (xpath.startsWith("xpath=")) {
            xpath = xpath.substring("xpath=".length);
        }
        var count = checkXpathCount(xpath);
        if (count != 1) {
            options.splice(i, 1);
            i--;
        } else {
            validated_xpaths.push(xpath);
        }
    } else {
        validated_xpaths.push(xpath);
    }
}
return validated_xpaths;