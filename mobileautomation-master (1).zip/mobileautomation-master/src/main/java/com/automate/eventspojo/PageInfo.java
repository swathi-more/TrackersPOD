package com.automate.eventspojo;


import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class PageInfo{
  public String path;
  public String title;
}
