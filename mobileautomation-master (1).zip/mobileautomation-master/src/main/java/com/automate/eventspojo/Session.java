package com.automate.eventspojo;


import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class Session{
  public String atgId;
  public String biId;
  public String biPoints;
  public String bi_points;
  public String biStatus;
  public String deviceId;
  public String emailId;
  public String flash_member_status;
  public String platform;
  public String profileId;
  public String sessionId;
  public String signin_state;
  public String timestamp;
  public String sotTrackingId;
}
