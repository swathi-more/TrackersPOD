package com.automate.eventspojo;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class Event {
  public String eventId;
  public String eventTime;
  public PageInfo pageInfo;
  public Session session;
  public SysInfo sysInfo;
  public SotVars sotVars;
}
