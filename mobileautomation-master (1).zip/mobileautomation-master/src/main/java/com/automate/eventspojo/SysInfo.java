package com.automate.eventspojo;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class SysInfo{
  public String app_id;
  public String device_name;
  public String operating_system;
  public String userAgent;
  public String userLanguage;
}
