package com.automate.driver.manager;

import net.lightbody.bmp.BrowserMobProxyServer;

public class BrowserMobProxyManager {
	
	private static BrowserMobProxyServer proxy;
	
	public static BrowserMobProxyServer getBMP()
	{
    if(proxy==null)
    {
      proxy = new BrowserMobProxyServer();
      proxy.setTrustAllServers(true);

    }

		return proxy;
	}

}
