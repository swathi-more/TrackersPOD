package com.automate.driver.manager;

public class DeviceManager {

  private static ThreadLocal<String> deviceName = new ThreadLocal<>();

  public static String getDeviceName() {
    return deviceName.get();
  }

  public static void setDeviceName(String device) {
    deviceName.set(device);
  }

  public static void unloadDeviceName() {
    deviceName.remove();
  }
}
