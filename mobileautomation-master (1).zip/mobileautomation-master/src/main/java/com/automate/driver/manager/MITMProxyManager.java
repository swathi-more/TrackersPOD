package com.automate.driver.manager;

import io.appium.mitmproxy.InterceptedMessage;
import io.appium.mitmproxy.MitmproxyJava;
import net.lightbody.bmp.BrowserMobProxyServer;

import java.util.List;

public class MITMProxyManager {

  public static MitmproxyJava enableMITMProxy()
  {
    // remember to set local OS proxy settings in the Network Preferences
    MitmproxyJava proxy = new MitmproxyJava("/Users/rajeshsharma/Library/Python/3.9/bin/mitmdump", (InterceptedMessage m) -> {
      System.out.println("intercepted request for " + m.getRequest().toString());
      DriverManager.addThreadLocalMessages(m);
      return m;
    });

    return proxy;
  }
 public static MITMProxyManager getMITMProxyManagerObj()
  {
    return new MITMProxyManager();
  }


}
