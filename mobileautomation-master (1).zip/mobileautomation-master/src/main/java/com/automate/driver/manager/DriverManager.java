package com.automate.driver.manager;

import io.appium.mitmproxy.InterceptedMessage;
import io.appium.mitmproxy.MitmproxyJava;
import org.openqa.selenium.Proxy;

import com.automate.utils.AppiumServerManager;

import io.appium.java_client.AppiumDriver;
import net.lightbody.bmp.BrowserMobProxyServer;

import java.util.ArrayList;
import java.util.List;

public class DriverManager extends AppiumServerManager {

	private ThreadLocal<AppiumDriver> threadLocalDriver = new ThreadLocal<>();
	private ThreadLocal<Integer> threadLocaPortNumber = new ThreadLocal<>();
	private ThreadLocal<Proxy> threadLocalProxy = new ThreadLocal<>();
	private ThreadLocal<BrowserMobProxyServer> threadLocalBMP = new ThreadLocal<>();

  private static ThreadLocal<List<InterceptedMessage>> threadLocalMessages = new ThreadLocal<>();
  private ThreadLocal<MitmproxyJava> threadLocalMITMProxy = new ThreadLocal<>();


  public MitmproxyJava getMITMProxy()
  {
    return threadLocalMITMProxy.get();
  }


  public static List<InterceptedMessage> getInterceptedMessages()
  {
    return threadLocalMessages.get();
  }

  public static void addThreadLocalMessages(InterceptedMessage message)
  {
    List<InterceptedMessage> currentList = getInterceptedMessages();
    currentList.add(message);
    threadLocalMessages.set(currentList);
  }

  public void setThreadLocalMITMProxy(MitmproxyJava obj)
  {
    threadLocalMITMProxy.set(obj);
  }


  public AppiumDriver getDriver() {
		return threadLocalDriver.get();
	}


	public void setAppiumDriver(AppiumDriver driver) {
		threadLocalDriver.set(driver);
	}
	
	public BrowserMobProxyServer getBMPObj()
	{
		return threadLocalBMP.get();
	}
	
	public void setBMPObj(BrowserMobProxyServer bmp)
	{
		threadLocalBMP.set(bmp);
	}

	public Proxy getProxy() {
		return threadLocalProxy.get();
	}

	public void setProxy(Proxy proxy) {
		threadLocalProxy.set(proxy);
	}

	public int getPort() {
		return threadLocaPortNumber.get();
	}

	public void setPort(int portNumber) {
		threadLocaPortNumber.set(portNumber);
	}

	public void unload() {
		threadLocalDriver.remove();
	}

	public void quitDriver() {
		threadLocalDriver.get().quit();
	}
}
