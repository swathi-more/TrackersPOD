package com.automate.driver.factory;

import io.appium.mitmproxy.MitmproxyJava;
import org.openqa.selenium.Proxy;

import com.automate.customexceptions.DriverInitializationException;
import com.automate.driver.Drivers;
import com.automate.enums.MobilePlatformName;
import com.automate.utils.AppiumServerManager;

import io.appium.java_client.AppiumDriver;

public class DriverFactory {

  public static AppiumDriver initializeDriver(MobilePlatformName mobilePlatformName, String platformVersion, String deviceName, String udid, int port,
                                              String emulator, int freeport, Proxy proxy) {
    AppiumDriver driver;
    switch (mobilePlatformName) {
      case ANDROID:
        driver = Drivers.createAndroidDriverForNativeApp(deviceName,platformVersion, udid, port, emulator,freeport);
        break;
      case ANDROID_WEB:
        driver = Drivers.createAndroidDriverForWeb(deviceName,platformVersion, udid, port, emulator,freeport);
        break;
      case IOS:
        driver = Drivers.createIOSDriverForNativeApp(deviceName,platformVersion, udid, port,freeport);
        break;
      case IOS_WEB:
        driver = Drivers.createIOSDriverForWeb(deviceName,platformVersion, udid, port);
        break;
      case BROWSER_STACK :
    	  driver = Drivers.createBrowserStackDriver(deviceName,platformVersion, udid, port,freeport);
    	  break;
      case ANDROID_WITH_PROXY :
    	  driver = Drivers.createAndroidDriverForNativeAppWithProxy(deviceName,platformVersion, udid, port,emulator,freeport,proxy);
    	  break;
      case IOS_WITH_PROXY :
        driver = Drivers.createIOSDriverForNativeAppWithProxy(deviceName,platformVersion, udid, port,emulator,freeport,proxy);
        break;
      default:
        throw new DriverInitializationException(
          "Platform name " + mobilePlatformName + " is not found. Please check the platform name");
    }
    return driver;
  }

}
