package com.automate.driver.manager;

import java.net.Inet4Address;
import java.net.UnknownHostException;

import com.automate.constants.FrameworkConstants;
import net.lightbody.bmp.filters.RequestFilter;
import org.apache.commons.lang3.math.Fraction;
import org.openqa.selenium.Proxy;

import com.automate.utils.AppiumServerManager;

import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.client.ClientUtil;
import net.lightbody.bmp.proxy.CaptureType;

public class ProxyManager {
	
	private static Proxy seleniumProxy;
	
	
	public static Proxy getProxy(BrowserMobProxyServer proxy) throws UnknownHostException
	{

    if(seleniumProxy==null)
    {
      proxy.start(FrameworkConstants.proxy_port);
      seleniumProxy = ClientUtil.createSeleniumProxy(proxy);
      String hostIp = FrameworkConstants.proxy_ip;
      // String hostIp = Inet4Address.getLocalHost().getHostAddress();
      seleniumProxy.setHttpProxy(hostIp + ":" + proxy.getPort());
      seleniumProxy.setSslProxy(hostIp + ":" + proxy.getPort());
      proxy.enableHarCaptureTypes(CaptureType.REQUEST_CONTENT, CaptureType.RESPONSE_CONTENT);
    }

        return seleniumProxy;
	}
	
	
}
