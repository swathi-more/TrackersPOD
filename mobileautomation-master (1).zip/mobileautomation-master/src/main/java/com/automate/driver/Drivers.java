package com.automate.driver;

import static com.automate.utils.configloader.JsonUtils.getConfig;

import java.net.Inet4Address;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.Platform;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.automate.constants.FrameworkConstants;
import com.automate.customexceptions.DriverInitializationException;
import com.automate.enums.ConfigJson;
import com.automate.enums.MobileBrowserName;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.AutomationName;
import io.appium.mitmproxy.InterceptedMessage;
import io.appium.mitmproxy.MitmproxyJava;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.client.ClientUtil;
import net.lightbody.bmp.proxy.CaptureType;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class Drivers {

	public static AppiumDriver createAndroidDriverForNativeApp(String deviceName, String platformVersion, String udid,
			int port, String emulator, int freePort) {
		try {
			var capability = new DesiredCapabilities();
			capability.setCapability("platformName", Platform.ANDROID);
			capability.setCapability("appium:deviceName", deviceName);
			capability.setCapability("appium:automationName", AutomationName.ANDROID_UIAUTOMATOR2); // Specific to
																									// Android
			capability.setCapability("appium:uuid", udid); // To uniquely identify device
			capability.setCapability("appium:app", FrameworkConstants.ANDROID_APK_PATH);
			capability.setCapability("appPackage", getConfig(ConfigJson.APP_PACKAGE));
			capability.setCapability("appActivity", getConfig(ConfigJson.APP_ACTIVITY));
			capability.setCapability("appium:systemPort", port); // To set different port for each thread - This port is
																	// used to communicate with UiAutomator2
			if (emulator.equalsIgnoreCase("yes")) {
				capability.setCapability("avd", deviceName);
				capability.setCapability("appium:newCommandTimeout",
						Integer.parseInt(getConfig(ConfigJson.AVD_LAUNCH_TIMEOUT)));
			}
			System.out.println("data from config" + getConfig(freePort, ConfigJson.APPIUM_URL));
			return new AndroidDriver(new URL(getConfig(freePort, ConfigJson.APPIUM_URL)), capability);
		} catch (Exception e) {
			e.printStackTrace();
			throw new DriverInitializationException(
					"Failed to initialize driver. Please check the desired capabilities", e);
		}
	}
	
	public static AppiumDriver createAndroidDriverForNativeAppWithProxy(String deviceName, String platformVersion, String udid,
			int port, String emulator, int freePort,Proxy proxy) {
		try {
      AppiumDriver driver;

			var capability = new DesiredCapabilities();
			capability.setCapability("platformName", Platform.ANDROID);
			capability.setCapability("appium:deviceName", deviceName);
			capability.setCapability("appium:automationName", AutomationName.ANDROID_UIAUTOMATOR2); // Specific to
																									// Android
			capability.setCapability("appium:uuid", udid); // To uniquely identify device
      capability.setCapability("fullReset", true);
			capability.setCapability("appium:app", FrameworkConstants.ANDROID_APK_PATH);
			capability.setCapability("appium:appPackage", getConfig(ConfigJson.APP_PACKAGE));
			capability.setCapability("appium:appActivity", getConfig(ConfigJson.APP_ACTIVITY));
      capability.setCapability("appium:appWaitActivity","com.sephora.appmodules.onboarding.OnboardingActivity");
      capability.setCapability(CapabilityType.PROXY, proxy);
      capability.setCapability("idleTimeout", 100);


			//capability.setCapability("appium:systemPort", port);
      // To set different port for each thread - This port is
      // used to communicate with UiAutomator2
	
			//add proxy to desired capabilities
			//capability.setCapability(CapabilityType.PROXY, seleniumProxy);
			capability.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
      capability.setCapability("autoGrantPermissions", "true");
			
			if (emulator.equalsIgnoreCase("yes")) {
				capability.setCapability("avd", deviceName);
				capability.setCapability("appium:newCommandTimeout",
						Integer.parseInt(getConfig(ConfigJson.AVD_LAUNCH_TIMEOUT)));
			}
			System.out.println("data from config" + getConfig(freePort, ConfigJson.APPIUM_URL));
			driver = new AndroidDriver(new URL(getConfig(freePort, ConfigJson.APPIUM_URL)), capability);

      return driver;

    } catch (Exception e) {
			e.printStackTrace();
			throw new DriverInitializationException(
					"Failed to initialize driver. Please check the desired capabilities", e);
		}
	}


  public static AppiumDriver createIOSDriverForNativeAppWithProxy(String deviceName, String platformVersion, String udid,
                                                                      int port, String emulator, int freePort,Proxy proxy) {
    try {
      AppiumDriver driver;

      var capability = new DesiredCapabilities();
      capability.setCapability("platformName", Platform.IOS);
      capability.setCapability("platformVersion", platformVersion);
      capability.setCapability("appium:deviceName", deviceName);
      capability.setCapability("appium:automationName", AutomationName.IOS_XCUI_TEST);
      capability.setCapability("appium:uuid", udid);
      capability.setCapability("appium:app", FrameworkConstants.IOS_APP_PATH);
      capability.setCapability("appium:showXcodeLog", FrameworkConstants.showXcodeLog);
      capability.setCapability("appium:useNewWDA", true);
      capability.setCapability("appium:usePrebuiltWDA", true);
      capability.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
      capability.setCapability("appium:autoGrantPermissions", true);
      capability.setCapability("appium:autoAcceptAlerts", true);
      capability.setCapability(CapabilityType.PROXY, proxy);

      driver= new IOSDriver(new URL(getConfig(freePort, ConfigJson.APPIUM_URL)), capability);

      // enabling setting and notifications
      driver.setSetting("acceptAlertButtonSelector", "**/XCUIElementTypeButton[label == 'Allow While Using App']");

      // automatically install proxy certificate. Can be skipped if done manually on the simulator already.
      Path certificatePath = Paths.get(System.getProperty("user.dir")+"/certificate","ca-certificate-rsa.cer");
      Map args = new HashMap<>();
      byte[] byteContent = Files.readAllBytes(certificatePath);
      args.put("content", Base64.getEncoder().encodeToString(byteContent));
      driver.executeScript("mobile: installCertificate", args);


      return driver;
    } catch (Exception e) {
      e.printStackTrace();
      throw new DriverInitializationException(
        "Failed to initialize driver. Please check the desired capabilities", e);
    }
  }

	public static AppiumDriver createAndroidDriverForWeb(String deviceName,String platformVersion, String udid, int port, String emulator,int freePort) {
    try {
      var capability = new DesiredCapabilities();
      capability.setCapability("platformName", Platform.ANDROID);
      capability.setCapability("appium:deviceName", deviceName);
      capability.setCapability("appium:automationName", AutomationName.ANDROID_UIAUTOMATOR2); // Specific to Android
      capability.setCapability("appium:uuid", udid); // To uniquely identify device
      capability.setCapability("browserName", MobileBrowserName.CHROME);
      
        capability.setCapability("avd", deviceName);
        capability.setCapability("appium:newCommandTimeout",
                                 Integer.parseInt(getConfig(ConfigJson.AVD_LAUNCH_TIMEOUT)));
      
      System.out.println(deviceName + ": "+ udid+" : "+port);
      System.out.println("data from config"+getConfig(freePort , ConfigJson.APPIUM_URL));
      return new AndroidDriver(new URL(getConfig(freePort , ConfigJson.APPIUM_URL)), capability);
    }
	catch(Exception e)
	{
		e.printStackTrace();
		throw new DriverInitializationException("Failed to initialize driver. Please check the desired capabilities",
				e);
	}
	}

	public static AppiumDriver createIOSDriverForNativeApp(String deviceName, String platformVersion, String udid,
			int port, int freePort) {
		try {
			var capability = new DesiredCapabilities();
			capability.setCapability("platformName", Platform.IOS);
			capability.setCapability("appium:deviceName", deviceName);
			capability.setCapability("appium:automationName", AutomationName.IOS_XCUI_TEST);
			capability.setCapability("appium:uuid", udid);
			capability.setCapability("appium:app", FrameworkConstants.IOS_APP_PATH);
			capability.setCapability("xcodeOrgId", "8S2MZYKZ2F");
			capability.setCapability("xcodeSigningId", "iPhone Developer");
			capability.setCapability("bundleId", "com.truglobal.sample");
			capability.setCapability("showXcodeLog", true);
      capability.setCapability("fullReset", true);

			//capability.setCapability capabilities.setCapability("webDriverAgentUrl", WDAServer.SERVER_URL)); // To set different port for each
																					// thread - This port is used to
																					// communicate with WebDriverAgent
																					// driver

			return new IOSDriver(new URL(getConfig(freePort, ConfigJson.APPIUM_URL)), capability);
		} catch (Exception e) {
			throw new DriverInitializationException(
					"Failed to initialize driver. Please check the desired capabilities", e);
		}
	}

	public static AppiumDriver createIOSDriverForWeb(String deviceName, String platformVersion, String udid, int port) {
		try {
			var capability = new DesiredCapabilities();
			capability.setCapability("platformName", Platform.IOS);
			capability.setCapability("appium:deviceName", deviceName);
			capability.setCapability("appium:automationName", AutomationName.IOS_XCUI_TEST);
			capability.setCapability("appium:uuid", udid);
			capability.setCapability("bundleId", getConfig(ConfigJson.BUNDLE_ID));
			capability.setCapability(CapabilityType.BROWSER_NAME, MobileBrowserName.SAFARI);
			capability.setCapability("webkitDebugProxyPort", port); // For web view/Safari browser testing on real
																	// device

			return new IOSDriver(new URL(getConfig(port, ConfigJson.APPIUM_URL)), capability);
		} catch (Exception e) {
			throw new DriverInitializationException(
					"Failed to initialize driver. Please check the desired capabilities", e);
		}
	}

	public static AppiumDriver createBrowserStackDriver(String deviceName, String platformVersion, String udid,
			int port, int freePort) {
		try {
			var capability = new DesiredCapabilities();
			capability.setCapability("platformName", Platform.IOS);
			capability.setCapability("appium:deviceName", deviceName);
			capability.setCapability("appium:automationName", AutomationName.IOS_XCUI_TEST);
			capability.setCapability("appium:uuid", udid);
			capability.setCapability("app", FrameworkConstants.IOS_APP_PATH);
			capability.setCapability("xcodeOrgId", "8S2MZYKZ2F");
			capability.setCapability("xcodeSigningId", "iPhone Developer");
			capability.setCapability("bundleId", "com.truglobal.sample");
			capability.setCapability("showXcodeLog", true);
			// capability.setCapability(IOSMobileCapabilityType.WDA_LOCAL_PORT,
			// port); // To set different port for each thread - This port is used to
			// communicate with WebDriverAgent driver

			System.out.println("https://" + FrameworkConstants.BS_USERNAME + ":" + FrameworkConstants.BS_ACCESSKEY
					+ "@hub-cloud.browserstack.com/wd/hub");

			return new AppiumDriver(new URL("https://" + FrameworkConstants.BS_USERNAME + ":"
					+ FrameworkConstants.BS_ACCESSKEY + "@hub-cloud.browserstack.com/wd/hub"), capability);
		} catch (Exception e) {
			e.printStackTrace();
			throw new DriverInitializationException(
					"Failed to initialize driver. Please check the desired capabilities", e);
		}
	}
}
