package com.automate.interfaces;

public interface LoggerImpl {

	public void infoWithMessage(LoggerImpl logger,String msg);
	public void infoWithMessageAndAuthor(LoggerImpl logger,String msg,String author);
	public void infoWithMessageAndDevice(LoggerImpl logger, String msg,String device);
	public void infoWithMessageAndCategory(LoggerImpl logger,String msg,String category);
	public void info(LoggerImpl logger,String msg,String author,String device,String category);
	
	
	public void passWithMessage(LoggerImpl logger,String msg);
	public void passWithMessageAndAuthor(LoggerImpl logger,String msg,String author);
	public void passWithMessageAndDevice(LoggerImpl logger,String msg,String device);
	public void passWithMessageAndCategory(LoggerImpl logger,String msg,String category);
	public void pass(LoggerImpl logger,String msg,String author,String device,String category);
	
	public void failWithMessage(LoggerImpl logger,String msg);
	public void failWithMessageAndAuthor(LoggerImpl logger,String msg,String author);
	public void failWithMessageAndDevice(LoggerImpl logger,String msg,String device);
	public void failWithMessageAndCategory(LoggerImpl logger,String msg,String category);
	public void fail(LoggerImpl logger,String msg,String author,String device,String category);
	
	
	public void warningWithMessage(LoggerImpl logger,String msg);
	public void warningWithMessageAndAuthor(LoggerImpl logger,String msg,String author);
	public void warningWithMessageAndDevice(LoggerImpl logger,String msg,String device);
	public void warningWithMessageAndCategory(LoggerImpl logger,String msg,String category);
	public void warning(LoggerImpl logger,String msg,String author,String device,String category);
	
	
	public void skipWithMessage(LoggerImpl logger,String msg);
	public void skipWithMessageAndAuthor(LoggerImpl logger,String msg,String author);
	public void skipWithMessageAndDevice(LoggerImpl logger,String msg,String device);
	public void skipWithMessageAndCategory(LoggerImpl logger,String msg,String category);
	public void skip(LoggerImpl logger,String msg,String author,String device,String category);
	
}
