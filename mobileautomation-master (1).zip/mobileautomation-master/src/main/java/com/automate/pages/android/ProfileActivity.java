package com.automate.pages.android;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class ProfileActivity {

  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public ProfileActivity(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("android/ProfileActivity.csv");
    util.readDataFile("android/MeActivityData.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }

  public void clickOnOrders()
  {
    appiumCommands.click("ordersButton");
  }

  public void clickOnBeautyInsiderSummaryLink()
  {
    appiumCommands.click("beautyInsiderSummaryButton");
  }

  public void clickOnLovesSection()
  {
    appiumCommands.click("lovesSection");
  }

  public void clickOnBeautyReferenceLink()
  {appiumCommands.click("beautyReferencesLink");}

  public void clickBeautyInsiderSummaryLink()
  {
    appiumCommands.click("beautyInsiderSummaryLink");
  }

  public void clickOnRewardsBazaarLink()
  {
    appiumCommands.click("rewardsBazaarLink");
  }

  public void clickOnBeautyInsiderChallengesLink()
  {
    appiumCommands.click("beautyInsiderChallengesLink");
  }

  public void clickOnAutoReplenishLink()
  {
    appiumCommands.click("autoReplenishLink");
  }

  public void clickOnBuyItAgainLink()
  {
    appiumCommands.click("buyItAgainLink");
  }

  public void clickOnAccountLink()
  {
    appiumCommands.click("accountLink");
  }

  public void clickOnSameDayUnlimitedLink()
  {
    appiumCommands.click("sameDayUnlimitedLink");
    }

    public void clickOnSephoraCreditCardProgramLink()
    {
      appiumCommands.click("sephoraCreditCardProgramLink");
    }

    public void clickOnFlashLink()
    {
      appiumCommands.click("flashLink");
    }

    public  void clickOnReservationsLink()
    {
      appiumCommands.click("reservationsLink");
    }

    public void clickOnSampleAndRewardsLink()
    {
      appiumCommands.click("sampleAndRewardsLink");
    }

    public void clickOnBeautyAdvisorRecommendationsLink()
    {
      appiumCommands.click("beautyAdvisorRecommendationsLink");
    }

    public void clickOnBeautyInsiderChallengesLink_1()
    {
      appiumCommands.click("beautyInsiderChallengesLink");
    }

    public void clickOnLiveBeautyHelplink()
    {
      appiumCommands.click("liveBeautyHelpLink");
    }

    public void clickOnAppSettingsLink()
    {
      appiumCommands.click("appSettingsLink");
    }

    public void scrollToAppSettings()
    {
      appiumCommands.customWait(FrameworkConstants.prolongedWait);
      appiumCommands.performScroll();
      appiumCommands.performScroll();
      appiumCommands.performScroll();
    }
    
	public void clickOnYourLocationDropdown() {
		appiumCommands.click("yourLocation");
	}

	public void enterZipcode(int i) {
		appiumCommands.type("sameDayDeliveryZipcode", util.getTestCaseDataColumn(i, "zipcode"));
	}
	
	public void clickOnShowResultsButton() {
		appiumCommands.click("showResultsButton");

	}
	
	public void clickOnOKButton() {
		appiumCommands.click("okButton");

	}
	
	public void verifyTheZipcodeAppliedSuccessfully() {
		appiumCommands.checkElementIsVisibleOnPage("verifyZipcode");

	}
  public void BeautyPref(){

    appiumCommands.click("BeautyPrefrence");
  }


  public void Fifthpref(){
    //appiumCommands.performScroll();

    appiumCommands.click("FifthPre");
//    appiumCommands.click("ViewAllIngredient");
//    appiumCommands.click("IgredientAlco");

  }
//  public void SavedFifth(){
//    appiumCommands.customWait(3);
//    appiumCommands.click("igredientDone");
//    appiumCommands.click("SaveButton");
//  }
  public void NoPrefrenceClick(){
    if(appiumCommands.checkElementIsVisibleOnPage("NoPrefrenceUnclick")){
      appiumCommands.click("NoPrefrenceUnclick");
      appiumCommands.click("NoPrerence");
      appiumCommands.click("NoPrefrenceUnclick");
      appiumCommands.click("SaveButton");
    }
    else {
      appiumCommands.click("NoPrerence");
      appiumCommands.click("SaveButton");
    }
  }
  public void BuyitAgain(){
    appiumCommands.performScroll();
    appiumCommands.click("buyagain");
  }
  public void ClickAdd(){
    appiumCommands.click("Clickonadd");
  }
}
