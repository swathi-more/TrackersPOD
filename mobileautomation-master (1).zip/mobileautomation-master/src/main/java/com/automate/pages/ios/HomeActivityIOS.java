package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.io.IOException;

public class HomeActivityIOS {

	private static final Logger logger = LogManager.getLogger(HomeActivityIOS.class);
	AppiumDriver driver;
	ServiceLocator service = ServiceLocator.getInstance();
	Util util;
	AppiumCommands appiumCommands;

	public HomeActivityIOS(AppiumDriver driver) throws IOException, CsvException {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		util = new Util(driver);
		util.readCSV("ios/HomeActivityIOS.csv");
		util.readDataFile("android/HomeActivityData.csv");
		appiumCommands = new AppiumCommands(driver, util);
	}

	public void searchProduct(int i) {
		appiumCommands.type("inputSearchBox", util.getTestCaseDataColumn(i, "ProductName"));
		appiumCommands.click("productSuggestion");
	}

	public void searchCustomVariantProduct(int i) {
		//appiumCommands.click("searchTextField");
		appiumCommands.type("inputSearchBox", util.getTestCaseDataColumn(i, "ProductName"));
    appiumCommands.click("productSuggestionBYOB");
	}

	public void searchProduct(String productName) {
		appiumCommands.click("searchTextField");
		appiumCommands.type("inputSearchBox", productName);
		appiumCommands.click("productSuggestion");
	}

	public void clickOnBasketButton() {
		appiumCommands.click("basketButton");
	}

	public void verifyUserIcon() {
		Assert.assertTrue(!appiumCommands.checkElementIsVisibleOnPage("verifyUserIcon"));
	}

	public void clickOnSigInButton() {
		appiumCommands.click("signInButton");
	}

	public void clickOnSearchTextField() {
		appiumCommands.click("searchTextField");
	}

  public void clickOnVoiceSearch()
  {
    appiumCommands.click("voiceSearch");

  }

	public void clickOnBarCode() {
		appiumCommands.click("barCodeButton");
	}

	public void selectRecommendedForYouProduct() {
		appiumCommands.performScroll();
		appiumCommands.performScroll();
		appiumCommands.performScroll();
		appiumCommands.click("recommendedForYouCard");
	}

	public void clickChosenForyouProduct() {
		appiumCommands.performScroll();
		appiumCommands.performScroll();
		appiumCommands.performScroll();
		appiumCommands.click("chosenForYou");
	}
}
