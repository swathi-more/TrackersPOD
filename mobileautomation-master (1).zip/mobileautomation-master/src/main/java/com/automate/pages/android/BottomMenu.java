package com.automate.pages.android;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class BottomMenu {

  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public BottomMenu(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("android/BottomMenu.csv");
    util.readDataFile("android/BottomMenuData.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }

  public void clickOnHomeMenuIcon()
  {
    appiumCommands.click("homeNavIcon");
  }

  public void clickOnShopNavIcon()
  {
    appiumCommands.click("shopNavIcon");
  }

  public void clickOnOffersNavIcon()
  {
    appiumCommands.click("offersNavIcon");
  }

  public void clickOnMeIcon()
  {
    appiumCommands.click("meNavIcon");
    appiumCommands.customWait(FrameworkConstants.quickWait);
  }

  public void clickOnCommunityNavIcon()
  {
    appiumCommands.click("communityNavIcon");
  }

  public void clickOnStoresNavIcon()
  {
    appiumCommands.click("storesNavIcon");
  }

}
