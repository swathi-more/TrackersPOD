package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.io.IOException;

public class SignInIOS {


  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  BottomMenuIOS bottomMenuIOS;
  HomeActivityIOS homeActivityIOS;

  public SignInIOS(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("ios/signIn.csv");
    util.readDataFile("ios/SignInData.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }


  public void enterEmail(int i)
  {
    appiumCommands.type("email",util.getTestCaseDataColumn(i,"User_Email"));
  }

  public void enterPassword(int i)
  {
    appiumCommands.type("password",util.getTestCaseDataColumn(i,"User_Passowrd"));
  }

  public void enterInvalidEmail(int i)
  {
    appiumCommands.type("email",util.getTestCaseDataColumn(i,"InvalidEmail"));
  }

  public void enterInvalidPassword(int i)
  {
    appiumCommands.type("password",util.getTestCaseDataColumn(i,"InvalidPassword"));
  }

  public void staylogincheck()
  {

    Assert.assertTrue(appiumCommands.checkElementIsEnabledOnPage("StaySignedIn"));
    appiumCommands.click("StaySignedIn");

  }
  public void staylogincheckdisable(){
    Assert.assertTrue(appiumCommands.checkElementIsDisabledOnPage("StaySignedIn"));
  }
  public void clickOnSignInButton()
  {
    appiumCommands.click("signInButton");
  }

public  void clickOnSignInLink(){appiumCommands.click("signInLink");}
  public void login(int i)
  {
      enterEmail(i);
      enterPassword(i);
      clickOnSignInButton();
  }


  public void loginIOS(int i) throws IOException, CsvException {
    bottomMenuIOS = new BottomMenuIOS(driver);
    homeActivityIOS = new HomeActivityIOS(driver);
    int count =0;

    while(count <=3)
    {
      enterEmail(i);
      enterPassword(i);
      clickOnSignInButton();
      count++;
      if(bottomMenuIOS.checkCommunityIconPresent(5)){
        break;
      }

    }

  }


  public void clickforgott(){
    appiumCommands.click("forgotPass");
  }
  public void resetpass(){
    appiumCommands.click("ResetPass");
  }
  public void emailsentok(){
    appiumCommands.click("emailsentok");
  }

  public void clickOnCreateNewAccountLink()
  {
    appiumCommands.click("createNewAccountLink");
  }

  public void clickOnCreateAccountButton() {
    appiumCommands.click("CreateAccountButton");

  }

  public void Resend(){
    appiumCommands.click("ResendMail");
  }

  public void clickOnOKButtonError()
  {
    appiumCommands.click("signInErrorOKButton");

  }
}
