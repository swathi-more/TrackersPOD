package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class CommunityActivity {
  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public CommunityActivity(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("ios/CommunityActivity.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }

  public void ProfileBar() {
    appiumCommands.click("Profile");
  }

  public void Edit() {
    appiumCommands.click("Edit");
  }

  public void GallaryBar() {
    appiumCommands.click("Gallary");
  }

  public void ClickImage() {
     appiumCommands.performScroll();
     appiumCommands.click("ClickOnImage");

  }

  public void CheckLike() {
    String attribute = appiumCommands.getText("LikesVisible");
    System.out.println("&&&&&&&&&&&&&&&&&&&&"+attribute+"&&&&&&&&&&&&&&&&&");
    if (attribute.equals("0")) {
      appiumCommands.click("ClickLove");
      System.out.println("liked a picture.");
    }
    else {
      appiumCommands.click("ClickLove");
      appiumCommands.click("ClickLove");
      System.out.println("Liked a picture.");
    }
    }
    public void ClickUploadGallery(){
    appiumCommands.performScroll();
    appiumCommands.click("UploadtoGallery");
    appiumCommands.customWait(4);
    WebElement Existing=util.findElement("ChooseExisting");
    Existing.click();
    if(appiumCommands.checkElementIsVisibleOnPage("SelectPhotos")){
      appiumCommands.click("SelectPhotos");
    appiumCommands.click("ChooseImage");
    appiumCommands.click("Choose");
    }
    else {
      appiumCommands.click("ChooseImage");
      appiumCommands.click("Choose");
    }
  }

  public void UploadImage(){
    appiumCommands.performScroll();
      WebElement Submit=util.findElement("Caption");
      Submit.sendKeys("Nice Image");
      appiumCommands.click("CheckBox1");
      appiumCommands.click("CheckBox2");
      appiumCommands.click("Submit");
      appiumCommands.click("NoThanks");
    }
    public void ClickOnMyGallery() {
      appiumCommands.click("DeletefFromGallery");

  }
 public void DeletePhotoFromGallery(){
   if (appiumCommands.checkElementIsVisibleOnPage("ClickONPhoto")) {
     appiumCommands.click("ClickONPhoto");
    appiumCommands.click("ClickThreeeDot");
    appiumCommands.customWait(3);
    appiumCommands.click("DeleteImage");
  }
  else {
    System.out.println("No Image Found For The Delete");
  }
}
  }





