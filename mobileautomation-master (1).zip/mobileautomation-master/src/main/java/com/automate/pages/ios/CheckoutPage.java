package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.github.javafaker.Faker;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.io.IOException;
import java.util.Random;

public class CheckoutPage {

	private static final Logger logger = LogManager.getLogger(CheckoutPage.class);
	AppiumDriver driver;
	ServiceLocator service = ServiceLocator.getInstance();
	Util util;
	AppiumCommands appiumCommands;
	Random random = new Random();
	Faker faker = new Faker();

	public CheckoutPage(AppiumDriver driver) throws IOException, CsvException {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		util = new Util(driver);
		util.readCSV("ios/CheckoutPage.csv");
		util.readDataFile("ios/CheckoutPageData.csv");
		appiumCommands = new AppiumCommands(driver, util);
	}

	public void clickOnCheckoutQuantityButton() {
		appiumCommands.click("checkoutProductQuantityButton");
	}

	public void clickOnCheckoutQuantity() {
		appiumCommands.click("checkoutProductQuantity");
	}

	public void clickOnCheckoutButton() {
		appiumCommands.click("checkoutButton");
	}
	
	public void clickOnKlarnaAfterpayAndVerifyPayLaterPage() {
		appiumCommands.click("klarnaAfterPay");
		appiumCommands.checkElementIsVisibleOnPage("klarnaShopNowPayLaterHeader");
	}

	public void clickOnShipToTitle() {
		appiumCommands.click("shipToHeader");
	}

	public void clickToSelectAddress() {
		appiumCommands.click("selectAddress");
	}

	public void verifyAddressDetails() {
		appiumCommands.checkElementIsVisibleOnPage("addressDetails");
	}

	public void clickOnAddNewAddress() {
		appiumCommands.click("addNewAddress");
	}

	public void enterDataForNewAddress() {
		appiumCommands.type("addNewAddressFirstName", faker.address().firstName());
		appiumCommands.type("addNewAddressLastName", faker.address().lastName());
		appiumCommands.type("addNewAddressPhone", faker.number().digits(10));
		appiumCommands.type("addNewAddressAddress", "My street");
		appiumCommands.type("addNewAddressZipCode", faker.address().zipCode());
		appiumCommands.click("addNewAddressState");
		appiumCommands.type("addNewAddressSelectState", faker.address().state());
		appiumCommands.type("addNewAddressCity", faker.address().city());
	}
	
	public void clickOnDoneButtonForAddNewAddress() {
		appiumCommands.click("addNewAddressDoneButton");
	}

	public void clickOnAddPaymentOrGiftCard() {
		appiumCommands.click("addPaymentOrGiftcard");
	}

	public void clickOnAddNewCreditOrDebitCard() {
		appiumCommands.click("addNewCreditOrDebitCard");
	}

	public void enterCreditOrDebitCardInfo(int i) {
		appiumCommands.type("cardNumber", util.getTestCaseDataColumn(2, "creditCardNumber"));

//		select month
		appiumCommands.type("month",util.getTestCaseDataColumn(i,"ExpiryMonth"));
		appiumCommands.type("cvv", util.getTestCaseDataColumn(2, "cvv"));
    appiumCommands.click("firstName");
		appiumCommands.type("firstName", util.getTestCaseDataColumn(i, "firstName"));
		appiumCommands.type("lastName", util.getTestCaseDataColumn(i, "lastName"));
    appiumCommands.customWait(FrameworkConstants.quickWait);
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    if(appiumCommands.checkElementIsVisibleOnPage("setAsMyDefaultCardChkBox")){
      appiumCommands.click("setAsMyDefaultCardChkBox");
    }
    if(appiumCommands.checkElementIsVisibleOnPage("saveForFutureRefChkBox")){
      appiumCommands.click("saveForFutureRefChkBox");
    }
		appiumCommands.click("saveButton");
	}

	public void clickOnPlaceOrderButton() {
    if(appiumCommands.checkElementIsVisibleOnPage("backButton")){
    appiumCommands.click("backButton");
    }
		appiumCommands.click("placeOrder");
	}

	public void clickNoButtonOnReviewSephora() {
		appiumCommands.click("reviewSephoraNoButton");
	}

	public void storeOrderNumber() {
		String orderNumber = appiumCommands.getText("orderNumber");
		orderNumber = orderNumber.split(" ")[4];
		util.setSessionMap("orderNumber", orderNumber);
	}

	public void clickOnShopButton() {
		appiumCommands.click("shopButton");
	}

	public void clickOnViewDetailsButton(int i) {
		String orderViewDetals = util.getXpathFromCSV("orderViewDetals", "xpath");
		orderViewDetals = String.format(orderViewDetals, util.getSessionMap("orderNumber"));
		this.driver.findElement(By.xpath(orderViewDetals)).click();
	}

	public void clickOnCancelOrderLinkAndVerifyHeader() {
		appiumCommands.click("cancelOrder");
		appiumCommands.checkElementIsVisibleOnPage("reasonForCancellationHeader");
	}

	public void clickOnBackButtonToDeclineCancelOrder() {
		appiumCommands.click("backButton");
	}

	public void clickOnCancelOrderReason() {
		appiumCommands.click("cancelOrderReason");
	}

	public void clickOnSendButton() {
		appiumCommands.click("sendButton");
	}

	public void verifyCancelOrderMessage(int i) {
		String cancelOrderMessage = appiumCommands.getText("cancelOrderMessage");
		Assert.assertEquals(cancelOrderMessage, util.getTestCaseDataColumn(i, "cancelOrderMessage"));
	}

  public void clickOnScheduleDeliverWindowButton() {
    appiumCommands.click("scheduleDeliverWindowButton");
  }

  public void selectTimeAndConfirmIt() {
    appiumCommands.click("radioButton");appiumCommands.customWait(FrameworkConstants.quickWait);
    appiumCommands.click("confirmButton");appiumCommands.customWait(FrameworkConstants.longWait);

  }

  public void clickOnCancelButton() {
    appiumCommands.click("cancelButton");appiumCommands.customWait(FrameworkConstants.longWait);
  }
  public void clickOnSaveButton(){
    appiumCommands.click("saveButton");appiumCommands.customWait(FrameworkConstants.quickWait);
  }
  public void clickOnContinueToAfterPayButton(){
    appiumCommands.click("continueToAfterPayButton");appiumCommands.customWait(FrameworkConstants.longWait);
  }
  public void selectAfterPay() {
    if(appiumCommands.checkElementIsVisibleOnPage("addPaymentMethod")){
      appiumCommands.click("addPaymentMethod");
      appiumCommands.click("afterPayLogo");
      appiumCommands.checkElementIsNotVisibleOnPage("addPaymentMethod");
    }
    else {
      if (appiumCommands.checkElementIsVisibleOnPage("addPaymentOrGiftcard")) {
        clickOnAddPaymentOrGiftCard();
        appiumCommands.click("afterPayLogo");
      }
    }
  }
  public void placeOrderWithAfterPay(){
      Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("saveButton"));
      clickOnSaveButton();
      clickOnBackButtonToDeclineCancelOrder();
      clickOnContinueToAfterPayButton();
    }
    public void addPaymentOKPopup(){
    if(appiumCommands.checkElementIsVisibleOnPage("addPaymentOKPopup")){
      appiumCommands.click("addPaymentOKPopup");
    }
    }

  public void enterBillingAddress(int i) throws InterruptedException {
    if(appiumCommands.checkElementIsVisibleOnPage("addNewAddressPhone")){
      appiumCommands.type("addNewAddressPhone", util.getTestCaseDataColumn(i,"MobileNumber"));
      appiumCommands.type("addNewAddressAddress", "My street");
      appiumCommands.type("addNewAddressZipCode", util.getTestCaseDataColumn(i,"PostalCode"));appiumCommands.customWait(FrameworkConstants.quickWait);
    //  appiumCommands.sendKeys("addNewAddressZipCode",Keys.ENTER);
      WebElement element= driver.findElement(By.xpath("//android.widget.LinearLayout[@resource-id='com.sephora:id/add_shipping_zip_code']//android.widget.EditText"));
      Actions actions = new Actions(driver);
      actions.sendKeys(element,Keys.ENTER).perform();
      appiumCommands.customWait(FrameworkConstants.longWait);
      appiumCommands.click("addressLineOptionalText");appiumCommands.customWait(FrameworkConstants.longWait);
      appiumCommands.click("doneButton");appiumCommands.customWait(FrameworkConstants.longWait);
      if(appiumCommands.checkElementIsVisibleOnPage("doneButton")){
        appiumCommands.click("doneButton");
      }
    }
  }

  public void clickOnFreeTrialToBasketButton() {
    appiumCommands.performScroll();
    appiumCommands.click("freeTrialToBasketButton");appiumCommands.customWait(FrameworkConstants.quickWait);
  }

}

