package com.automate.pages.android;

import com.automate.commands.AppiumCommands;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class DebugActivity {


  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public DebugActivity(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("android/DebugActivity.csv");
    //util.readDataFile("MeActivityData.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }

  public void clickOnStoreModeLink()
  {
    appiumCommands.click("storeModeLink");
  }
}
