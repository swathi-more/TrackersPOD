package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.io.IOException;

public class StoreActivity {
  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public StoreActivity(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("ios/StoreActivity.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }
  public void clickOnEvents(){
    appiumCommands.performScroll();
      appiumCommands.click("Events");
  }
 public void WaitOnEvent(){
    appiumCommands.customWait(7);
 }
 public void ClickQuizzes(){
    appiumCommands.customWait(10);
    appiumCommands.performScroll();
    appiumCommands.performScrollBottomToUp();
    appiumCommands.click("Quizzes");
 }
 public void FragranceQuizz(){
    appiumCommands.click("Fragrance");
 }
 public void GetStartedQuizz(){
    appiumCommands.click("GetStart");
 }
 public void ClickonAns(){
    appiumCommands.click("Floaral");
    appiumCommands.click("FruityFLowral");
    appiumCommands.click("BestSeller");
 }
 public void VerifyResult(){
   Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("InStockAtSephora"));
 }

 public void clickonAll(){
    appiumCommands.click("ClickOnAll");
 }
 public void ClickonInsideFragrance(){
    appiumCommands.click("InSideFragrance");
 }

 public void ClickonEventsandServices(){
   appiumCommands.performScroll();
    appiumCommands.click("ClickonEventBook");
 }
 public void BookReservation(){
    appiumCommands.click("ReservationDate");
    appiumCommands.performScroll();
    appiumCommands.click("Time");
    appiumCommands.click("ContinueBook");
    appiumCommands.customWait(6);
 }
 public void reservationdetails(){
    appiumCommands.performScroll();
    appiumCommands.click("SecondCheckBox");
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.click("ThirdCheckBox");
    appiumCommands.click("CompleteBooking");
 }

}
