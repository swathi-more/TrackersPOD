package com.automate.pages.android;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.customannotations.FrameworkAnnotation;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class AccountDetailsPage {
  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public AccountDetailsPage(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("android/AccountDetailsPage.csv");
    util.readDataFile("android/AccountDetailsPageData.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }
  public void clickOnNameEditButton()
  {
    appiumCommands.click("nameEditButton");
    appiumCommands.customWait(FrameworkConstants.quickWait);
  }
  public void clickOnEmailEditButton()
  {
    appiumCommands.click("emailEditButton");
  }

  public void clickOnPasswordEditButton()
  {
    appiumCommands.click("passwordEditButton");
    appiumCommands.customWait(FrameworkConstants.quickWait);
  }

  public void editName(int i)
  {
    appiumCommands.type("firstNameEditField", util.getTestCaseDataColumn(i,"User_FirstName"));
    appiumCommands.type("lastNameEditField", util.getTestCaseDataColumn(i,"User_LastName"));
    appiumCommands.click("editAccountDetailsAccept");
  }

  public void editEmailAddress(int i)
  {
    appiumCommands.type("editEmailField", util.getTestCaseDataColumn(i,"User_EmailAddress"));
    appiumCommands.type("editConfirmEmailField", util.getTestCaseDataColumn(i,"User_EmailAddress"));
    appiumCommands.click("editAccountDetailsAccept");
    appiumCommands.customWait(FrameworkConstants.longWait);
  }

  public void editPassword(int i)
  {
    appiumCommands.type("editPasswordField", util.getTestCaseDataColumn(i,"User_Password"));
    appiumCommands.type("editPasswordConfirmField", util.getTestCaseDataColumn(i,"User_Password"));
    appiumCommands.click("editAccountDetailsAccept");
  }

}
