package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import javax.swing.*;
import java.io.IOException;

public class AllGroupsActivityIOS {


	private static final Logger logger = LogManager.getLogger(AllGroupsActivityIOS.class);
	AppiumDriver driver;
	ServiceLocator service = ServiceLocator.getInstance();
	Util util;
	AppiumCommands appiumCommands;

	public AllGroupsActivityIOS(AppiumDriver driver) throws IOException, CsvException {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		util = new Util(driver);
    util.readCSV("ios/AllGroupsActivityPage.csv");
    util.readDataFile("ios/AllGroupsActivityPageData.csv");
		appiumCommands = new AppiumCommands(driver, util);
	}
  public void joinGroup(){
    appiumCommands.click("JoinButton");
    if(appiumCommands.checkElementIsVisibleOnPage("continueButton")){
      appiumCommands.click("continueButton");
    }
  }
  public void leaveGroup(){
    if(appiumCommands.checkElementIsVisibleOnPage("MemberButton")){
      appiumCommands.click("MemberButton");
    }
    else{
      joinGroup();
      appiumCommands.click("MemberButton");
    }

  }
  public void clickOnMyGroupsButton(){
    appiumCommands.click("MyGroupsButton");
  }

  public void enterNickName(int i) {
    appiumCommands.type("nickNameInputTextField",util.getTestCaseDataColumn(i,"NickName")+appiumCommands.getCurrentTime());
    appiumCommands.performScroll();
  }

  public void clickOnJoinAndContinueButton() {
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.click("beautyInsiderLogo");
    appiumCommands.click("joinAndContinueButton");
  }
  public void clickOnAllGroupsButton() {
    appiumCommands.click("allGroupsButton");
  }
  public void selectGroup() {
    appiumCommands.click("selectJoinedGroup");
  }

  public void clickOnStartAConversation() {
    appiumCommands.click("startAConversation");
  }
}
