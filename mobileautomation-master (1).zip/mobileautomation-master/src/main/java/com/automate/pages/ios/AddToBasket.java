package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.io.IOException;

public class AddToBasket {

	private static final Logger logger = LogManager.getLogger(AddToBasket.class);
	AppiumDriver driver;
	ServiceLocator service = ServiceLocator.getInstance();
	Util util;
	AppiumCommands appiumCommands;

	public AddToBasket(AppiumDriver driver) throws IOException, CsvException {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		util = new Util(driver);
		util.readCSV("ios/AddToBasket.csv");
		util.readDataFile("ios/AddToBasketData.csv");
		appiumCommands = new AppiumCommands(driver, util);
	}

	public void verifySelectedProduct() {
		if (appiumCommands.checkElementIsVisibleOnPage("scrollDownPopup")) {
			appiumCommands.click("scrollDownPopup");
		}

		Assert.assertEquals(util.getSessionMap("ProductName"), appiumCommands.getText("verifyProductName"));
		Assert.assertEquals(util.getSessionMap("ProductBrandName"), appiumCommands.getText("verifyBrandName"));
		util.setSessionMap("ProductName", appiumCommands.getText("verifyProductName"));
		util.setSessionMap("ProductBrandName", appiumCommands.getText("verifyBrandName"));

	}

	public void clickOnShopAllFromThisBrand() {
		appiumCommands.scrollToViewElement("shopAllFromThisBrand");
		appiumCommands.click("shopAllFromThisBrand");
		appiumCommands.checkElementIsNotVisibleOnPage("shopAllFromThisBrand");
	}

	public void clickOnVariantText() {
		appiumCommands.click("variantText");
	}

	public void clickOnShippingOption() {
		appiumCommands.click("shippingOption");
	}

	public void clickOnAddToBasketQuantityButton() {
		appiumCommands.click("addToBasketSelectQuantityButton");
	}

	public void clickOnAddToBasketQuantity() {
		appiumCommands.click("addToBasketQuantity");
	}

	public void clickOnAddToBasketButton() {
		appiumCommands.click("addToBasketButton");
	}

	public void clickOnBuyOnlineAndPickupLink() {
		if (appiumCommands.checkElementIsVisibleOnPage("scrollDownPopup")) {
			appiumCommands.click("scrollDownPopup");
		}
		appiumCommands.performScroll();
		appiumCommands.click("buyOnlineAndPickupLink");
	}

	public void clickOnCheckOtherStoresLink() {
		appiumCommands.click("checkOtherStoresLink");
	}

	public void clickOnViewSimilarProductsText() {
		appiumCommands.customWait(FrameworkConstants.longWait);
		appiumCommands.performScroll();
		appiumCommands.performScroll();
		appiumCommands.performScroll();
		appiumCommands.performScroll();
		appiumCommands.performScroll();appiumCommands.performScroll();
    appiumCommands.performScroll();appiumCommands.performScroll();
		appiumCommands.click("similarProductsText");
	}

	public void clickAndVerifySameDayDelivery(int i) {
		appiumCommands.performScroll();
		appiumCommands.click("sameDayDeliver");
		if (appiumCommands.checkElementIsVisibleOnPage("sameDayDeliveryNotAvailable")) {
			appiumCommands.click("sameDayDeliveryNotAvailable");
			appiumCommands.type("zipCodeTxtField", util.getTestCaseDataColumn(i, "SameDayDeliveryZipCode"));
			appiumCommands.click("confirmButton");
			if (appiumCommands.checkElementIsVisibleOnPage("okButton")) {
				appiumCommands.click("okButton");
			}
		} else if (appiumCommands.checkElementIsVisibleOnPage("zipCodeTxtField")) {
      appiumCommands.type("zipCodeTxtField", util.getTestCaseDataColumn(i, "SameDayDeliveryZipCode"));
      appiumCommands.click("confirmButton");
      if (appiumCommands.checkElementIsVisibleOnPage("okButton")) {
        appiumCommands.click("okButton");
      }
    }
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("orderTiming"));
	}
  public void clickAndVerifySameDayDeliveryAvailable(int i) {
    appiumCommands.performScroll();
    appiumCommands.click("sameDayDeliver");
      appiumCommands.type("zipCodeTxtField", util.getTestCaseDataColumn(i, "SameDayDeliveryZipCode"));
      appiumCommands.click("confirmButton");
      if (appiumCommands.checkElementIsVisibleOnPage("okButton")) {
        appiumCommands.click("okButton");

    }
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("orderTiming"));
  }
	public void verifyScrollDropDown() {
		appiumCommands.performScroll();
	}
}
