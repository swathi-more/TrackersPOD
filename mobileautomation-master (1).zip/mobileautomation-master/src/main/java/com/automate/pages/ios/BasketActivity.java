package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.apache.commons.math3.analysis.function.Add;
import org.apache.poi.ss.usermodel.CellStyle;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class BasketActivity {
	AppiumDriver driver;
	ServiceLocator service = ServiceLocator.getInstance();
	Util util;
	AppiumCommands appiumCommands;

	public BasketActivity(AppiumDriver driver) throws IOException, CsvException {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		util = new Util(driver);
		util.readCSV("ios/BasketPage.csv");
		util.readDataFile("ios/BasketPageData.csv");
		appiumCommands = new AppiumCommands(driver, util);
	}

	public void AddtoBasket() {
		appiumCommands.customWait(3);
		appiumCommands.performScroll();
		appiumCommands.click("AddToBasket");
	}

	public void BasketIcon() {
		appiumCommands.click("Basket");
	}

	public void CheckOut() {
		appiumCommands.click("CheckOut");
	}

	public void ClickOnShip() {
		appiumCommands.click("ShipTo");
	}

	public void addAddress() {
		appiumCommands.click("AddAddress");
	}

	public void EnterDetails(int i) {
		appiumCommands.type("PhoneBox", util.getTestCaseDataColumn(i, "Phone"));

		WebElement Address = util.findElement("AddressBox");
		Address.sendKeys("C Admiralty Dr W Apt 1");

		WebElement Add = util.findElement("AddressBox");
		Add.sendKeys(Keys.ENTER);

		appiumCommands.type("ZipCodeBox", util.getTestCaseDataColumn(i, "ZipCode"));
		WebElement Zip = util.findElement("ZipCodeBox");
		Zip.sendKeys(Keys.ENTER);
    appiumCommands.customWait(FrameworkConstants.quickWait);
		appiumCommands.click("Saved");appiumCommands.customWait(FrameworkConstants.quickWait);
	}

	public void EditADD() {
		appiumCommands.click("EditAdd");
		WebElement PhoneType = util.findElement("PhoneBox");
		PhoneType.sendKeys(Keys.CLEAR);
		PhoneType.sendKeys("9284530404");
		WebElement Address = util.findElement("AddressBox");
		Address.sendKeys(Keys.CLEAR);
		Address.sendKeys("C Admiralty Dr W Apt 1");
		Address.sendKeys(Keys.ENTER);
		WebElement Zip = util.findElement("ZipCodeBox");
		Zip.sendKeys(Keys.CLEAR);
		Zip.sendKeys("028426250");
		Zip.sendKeys(Keys.ENTER);

	}

	public void UseTheAddressIEntered() {
		appiumCommands.click("UseAddress");
	}

	public void SelectSuggested() {
		appiumCommands.click("SelectNearest");
		appiumCommands.click("ChooseBox");
		appiumCommands.click("ChooseAddress");
	}

	public void clickonRecommended() {
		appiumCommands.click("Recommended");
	}

	public void clickOnSameDayUnlimitedCheckbox() {
		if (appiumCommands.checkElementIsVisibleOnPage("samedayUnlimitedCheckbox")) {
			appiumCommands.click("samedayUnlimitedCheckbox");
		}
	}

	public void ClickPlacedOrder(int i) {
		appiumCommands.click("PayMentMethod");
		appiumCommands.click("SelectAmerica");
		appiumCommands.checkElementIsVisibleOnPage("SecurityCode");
		WebElement EnterCode = util.findElement("EnterrCode");
		EnterCode.sendKeys("1234");
		appiumCommands.click("Saved");

		// going back to payments page
		appiumCommands.click("backButtonCheckoutPaymentSelectionPage");

		// click on place order
		appiumCommands.click("Placedorder");

		appiumCommands.checkElementIsNotVisibleOnPage("Placedorder");

	}
  public void placedOrderClick(int i) {

    // going back to payments page
    appiumCommands.click("backButtonCheckoutPaymentSelectionPage");
    // click on place order
    appiumCommands.click("Placedorder");
    appiumCommands.checkElementIsNotVisibleOnPage("Placedorder");

  }
  public void clickOnApplePayButton()
  {
    appiumCommands.click("applePayButton");
  }
public void clickOnAddCreditOrDebitCard(){
  appiumCommands.click("paymentMethode");
  appiumCommands.click("addNewCreditCardOrDebitCard");
}
}
