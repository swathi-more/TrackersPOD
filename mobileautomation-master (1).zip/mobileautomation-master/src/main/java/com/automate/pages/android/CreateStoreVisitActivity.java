package com.automate.pages.android;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class CreateStoreVisitActivity {

  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public CreateStoreVisitActivity(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("android/CreateStoreVisitActivity.csv");
    //util.readDataFile("MeActivityData.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }

  public void enterTextInStoreIdTxtBox(String storeId)
  {

    appiumCommands.type("storeIdTxtBox",storeId);
  }

  public void enterTextInStoreNameTxtBox(String storeName)
  {

    appiumCommands.type("storeNameTxtBox",storeName);
  }

  public void enterTextInStoreTypeTxtBox(String type)
  {
    appiumCommands.type("storeTypeTxtBox",type);
  }
  public void enterTextInStoreRegion()
  {
    appiumCommands.type("storeRegion","yes");
  }
  public void enterTextInStoreCountry(String country)
  {
    appiumCommands.type("storeCountry",country);
  }
  public void enterTextInStoreState(String state)
  {
    appiumCommands.type("storeState",state);
  }

  public void clickOnCreateStoreVisitButton()
  {
    appiumCommands.click("createStoreVisitButton");
  }

  public void createStoreWithDefaultValues()
  {
    enterTextInStoreIdTxtBox("0058");
    enterTextInStoreNameTxtBox("Sephora Test");
    enterTextInStoreTypeTxtBox("Sephora");
    enterTextInStoreRegion();
    enterTextInStoreCountry("US");
    enterTextInStoreState("CA");
    clickOnCreateStoreVisitButton();
  }
}
