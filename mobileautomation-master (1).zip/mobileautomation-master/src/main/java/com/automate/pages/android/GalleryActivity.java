package com.automate.pages.android;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class GalleryActivity {


	private static final Logger logger = LogManager.getLogger(GalleryActivity.class);
	AppiumDriver driver;
	ServiceLocator service = ServiceLocator.getInstance();
	Util util;
	AppiumCommands appiumCommands;

	public GalleryActivity(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("android/GalleryActivityPage.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }

  public void selectImage() {
    appiumCommands.click("selectImage");
  }
public void clickOnMoreButton(){
  appiumCommands.click("moreButton");
}
public void clickOnReportButton(){
  appiumCommands.click("reportButton");
}
  public void reportAnImage() {
    clickOnMoreButton();
    clickOnReportButton();
  }

  public void uploadPhoto() {
  appiumCommands.click("uploadPhotoLink");
    appiumCommands.click("takePhotoIcon");
    appiumCommands.click("shutterIcon");
    appiumCommands.click("imageDoneButton");
    appiumCommands.type("captionInputTextField","Test");
    appiumCommands.performScroll();
    appiumCommands.click("yesIagreeChkBox");
    appiumCommands.click("postButton");
    if(appiumCommands.checkElementIsVisibleOnPage("successOKButton")){
      appiumCommands.click("successOKButton");
    }
  }

  public void deletePhoto() {
    appiumCommands.click("myGalleryButton");
    appiumCommands.click("selectPhoto");
    appiumCommands.click("kebobIcon");
    appiumCommands.click("deleteIcon");
    appiumCommands.click("deleteIcon");
    appiumCommands.click("doneButton");
  }

  public void clickOnImage() {
    appiumCommands.click("imageCard");
  }
}
