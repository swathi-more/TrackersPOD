package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class MeActivity {
  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public MeActivity(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("ios/MeActivity.csv");
    //util.readDataFile("");
    appiumCommands = new AppiumCommands(driver, util);
  }
  public void ScrollAppSetting(){
    appiumCommands.performScroll();
    appiumCommands.performScroll();
  }
  public void ClickOnAppSettiong(){
    appiumCommands.click("AppSetting");
  }

   public void clickOnBuyAgain(){
    appiumCommands.click("BuyitAgain");
   }
   public void ClickStartShopping(){
    appiumCommands.click("StartShopping");
   }
   public void BeautyPrefrenceIcon(){
    appiumCommands.click("BeautyPrefrence");
   }
   public void ClickOnPrefrence(){
    appiumCommands.click("SkinType");
      appiumCommands.click("beautyPreferenceNormal");appiumCommands.customWait(FrameworkConstants.quickWait);
      if(appiumCommands.checkElementIsVisibleOnPage("SaveContinue")){
        appiumCommands.click("SaveContinue");
      } else {
        appiumCommands.click("beautyPreferenceNormal");appiumCommands.customWait(FrameworkConstants.quickWait);
        appiumCommands.click("SaveContinue");

      }
   }
   public void SkipQuestion(){
    appiumCommands.performScroll();

    if(appiumCommands.checkElementIsNotVisibleOnPage("SkinTone")){
      appiumCommands.click("SkinTone");appiumCommands.customWait(FrameworkConstants.quickWait);
      appiumCommands.click("SkipThisQuestion");
    }
    else {
      appiumCommands.performScrollBottomToUp();
      appiumCommands.click("SkinTone");appiumCommands.customWait(FrameworkConstants.quickWait);
      appiumCommands.click("SkipThisQuestion");
    }
    if(appiumCommands.checkElementIsVisibleOnPage("SkipThisQuestion")){
      appiumCommands.click("SkipThisQuestion");
    }
   }
   public void clickonSamedeliveryOption(){
    appiumCommands.performScroll();
    appiumCommands.click("SameDayWindow");
   }
   public void CancelUnlimited(){
    appiumCommands.click("CancelSub");
    appiumCommands.click("CliCkonCancelSub");
   }
   public void cancelReservationOpt(){
    appiumCommands.click("CancelReservation");
   }
  }


