package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class BeautyInsiderActivityIOS {

	AppiumDriver driver;
	ServiceLocator service = ServiceLocator.getInstance();
	Util util;
	AppiumCommands appiumCommands;

	public BeautyInsiderActivityIOS(AppiumDriver driver) throws IOException, CsvException {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		util = new Util(driver);
		util.readCSV("ios/BeautyInsiderActivityIOS.csv");
		// util.readDataFile("MeActivityData.csv");
		appiumCommands = new AppiumCommands(driver, util);
	}

	public void clickOnBarCodeIcon() {
		appiumCommands.click("barcodeIcon");
	}
}
