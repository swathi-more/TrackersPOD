package com.automate.pages.android;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class CommunityActivity {

  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public CommunityActivity(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("android/CommunityActivity.csv");
    //util.readDataFile("MeActivityData.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }

  public void clickOnCommunityTopTab() {
    appiumCommands.click("communityTopTab");
  }

  public void clickOnPofileTopTab() {
    appiumCommands.click("profileTopTab");
  }

  public void clickOnGroupsTopTab() {
    appiumCommands.click("groupsTopTab");
  }

  public void clickOnGalleryTopTab() {
    appiumCommands.click("galleryTopTab");
  }

  public void clickOnStartAConversation() {
    appiumCommands.click("startAConversation");
  }

  public void clickOnUploadToGallery() {
    appiumCommands.click("uploadToGallery");
  }

  public void clickOnTrendingFirstImage() {
    appiumCommands.click("TrendingFirstImage");
  }

  public void clickOnAllPostsLink() {
    appiumCommands.click("allPostsLink");
  }

  public void clickOnSubscribeButton() {
    if (appiumCommands.checkElementIsVisibleOnPage("unSubscribeButton")) {
      appiumCommands.click("unSubscribeButton");
    }
    appiumCommands.click("subscribeButton");
  }

  public void profileBarClick() {
    appiumCommands.click("CommunityProfile");
  }

  public void EditProfile() {
    appiumCommands.click("EditCommProfile");
  }

  public void clickOnReplyButton() {
    appiumCommands.click("replyButton");
  }

  public void enterPostMessage() {
    appiumCommands.type("bodyInputTxt", "Test");
  }

  public void clickOnPostButton() {
    appiumCommands.click("postButton");
  }

  public void postTheMessage() {
    enterPostMessage();
    appiumCommands.performScroll();
    clickOnPostButton();
  }

  public void CommunityGallery() {
    appiumCommands.click("CommunityGalary");
  }

  public void galleryScroll() {
    appiumCommands.performScroll();
  }

  public void LoveThePicture() {

    appiumCommands.click("LovetheImage");
  }
  public void CommunityGalary(){
    appiumCommands.click("CommunityGalary");
  }
  public void galleryscroll(){
    appiumCommands.performScroll();
    appiumCommands.performScroll();
  }

  public void clickonImage(){
    appiumCommands.click("ClickonImage");
  }
  public void LovethePicture(){
    String attribute = appiumCommands.getText("LoveVisible");
    System.out.println("&&&&&&&&&&&&&&&&&&&&"+attribute+"&&&&&&&&&&&&&&&&&");
    if (attribute.equals("1")) {
      appiumCommands.click("LovetheImage");
      appiumCommands.click("LovetheImage");
    } else {
      appiumCommands.click("LovetheImage");
      System.out.println("Liked a picture.");
    }
  }




}

