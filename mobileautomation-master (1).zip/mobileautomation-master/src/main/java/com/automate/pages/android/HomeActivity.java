package com.automate.pages.android;

import java.io.IOException;

import com.automate.constants.FrameworkConstants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import com.automate.commands.AppiumCommands;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;

import io.appium.java_client.AppiumDriver;
import org.testng.Assert;

public class HomeActivity {

	private static final Logger logger = LogManager.getLogger(HomeActivity.class);
	AppiumDriver driver;
	ServiceLocator service = ServiceLocator.getInstance();
	Util util;
	AppiumCommands appiumCommands;

	public HomeActivity(AppiumDriver driver) throws IOException, CsvException {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		util = new Util(driver);
		util.readCSV("android/HomeActivity.csv");
		util.readDataFile("android/HomeActivityData.csv");
		appiumCommands = new AppiumCommands(driver, util);
	}

	public void searchProduct(int i) {

		appiumCommands.click("searchTextField");
		appiumCommands.type("inputSearchBox", util.getTestCaseDataColumn(i, "ProductName"));
	  appiumCommands.click("productSuggestion");
	}

	public void searchCustomVariantProduct(int i) {
		appiumCommands.click("searchTextField");
		appiumCommands.type("inputSearchBox", util.getTestCaseDataColumn(i, "ProductName"));
		Actions actions = new Actions(driver);
		actions.sendKeys(Keys.ENTER).perform();
	}

	public void searchProduct(String productName) {
		appiumCommands.click("searchTextField");
		appiumCommands.type("inputSearchBox", productName);
		appiumCommands.click("productSuggestion");
	}

	public void clickOnBasketButton() {
		appiumCommands.click("basketButton");
	}

	public void verifyUserIcon() {
		Assert.assertTrue(!appiumCommands.checkElementIsVisibleOnPage("verifyUserIcon"));
	}

	public void clickOnSigInButton() {
		appiumCommands.click("signInButton");
	}

	public void clickOnSearchTextField() {
		appiumCommands.click("searchTextField");
	}

	public void clickOnBarCode() {
		appiumCommands.click("barCodeButton");
	}

	public void selectRecommendedForYouProduct() {
    appiumCommands.customWait(3);
//		appiumCommands.performScroll();
//		appiumCommands.performScroll();
//		appiumCommands.performScroll();
//    appiumCommands.performScroll();
//		appiumCommands.click("recommendedForYouCard");
    boolean status=true;
    while (status){
      if(appiumCommands.checkElementIsVisibleOnPage("VerfiryRecommendedForYou")){
        appiumCommands.click("RecommendedProduct");
        status=false;
      }
      else {
        appiumCommands.performScroll();
      }
    }
	}

	public void clickChosenForyouProduct() {
		appiumCommands.performScroll();
		appiumCommands.performScroll();
		appiumCommands.performScroll();
		appiumCommands.click("chosenForYou");
	}
  public void Homerefresh() {
    appiumCommands.click("HomeRefresh");
}}
