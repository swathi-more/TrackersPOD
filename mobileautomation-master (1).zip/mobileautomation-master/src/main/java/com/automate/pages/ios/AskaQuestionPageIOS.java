package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class AskaQuestionPageIOS {
	AppiumDriver driver;
	ServiceLocator service = ServiceLocator.getInstance();
	Util util;
	AppiumCommands appiumCommands;

	public AskaQuestionPageIOS(AppiumDriver driver) throws IOException, CsvException {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		util = new Util(driver);
		util.readCSV("ios/AskaQuestionPage.csv");
		util.readDataFile("ios/AskaQuestionPageData.csv");
		appiumCommands = new AppiumCommands(driver, util);
	}

	public void typeQuestion(int i) {
		appiumCommands.type("enterQuestionField", util.getTestCaseDataColumn(i, "questions"));
	}

	public void clickOnTermsCheckBox() throws InterruptedException {
		appiumCommands.click("agreeTermsCheckBox");
	}

	public void clickOnSubmit() {
		appiumCommands.performScroll();
		appiumCommands.click("submitButton");
	}

	public void clickDoneButton() {
		appiumCommands.click("doneButton");
	}

	public void askQuestion() throws InterruptedException {
		typeQuestion(0);

		clickOnTermsCheckBox();
		clickOnSubmit();
		clickDoneButton();

	}

}
