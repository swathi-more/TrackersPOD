package com.automate.pages.android;

import com.automate.commands.AppiumCommands;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class FilterAndSortPage {


  private static final Logger logger = LogManager.getLogger(ProductsPage.class);
  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public FilterAndSortPage(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("android/FilterAndSortPage.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }

  public void clickOnSortFiler() {
    appiumCommands.click("sortDropDown");
  }

  public void clickOnOldestOprtion() {
    appiumCommands.click("oldestOption");
  }

  public void clickOnRatingDropDown() {
    appiumCommands.click("ratingDropDown");
  }

  public void clickOnFiveStartCheckBox() {
    appiumCommands.click("fiveStarCheckBox");
  }

  public void clickOnShowResultsButton() {
    appiumCommands.click("showResultsButton");
  }
}
