package com.automate.pages.android;

import com.automate.commands.AppiumCommands;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class Reservation {


  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public Reservation(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("android/Reservation.csv");
    // util.readDataFile("StoresActivityData.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }

  public boolean checkNoTimesAvailableLink()
  {
    return appiumCommands.checkElementIsVisibleOnPage("noTimesAvailableLink");
  }

  public void clickOnShowMoreTimesAndLocation()
  {
    appiumCommands.click("showMoreTimesAndLocation");
  }

  public void clickOnFirstDay()
  {
    appiumCommands.click("firstday");
  }

  public void clickOnSecondDay()
  {
    appiumCommands.click("secondDay");
  }

  public void clickOnThirdDay()
  {
    appiumCommands.click("thirdDay");
  }

  public void clickOnFourthDay()
  {
    appiumCommands.click("fourthDay");
  }

  public void clickOnFifthDay()
  {
    appiumCommands.click("fifthDay");
  }

  public void clickOnSixthDay()
  {
    appiumCommands.click("sixthDay");
  }

  public void clickOnSeventhDay()
  {
    appiumCommands.click("seventhDay");
  }

  public void selectFirstAvailableTime()
  {
    appiumCommands.click("selectTime");
  }

  public void clickOnContinueBooking()
  {
    appiumCommands.click("continueBookingButton");
  }

  public void messageUpdateCheckbox()
  {
    appiumCommands.click("messageUpdateCheckbox");
  }

  public void completeBooking() {
    appiumCommands.click("completeBooking");
  }

  public void clickPaymentPolicy()
  {
    appiumCommands.click("checkPaymentPolicy");
  }

  public void initiateBooking()
  {
        appiumCommands.performScroll();
        clickOnFourthDay();

        if(appiumCommands.checkElementIsVisibleOnPage("selectTime"))
        {
          selectFirstAvailableTime();
        }
        else{

          clickOnShowMoreTimesAndLocation();
          appiumCommands.performScroll();
          appiumCommands.performScroll();

          if(appiumCommands.checkElementIsVisibleOnPage("selectTime"))
          {
            selectFirstAvailableTime();
          }

        }

        clickOnContinueBooking();
  }


  public void confirmBooking()
  {
      messageUpdateCheckbox();
      appiumCommands.performScroll();
      appiumCommands.performScroll();
      clickPaymentPolicy();
      completeBooking();

  }

}
