package com.automate.pages.android;

import com.automate.commands.AppiumCommands;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.Keys;
import java.io.IOException;

public class AskaQuestionPage {
  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public AskaQuestionPage(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("android/AskaQuestionPage.csv");
    util.readDataFile("android/AskaQuestionPageData.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }


  public void typeQuestion(int i)
  {
    appiumCommands.type("enterQuestionField", util.getTestCaseDataColumn(i,"questions"));
  }

  public void clickOnTermsCheckBox() throws InterruptedException {
    Actions actions = new Actions(driver);
    actions.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB,Keys.TAB, Keys.ENTER).perform();
  }

  public void clickOnSubmit(){
    appiumCommands.performScroll();
    appiumCommands.click("submitButton");
  }

  public void clickDoneBtton() {
    appiumCommands.click("doneButton");
  }

}
