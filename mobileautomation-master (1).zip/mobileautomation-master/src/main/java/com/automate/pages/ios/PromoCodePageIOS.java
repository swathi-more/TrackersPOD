package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class PromoCodePageIOS {

	private static final Logger logger = LogManager.getLogger(PromoCodePageIOS.class);
	AppiumDriver driver;
	ServiceLocator service = ServiceLocator.getInstance();
	Util util;
	AppiumCommands appiumCommands;

	public PromoCodePageIOS(AppiumDriver driver) throws IOException, CsvException {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		util = new Util(driver);
		util.readCSV("ios/PromoCodePageIOS.csv");
		util.readDataFile("ios/PromoCodeDataIos.csv");
		appiumCommands = new AppiumCommands(driver, util);
	}

	public void enterPromoCode(int i) {
		appiumCommands.type("promoCodeInputText", util.getTestCaseDataColumn(i, "PromoCode"));
	}

  public void clickOnApplyButton() {
    appiumCommands.click("applyButton");
  }

  public void clickOnRemoveButton() {
    appiumCommands.click("removeButton");
  }

  public void clickOnCancelButton() {
    appiumCommands.click("cancelButton");
  }
}
