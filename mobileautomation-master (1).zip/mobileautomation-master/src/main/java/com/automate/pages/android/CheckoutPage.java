package com.automate.pages.android;

import java.io.IOException;
import java.util.Random;

import com.automate.constants.FrameworkConstants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import com.automate.commands.AppiumCommands;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.github.javafaker.Faker;
import com.opencsv.exceptions.CsvException;

import io.appium.java_client.AppiumDriver;
import org.testng.Assert;

public class CheckoutPage {

	private static final Logger logger = LogManager.getLogger(CheckoutPage.class);
	AppiumDriver driver;
	ServiceLocator service = ServiceLocator.getInstance();
	Util util;
	AppiumCommands appiumCommands;
	Random random = new Random();
	Faker faker = new Faker();

	public CheckoutPage(AppiumDriver driver) throws IOException, CsvException {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		util = new Util(driver);
		util.readCSV("android/CheckoutPage.csv");
		util.readDataFile("android/CheckoutPageData.csv");
		appiumCommands = new AppiumCommands(driver, util);
	}

	public void clickOnCheckoutQuantityButton() {
		appiumCommands.click("checkoutProductQuantityButton");
	}

	public void clickOnCheckoutQuantity() {
		appiumCommands.click("checkoutProductQuantity");
	}

	public void clickOnCheckoutButton() {
		appiumCommands.click("checkoutButton");
	}
	
	public void clickOnKlarnaAfterpayAndVerifyPayLaterPage() {
		appiumCommands.click("klarnaAfterPay");
		appiumCommands.checkElementIsVisibleOnPage("klarnaShopNowPayLaterHeader");
	}

	public void clickOnShipToTitle() {
		appiumCommands.click("shipToHeader");
	}

	public void clickToSelectAddress() {
		appiumCommands.click("selectAddress");
	}

	public void verifyAddressDetails() {
		appiumCommands.checkElementIsVisibleOnPage("addressDetails");
	}

	public void clickOnAddNewAddress() {
		appiumCommands.click("addNewAddress");
	}

	public void enterDataForNewAddress() {
		appiumCommands.type("addNewAddressFirstName", faker.address().firstName());
		appiumCommands.type("addNewAddressLastName", faker.address().lastName());
		appiumCommands.type("addNewAddressPhone", faker.number().digits(10));
		appiumCommands.type("addNewAddressAddress", "My street");
		appiumCommands.type("addNewAddressZipCode", faker.address().zipCode());
		appiumCommands.click("addNewAddressState");
		appiumCommands.type("addNewAddressSelectState", faker.address().state());
		appiumCommands.type("addNewAddressCity", faker.address().city());
	}
	
	public void clickOnDoneButtonForAddNewAddress() {
		appiumCommands.click("addNewAddressDoneButton");
	}

	public void clickOnAddPaymentOrGiftCard() {
		appiumCommands.click("addPaymentOrGiftcard");
	}

	public void clickOnAddNewCreditOrDebitCard() {
		appiumCommands.click("addNewCreditOrDebitCard");
	}

	public void enterCreditOrDebitCardInfo(int i) {
		appiumCommands.type("cardNumber", util.getTestCaseDataColumn(i, "creditCardNumber"));

//		select month
		appiumCommands.click("month");
		String monthXpath = util.getXpathFromCSV("monthOption", "xpath");
		monthXpath = String.format(monthXpath, util.getTestCaseDataColumn(i, "month"));
		this.driver.findElement(By.xpath(monthXpath)).click();

//		select month
		appiumCommands.click("year");
		String yearXpath = util.getXpathFromCSV("yearOption", "xpath");
		yearXpath = String.format(yearXpath, util.getTestCaseDataColumn(i, "year"));
		this.driver.findElement(By.xpath(yearXpath)).click();

		appiumCommands.type("cvv", util.getTestCaseDataColumn(i, "cvv"));
		appiumCommands.type("firstName", util.getTestCaseDataColumn(i, "firstName"));
		appiumCommands.type("lastName", util.getTestCaseDataColumn(i, "lastName"));
		appiumCommands.click("doneButton");
	}

	public void clickOnPlaceOrderButton() {
		appiumCommands.click("placeOrder");
	}

	public void clickNoButtonOnReviewSephora() {
		appiumCommands.click("reviewSephoraNoButton");
	}

	public void storeOrderNumber() {
		String orderNumber = appiumCommands.getText("orderNumber");
		orderNumber = orderNumber.split(" ")[4];
		util.setSessionMap("orderNumber", orderNumber);
	}

	public void clickOnShopButton() {
		appiumCommands.click("shopButton");
	}

	public void clickOnViewDetailsButton(int i) {
		String orderViewDetals = util.getXpathFromCSV("orderViewDetals", "xpath");
		orderViewDetals = String.format(orderViewDetals, util.getSessionMap("orderNumber"));
		this.driver.findElement(By.xpath(orderViewDetals)).click();
	}

	public void clickOnCancelOrderLinkAndVerifyHeader() {
		appiumCommands.click("cancelOrder");
		appiumCommands.checkElementIsVisibleOnPage("reasonForCancellationHeader");
	}

	public void clickOnBackButtonToDeclineCancelOrder() {
		appiumCommands.click("backButton");
	}

	public void clickOnCancelOrderReason() {
		appiumCommands.click("cancelOrderReason");
	}

	public void clickOnSendButton() {
		appiumCommands.click("sendButton");
	}

	public void verifyCancelOrderMessage(int i) {
		String cancelOrderMessage = appiumCommands.getText("cancelOrderMessage");
		Assert.assertEquals(cancelOrderMessage, util.getTestCaseDataColumn(i, "cancelOrderMessage"));
	}

  public void clickOnScheduleDeliverWindowButton() {
    appiumCommands.click("scheduleDeliverWindowButton");
  }

  public void selectTimeAndConfirmIt() {
    appiumCommands.click("radioButton");appiumCommands.customWait(FrameworkConstants.quickWait);
    appiumCommands.click("confirmButton");appiumCommands.customWait(FrameworkConstants.quickWait);

  }

  public void clickOnCancelButton() {
    appiumCommands.click("cancelButton");appiumCommands.customWait(FrameworkConstants.quickWait);
  }
  public void clickOnSaveButton(){
    appiumCommands.click("saveButton");appiumCommands.customWait(FrameworkConstants.quickWait);
  }
  public void clickOnContinueToAfterPayButton(){
    appiumCommands.click("continueToAfterPayButton");appiumCommands.customWait(FrameworkConstants.longWait);
  }
  public void selectAfterPay() {
    if(appiumCommands.checkElementIsVisibleOnPage("addPaymentOrGiftcard")){
      clickOnAddPaymentOrGiftCard();
      appiumCommands.click("afterPayLogo");
    }
  }
  public void placeOrderWithAfterPay(){
      Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("saveButton"));
      clickOnSaveButton();
      clickOnBackButtonToDeclineCancelOrder();
      clickOnContinueToAfterPayButton();
    }
    public void addPaymentOKPopup(){
    if(appiumCommands.checkElementIsVisibleOnPage("addPaymentOKPopup")){
      appiumCommands.click("addPaymentOKPopup");
    }
    }

  public void enterBillingAddress(int i) throws InterruptedException {
    if(appiumCommands.checkElementIsVisibleOnPage("addNewAddressPhone")){
      appiumCommands.type("addNewAddressPhone", util.getTestCaseDataColumn(i,"MobileNumber"));
      appiumCommands.type("addNewAddressAddress", "My street");
      appiumCommands.type("addNewAddressZipCode", util.getTestCaseDataColumn(i,"PostalCode"));appiumCommands.customWait(FrameworkConstants.quickWait);
    //  appiumCommands.sendKeys("addNewAddressZipCode",Keys.ENTER);
      WebElement element= driver.findElement(By.xpath("//android.widget.LinearLayout[@resource-id='com.sephora:id/add_shipping_zip_code']//android.widget.EditText"));
      Actions actions = new Actions(driver);
      actions.sendKeys(element,Keys.ENTER).perform();
      appiumCommands.click("addressLineOptionalText");appiumCommands.customWait(FrameworkConstants.longWait);
      appiumCommands.click("doneButton");appiumCommands.customWait(FrameworkConstants.longWait);
      if(appiumCommands.checkElementIsVisibleOnPage("doneButton")){
        appiumCommands.click("doneButton");
      }
    }
  }

  public void clickOnFreeTrialToBasketButton() {
    appiumCommands.performScroll();
    appiumCommands.click("freeTrialToBasketButton");appiumCommands.customWait(FrameworkConstants.quickWait);
  }
}

