package com.automate.pages.android;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class ProductsPage {


	private static final Logger logger = LogManager.getLogger(ProductsPage.class);
	AppiumDriver driver;
	ServiceLocator service = ServiceLocator.getInstance();
	Util util;
	AppiumCommands appiumCommands;

	public ProductsPage(AppiumDriver driver) throws IOException, CsvException {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		util = new Util(driver);
    util.readCSV("android/ProductsPage.csv");
		appiumCommands = new AppiumCommands(driver, util);
	}
  public void userSelectTheProduct(){
    util.setSessionMap("ProductName",appiumCommands.getText("productName"));
    util.setSessionMap("ProductBrandName",appiumCommands.getText("productBranName"));
    appiumCommands.click("FirstProduct");

  }

  public void clickOnVariantShoreMore() {
    appiumCommands.performScroll();
    appiumCommands.click("productVariantShowmore");
  }

  public void clickOnAskAQuestionLink() {
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.click("askAQuestionLink");
  }

  public void clickOnChooseYourItemsButton() {
    appiumCommands.click("chooseYourItemsButton");
  }

  public void clickOnCollectionsViewMore() {
    appiumCommands.click("collectionsViewMore");
  }

  public void clickOnItem() {
    appiumCommands.click("selectItem");
  }

  public void clickOnAddToSet() {
    appiumCommands.click("addToSetButton");
  }

  public void clickOnViewChoices() {
    appiumCommands.click("viewChoiceButton");
  }

  public void clickOnDeleteItem() {
    appiumCommands.click("choiceDeleteButton");
  }

  public void clickCloseYourChoice() {
    appiumCommands.click("yourChoiceClose");
  }

  public void clickOnProductVariant() {appiumCommands.click("selectVariant");appiumCommands.customWait(FrameworkConstants.longWait);
  }
  public void clickOnreviewFilterButton() {
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.customWait(2);
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.customWait(3);
    appiumCommands.click("reviewFilterButton");
  }

public void clickOnReviewHelpFull() {
  appiumCommands.performScroll();
  appiumCommands.performScroll();
  appiumCommands.performScroll();
  appiumCommands.performScroll();
  appiumCommands.customWait(2);
  appiumCommands.performScroll();
  appiumCommands.performScroll();
  appiumCommands.performScroll();
  appiumCommands.performScroll();
  appiumCommands.performScroll();
  appiumCommands.customWait(3);
  appiumCommands.performScroll();
  appiumCommands.click("firstreviewHelpFull");
}

  public void clickOnReviewNotHelpFull() {
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.customWait(2);
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.customWait(3);
    appiumCommands.click("firstReviewNotHelpFull");
  }


  public void clickOnSeeAllReview() {
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.customWait(2);
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.customWait(3);
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.click("seeAllReviewButton");
  }

  public void clickOnSellQuestionButton() {
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.customWait(1);
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.customWait(3);
    appiumCommands.performScroll();
    appiumCommands.customWait(1);
    appiumCommands.performScroll();
    if (appiumCommands.checkElementIsVisibleOnPage("sellAllQuestionsButtonn")) {
      appiumCommands.click("sellAllQuestionsButtonn");
    }
    else {
      System.out.println("Questions Not Visible");
    }
  }
  public void clickOnWriteAReview() {
    appiumCommands.click("writeAReview");
  }

  public void clickOnReviewSearch() {
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.customWait(2);
    appiumCommands.performScroll();
    appiumCommands.customWait(2);
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.click("searcReviewIcon");
  }

  public void clickReviewNextButton() {
    appiumCommands.click("writeAReviewNextButton");
  }

  public void scrollProductImage() {
    Actions actions = new Actions(driver);
    actions.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB).perform();
    appiumCommands.customWait(1);
    actions.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB).perform();
  appiumCommands.customWait(1);
    actions.sendKeys(Keys.ARROW_LEFT).perform();
  }
  public void pagescroll(){
    appiumCommands.performScroll();
  }
  public void quantity(){
    appiumCommands.click("Quantity");
  }
  public void increaseQuantity(){
    appiumCommands.click("QuantityIncrease");
  }
  public void productclick(){
    appiumCommands.click("ProcuctEnter");
  }

  public void productsscroll(){
    appiumCommands.performScroll();
  }

  public void Clickproduct() {
    if (appiumCommands.checkElementIsVisibleOnPage("VerifyProductName")) {
      appiumCommands.click("VerifyProductName");
    }
    else {
      appiumCommands.performScroll();
      appiumCommands.click("VerifyProductName");
    }
  }
  public void pageup(){
    appiumCommands.performScroll();
    appiumCommands.performScroll();
  }

  public void notifyme() {
    if (appiumCommands.checkElementIsVisibleOnPage("ManageNot")) {
      appiumCommands.click("ManageNot");
      appiumCommands.click("complete");
      appiumCommands.click("Gotit");
      appiumCommands.click("Notifyme");
      appiumCommands.click("complete");
      //driver.navigate().back();
      //appiumCommands.click("Notifyme");
    } else if (appiumCommands.checkElementIsVisibleOnPage("Notifyme")) {
      appiumCommands.click("Notifyme");
      appiumCommands.click("complete");
    }
    else {
      System.out.println("Product inStock");
    }



  }
  public void Unsubscribe(){
    if (appiumCommands.checkElementIsVisibleOnPage("Notifyme")) {
      appiumCommands.click("Notifyme");
      appiumCommands.click("complete");
      appiumCommands.click("Gotit");
      appiumCommands.click("ManageNot");

      //driver.navigate().back();
      //appiumCommands.click("Notifyme");
    } else if (appiumCommands.checkElementIsVisibleOnPage("ManageNot")) {
      appiumCommands.click("ManageNot");
     appiumCommands.click("complete");
      //System.out.println("OutofStockDisplayed");

    }
    else {
      System.out.println("Product inStock");
    }
  }
public void ClickonShipping(){
    appiumCommands.customWait(FrameworkConstants.longWait);
    appiumCommands.performScroll();
    appiumCommands.click("ShippingOption");
    if(appiumCommands.checkElementIsVisibleOnPage("ShippingOption")){
      appiumCommands.click("GetShipping");
    }
    else {
      appiumCommands.click("GetShipping");
    }
}



}
