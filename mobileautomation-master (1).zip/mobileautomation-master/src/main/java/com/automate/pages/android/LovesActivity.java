package com.automate.pages.android;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class LovesActivity {

  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public LovesActivity(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("android/LovesActivity.csv");
    util.readDataFile("android/LovesActivitydata.csv");
    //util.readDataFile("MeActivityData.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }

  public void clickOnSortButton() {
    appiumCommands.click("sortButton");
  }

  public void clickOnSortMostRecent() {
    appiumCommands.click("sortMostRecent");
  }

  public void clickOnSortBrandNameAToZ() {
    appiumCommands.click("sortBrandNameAToZ");
  }

  public void clickOnSortBrandNameZToA() {
    appiumCommands.click("sortBrandNameZToA");
  }

  public void clickOnSortPriceLowToHigh() {
    appiumCommands.click("sortPriceLowToHigh");
  }

  public void clickOnSortPriceHighToLow() {
    appiumCommands.click("sortPriceHighToLow");
  }

  public void clicksearchbar() {
    appiumCommands.click("clickonsearchbar");
  }

  public void searchproduct(int i) {
    appiumCommands.click("Searchbox");
    appiumCommands.type("Searchbox", util.getTestCaseDataColumn(i, "productname"));
  }

  public void ClickonProductName() {appiumCommands.click("clickonproductname");

  }

  public void clickonproduct() {
    appiumCommands.click("clickonproduct");
  }

  public void clicklove() {
    appiumCommands.performScroll();
    if (appiumCommands.checkElementIsEnabledOnPage("removelove")) {
      appiumCommands.click("removelove");
      appiumCommands.click("clickonloved");
    }
    else {
      appiumCommands.click("clickonloved");
    }
  }

  public void clickonloveicon() {
    appiumCommands.click("clickonloveicon");
  }

  public void unloved() {
    appiumCommands.performScroll();
    if (appiumCommands.checkElementIsEnabledOnPage("clickonloved")) {
      appiumCommands.click("clickonloved");
      appiumCommands.click("removelove");
    }
    else {
      appiumCommands.click("removelove");
    }
  }

  public void searchbarlovedicon(){
    appiumCommands.click("clickonserchbarLoveIcon");
  }

  public void Loveaddbutton(){
    boolean status=true;
    while(status)
    {
      if (!appiumCommands.checkElementIsVisibleOnPage("AddtoLoves")){
        appiumCommands.click("clickonremoved");
        appiumCommands.click("AddtoLoves");
      }
      else {
        appiumCommands.click("AddtoLoves");
        status=false;
      }

    }
    }
    public void SearchSephora(){
    appiumCommands.click("SearchSephora");
  }
  public void manualSeachSephora(int i){
    appiumCommands.type("SearchSephoraSearchBar", util.getTestCaseDataColumn(i,"productname"));
  }
  public void manualSearchSephoraLoved(){
    appiumCommands.click("SearchSephoraloved");
  }

  public void validateStoreNameOnLovePage(String StoreName)
  {
      String text = appiumCommands.getText("InStockAtButton");
      Assert.assertTrue(text.contains(StoreName));
  }

  public void validateSort(String sortValue)
  {
    String text = appiumCommands.getText("sortButton");
    Assert.assertTrue(text.contains(sortValue));
  }
  public void sortByPriceLowToHigh() {
    List<WebElement> allList = new ArrayList<>();
    Set<String> uniqueProductPrices = new HashSet<>(); // Track unique product prices
    // Click to sort by price (low to high)
    clickOnSortButton();
    appiumCommands.customWait(FrameworkConstants.quickWait);
    clickOnSortPriceLowToHigh();
    // Find elements before scrolling
    List<WebElement> sortedProductsPriceBeforeScroll = util.findElements("productPrice");
    allList.addAll(sortedProductsPriceBeforeScroll);
    for (WebElement product : sortedProductsPriceBeforeScroll) {
      String productPrice = product.getText().replace("$", "");
      if (!uniqueProductPrices.contains(productPrice)) {
        uniqueProductPrices.add(productPrice);
      }
    }
    // Perform scroll actions
    //appiumCommands.performScroll();
    //appiumCommands.performScroll();
    // Find elements after scrolling
    List<WebElement> sortedProductsPriceAfterScroll = util.findElements("productPrice");
    allList.addAll(sortedProductsPriceAfterScroll);
    for (WebElement product : sortedProductsPriceAfterScroll) {
      String productPrice = product.getText().replace("$", "");
      if (!uniqueProductPrices.contains(productPrice)) {
        uniqueProductPrices.add(productPrice);
      }
    }
    // Validating sorting order for price (Low to High)
    List<String> allProductPrices = new ArrayList<>(uniqueProductPrices);
    Collections.sort(allProductPrices); // Sort the unique prices

    for (int i = 0; i < allProductPrices.size() - 1; i++) {
      if (allProductPrices.get(i).compareTo(allProductPrices.get(i + 1)) > 0) {
        throw new RuntimeException("Sorting order is incorrect for Price Low To High. Test case stopped");
      }
    }
    // Output success message if sorting is correct
    System.out.println("Products are sorted correctly for Price Low To High");
  }



  public void validateSortingOrderHighToLow() {
    List<WebElement> allList = new ArrayList<>();
    Set<String> uniqueProductPrices = new HashSet<>(); // Track unique product prices
    // Click to sort by price (high to low)
    clickOnSortButton();
    clickOnSortPriceHighToLow();
    // Find elements before scrolling
    List<WebElement> sortedProductsPriceBeforeScroll = util.findElements("productPrice");
    allList.addAll(sortedProductsPriceBeforeScroll);
    for (WebElement product : sortedProductsPriceBeforeScroll) {
      String productPrice = product.getText().replace("$", "");
      if (!uniqueProductPrices.contains(productPrice)) {
        uniqueProductPrices.add(productPrice);
      }
    }
    // Perform scroll actions
    //appiumCommands.performScroll();
    //appiumCommands.performScroll();
    // Find elements after scrolling
    List<WebElement> sortedProductsPriceAfterScroll = util.findElements("productPrice");
    allList.addAll(sortedProductsPriceAfterScroll);
    for (WebElement product : sortedProductsPriceAfterScroll) {
      String productPrice = product.getText().replace("$", "");
      if (!uniqueProductPrices.contains(productPrice)) {
        uniqueProductPrices.add(productPrice);
      }
    }
    // Validating sorting order for price (High to Low)
    List<String> allProductPrices = new ArrayList<>(uniqueProductPrices);
    Collections.sort(allProductPrices, Collections.reverseOrder()); // Sort the unique prices in descending order
    for (int i = 0; i < allProductPrices.size() - 1; i++) {
      if (allProductPrices.get(i).compareTo(allProductPrices.get(i + 1)) < 0) {
        throw new RuntimeException("Sorting order is incorrect for Price High To Low. Test case stopped");
      }
    }
    // Output success message if sorting is correct
    System.out.println("Products are sorted correctly for Price High To Low");
  }

  public void validateSortingOrderAtoZ() {
    List<WebElement> allList = new ArrayList<>();
    // Click to sort by product names (A to Z)
    clickOnSortButton();
    clickOnSortBrandNameAToZ();
    // Find elements before scrolling
    List<WebElement> sortedProductsBeforeScroll = util.findElements("brandName");
    allList.addAll(sortedProductsBeforeScroll);
    List<String> productNamesBeforeScroll = new ArrayList<>();
    for (WebElement product : sortedProductsBeforeScroll) {
      productNamesBeforeScroll.add(product.getText());
    }
    // Perform scroll actions
   // appiumCommands.performScroll();
   // appiumCommands.performScroll();
    // Find elements after scrolling
    List<WebElement> sortedProductsAfterScroll = util.findElements("brandName");
    allList.addAll(sortedProductsAfterScroll);
    List<String> productNamesAfterScroll = new ArrayList<>();
    for (WebElement product : sortedProductsAfterScroll) {
      productNamesAfterScroll.add(product.getText());
    }
    // Combine names before and after scroll for comparison
    List<String> allProductNames = new ArrayList<>(productNamesBeforeScroll);
    allProductNames.addAll(productNamesAfterScroll);
    // Validating sorting order for product names (A to Z)
    Collections.sort(allProductNames); // Sort the combined names
    for (int i = 0; i < allProductNames.size() - 1; i++) {
      if (allProductNames.get(i).compareTo(allProductNames.get(i + 1)) > 0) {
        throw new RuntimeException("Sorting order is incorrect from A to Z. Test case stopped.");
      }
    }
    // Output success message if sorting is correct
    System.out.println("Products are sorted correctly from A to Z.");
  }

  public void validateSortingOrderZtoA() {
    List<WebElement> allList = new ArrayList<>();
    // Click to sort by product names (Z to A)
    clickOnSortButton();
    clickOnSortBrandNameZToA();
    // Find elements before scrolling
    List<WebElement> sortedProductsBeforeScroll = util.findElements("brandName");
    allList.addAll(sortedProductsBeforeScroll);
    List<String> productNamesBeforeScroll = new ArrayList<>();
    for (WebElement product : sortedProductsBeforeScroll) {
      productNamesBeforeScroll.add(product.getText());
    }
    // Perform scroll actions
    //appiumCommands.performScroll();
    //appiumCommands.performScroll();
    // Find elements after scrolling
    List<WebElement> sortedProductsAfterScroll = util.findElements("brandName");
    allList.addAll(sortedProductsAfterScroll);
    List<String> productNamesAfterScroll = new ArrayList<>();
    for (WebElement product : sortedProductsAfterScroll) {
      productNamesAfterScroll.add(product.getText());
    }
    // Combine names before and after scroll for comparison
    List<String> allProductNames = new ArrayList<>(productNamesBeforeScroll);
    allProductNames.addAll(productNamesAfterScroll);
    // Validating sorting order for product names (Z to A)
    Collections.sort(allProductNames, Collections.reverseOrder()); // Sort the combined names in descending order

    for (int i = 0; i < allProductNames.size() - 1; i++) {
      if (allProductNames.get(i).compareTo(allProductNames.get(i + 1)) < 0) {
        throw new RuntimeException("Sorting order is incorrect from Z to A. Test case stopped.");
      }
    }
    // Output success message if sorting is correct
    System.out.println("Products are sorted correctly from Z to A");
  }

  public void validateSortDropdown() {
    clickOnSortButton();
    List<WebElement> elemts = util.findElements("verifySortDropdown");
    for(int i=0;i< elemts.size();i++){
      String elementText = elemts.get(i).getText();
      Assert.assertEquals(elementText,util.getTestCaseDataColumn(i,"VerifySortDropdown"));
    }

  }

  public void Share(){
    appiumCommands.click("Share");
  }

  public void sort(){
   appiumCommands.click("SortClick");
  }
  public void sortoption(){
  appiumCommands.click("sortOption");
  }
}

