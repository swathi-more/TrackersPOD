package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class CreateAccountIOS {


  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public CreateAccountIOS(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("ios/CreateAccount.csv");
    // util.readDataFile("StoresActivityData.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }

  public void enterEmailAddress(String email)
  {
    appiumCommands.type("emailTextField",email);
  }

  public void clickOnDoneButton()
  {
    appiumCommands.click("doneButton");
  }

  public void enterFirstName(String firstName)
  {
    appiumCommands.type("firstName",firstName);
  }

  public void enterLastName(String lastName)
  {
    appiumCommands.type("lastName",lastName);
  }

  public void enterPassword(String password)
  {
    appiumCommands.type("password",password);
  }

  public void enterPhoneNumber(String phoneNumber)
  {
    appiumCommands.type("phoneNumber",phoneNumber);
  }

  public void checkSignMeMarketingAlert()
  {
    appiumCommands.click("signMeMarketingAlert");
  }

  public void checkSubscribeSephoraEmail()
  {
    appiumCommands.click("subscribeSephoraEmail");
  }

  public void clickOnJoinNowButton()
  {
    appiumCommands.click("joinNowButton");
  }

  public void clickOnCloseButtonPostRegistration()
  {
    appiumCommands.click("closeButtonPostRegistration");
  }


  public void registerUserWithDefaultValues()
  {
    String email = "sephora_auto_"+ util.getSaltString()+"@yopmail.com";
    enterEmailAddress(email);

    // click on done
    clickOnDoneButton();

    // enter username
    enterFirstName("Automation");

    // enter lastname
    enterLastName("Test");

    // enter password
    enterPassword("Sephoral@123");

    // scrolling to reach join now button
    appiumCommands.performScroll();
    appiumCommands.performScroll();

    clickOnJoinNowButton();

  }

}
