package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.io.IOException;

public class ProductsPageIOS {


	private static final Logger logger = LogManager.getLogger(ProductsPageIOS.class);
	AppiumDriver driver;
	ServiceLocator service = ServiceLocator.getInstance();
	Util util;
	AppiumCommands appiumCommands;

	public ProductsPageIOS(AppiumDriver driver) throws IOException, CsvException {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		util = new Util(driver);
    util.readCSV("ios/ProductsPage.csv");
		appiumCommands = new AppiumCommands(driver, util);
	}
  public void userSelectTheProduct(){
    if(appiumCommands.checkElementIsVisibleOnPage("FirstProduct")){
      appiumCommands.click("FirstProduct");
    }
  }

  public void clickOnVariantShoreMore() {
    appiumCommands.performScroll();
    appiumCommands.click("productVariantShowmore");
  }

  public void clickOnAskAQuestionLink() {
    appiumCommands.customWait(FrameworkConstants.longWait);
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.click("askAQuestionLink");
  }

  public void clickOnChooseYourItemsButton() {
    appiumCommands.click("chooseYourItemsButton");
  }

  public void clickOnCollectionsViewMore() {
    appiumCommands.click("collectionsViewMore");
  }

  public void clickOnItem() {
    appiumCommands.click("selectItem");
  }

  public void clickOnAddToSet() {
    appiumCommands.click("addToSetButton");
  }

  public void clickOnViewChoices() {
    appiumCommands.click("viewChoiceButton");
  }

  public void clickOnDeleteItem() {
    appiumCommands.click("choiceDeleteButton");
  }

  public void clickCloseYourChoice() {
    appiumCommands.click("yourChoiceClose");
  }

  public void clickOnProductVariant() {appiumCommands.click("selectVariant");appiumCommands.customWait(FrameworkConstants.longWait);
  }
  public void clickOnreviewFilterButton() {
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.customWait(2);
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.customWait(3);
    appiumCommands.click("reviewFilterButton");
  }

public void clickOnReviewHelpFull() {
  appiumCommands.performScroll();
  appiumCommands.performScroll();
  appiumCommands.performScroll();
  appiumCommands.performScroll();
  appiumCommands.customWait(2);
  appiumCommands.performScroll();
  appiumCommands.performScroll();
  appiumCommands.performScroll();
  appiumCommands.performScroll();
  appiumCommands.performScroll();
  appiumCommands.customWait(3);
  appiumCommands.performScroll();
  appiumCommands.click("firstreviewHelpFull");
}

  public void clickOnReviewNotHelpFull() {
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.customWait(2);
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.customWait(3);
    appiumCommands.click("firstReviewNotHelpFull");
  }


  public void clickOnSeeAllReview() {
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.customWait(FrameworkConstants.quickWait);
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.customWait(FrameworkConstants.longWait);
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.click("seeAllReviewButton");
    appiumCommands.customWait(FrameworkConstants.longWait);
  }

  public void clickOnSeeAQuestionButton() {
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.click("sellAllQuestionsButtonn");
  }

  public void clickOnWriteAReview() {
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.click("writeAReview");
  }

  public void clickOnReviewSearch() {
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.customWait(2);
    appiumCommands.performScroll();
    appiumCommands.customWait(2);
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.click("searcReviewIcon");
  }

  public void clickReviewNextButton() {
    appiumCommands.click("writeAReviewNextButton");
  }

  public void scrollProductImage() {
    Actions actions = new Actions(driver);
    actions.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB).perform();
    appiumCommands.customWait(1);
    actions.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB).perform();
  appiumCommands.customWait(1);
    actions.sendKeys(Keys.ARROW_LEFT).perform();
  }
  public void pagescroll(){
    appiumCommands.performScroll();
  }
  public void quantity(){
    appiumCommands.click("Quantity");
  }
  public void increaseQuantity(){
    appiumCommands.click("QuantityIncrease");
  }
  public void productclick(){
    appiumCommands.click("ProcuctEnter");
  }

  public void clickOnFirstProduct()
  {
    appiumCommands.click("FirstProduct");
  }

  public void clickOnReviewSortDropdownButton()
  {
    appiumCommands.click("reviewSortDropdown");
  }

  public void clickOnMostHelpfulSortRadioButton()
  {
    appiumCommands.click("mostHelpfulSort");
  }

  public void clickOnShowResultButton()
  {
    appiumCommands.click("showResultButton");
  }

  public void clickOnQuestionAnswerSortButton()
  {
    appiumCommands.click("questionAnswerSortButton");
  }

  public void clickOnMostRecentAnswerOption()
  {
    appiumCommands.click("mostRecentAnswerOption");
  }

  public void clickOnSearchIconReviewPage()
  {
    appiumCommands.click("searcReviewIcon");
  }

  public void searchReview(String data) throws InterruptedException {
    appiumCommands.type("searchReviewTextBox",data);
    appiumCommands.sendKeys("searchReviewTextBox",Keys.ENTER);
  }
  public void assetWhenReviewFound()
  {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("searchReviewTextBox"));
  }

  public void assetWhenReviewNotFound()
  {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("reviewResultNull"));
  }
  public void ClickHelpful(){
    appiumCommands.click("QAndAHelpful");
  }
}
