package com.automate.pages.android;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class ProfilePage {
  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public ProfilePage(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("android/ProfilePage.csv");
    util.readDataFile("android/ProfilePageData.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }
  public void clickSignoutButton()
  {
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.click("signOutTab");
  }
  public void clickAccountTab()
  {
    appiumCommands.click("accountTab");
    appiumCommands.customWait(FrameworkConstants.quickWait);
  }

  public void clickAppSettingsTab()
  {
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.click("appSettingsTab");
  }

  public void clickReservationLink() {
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.click("reservationTab");
  }

  public void clickOnFirstReservation() {
    appiumCommands.click("firstReservationOption");
  }

  public void clickOnBeautyInsiderSummaryButton() {
    appiumCommands.click("beautyInsiderSummaryButton");
  }
}
