package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class CreateDummyStoreIOS {


  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public CreateDummyStoreIOS(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("ios/CreateDummyStoreIOS.csv");
    //util.readDataFile("MeActivityData.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }


  public void clickOnCancelButton()
  {
    appiumCommands.click("cancelButton");
  }

  public void clickOnAddButton()
  {
    appiumCommands.click("addButton");
  }

  public void clickOnStoreFormCloseButton()
  {
    appiumCommands.click("storeFormCancelButton");
  }

  public void clickOnStoreFormDoneButton()
  {
    appiumCommands.click("storeFormDoneButton");
  }

  public void clickOnEntryButton()
  {
    appiumCommands.click("entryButton");
  }

  public void enterStoreId(String storeId)
  {
    appiumCommands.type("storeId",storeId);
  }

  public void enterState(String state)
  {
    appiumCommands.type("state",state);
  }

  public void enterStoreName(String storeName)
  {
    appiumCommands.type("storeName",storeName);
  }
  public void enterCountry(String country)
  {
    appiumCommands.type("country",country);
  }
  public void enterStoreRegion(String storeRegion)
  {
    appiumCommands.type("storeRegion",storeRegion);
  }
  public void enterStoreType(String storeType)
  {
    appiumCommands.type("storeType",storeType);
  }

  public void clickOnStore(){appiumCommands.click("clickOnStore");}

  public void createDummyStore(String storeId,String storeName,String state,String country,String storeRegion,String storeType)
  {

    enterStoreId(storeId);
    enterStoreName(storeName);
    enterState(state);
    enterCountry(country);
    enterStoreRegion(storeRegion);
    enterStoreType(storeType);
    clickOnStoreFormDoneButton();
    clickOnStore();
    clickOnEntryButton();
  }

}
