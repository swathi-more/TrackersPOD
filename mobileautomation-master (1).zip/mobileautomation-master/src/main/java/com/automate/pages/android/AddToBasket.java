package com.automate.pages.android;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.io.IOException;

public class AddToBasket {

	private static final Logger logger = LogManager.getLogger(AddToBasket.class);
	AppiumDriver driver;
	ServiceLocator service = ServiceLocator.getInstance();
	Util util;
	AppiumCommands appiumCommands;

	public AddToBasket(AppiumDriver driver) throws IOException, CsvException {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		util = new Util(driver);
		util.readCSV("android/AddToBasket.csv");
    util.readDataFile("android/AddToBasketData.csv");
		appiumCommands = new AppiumCommands(driver, util);
	}

	public void verifySelectedProduct() {
		if (appiumCommands.checkElementIsVisibleOnPage("scrollDownPopup")) {
			appiumCommands.click("scrollDownPopup");
		}
    appiumCommands.customWait(FrameworkConstants.quickWait);
	/*	Assert.assertEquals(util.getSessionMap("ProductName"), appiumCommands.getText("verifyProductName"));
		Assert.assertEquals(util.getSessionMap("ProductBrandName"), appiumCommands.getText("verifyBrandName"));
		util.setSessionMap("ProductName", appiumCommands.getText("verifyProductName"));
		util.setSessionMap("ProductBrandName", appiumCommands.getText("verifyBrandName"));*/

	}
	
	public void clickOnShopAllFromThisBrand() {
		appiumCommands.scrollToViewElement("shopAllFromThisBrand");
		appiumCommands.click("shopAllFromThisBrand");
		appiumCommands.checkElementIsNotVisibleOnPage("shopAllFromThisBrand");
	}
	
	public void clickOnVariantText() {
		appiumCommands.click("variantText");
	}
	
	public void clickOnShippingOption() {
		appiumCommands.click("shippingOption");
	}

	public void clickOnAddToBasketQuantityButton() {
		appiumCommands.click("addToBasketSelectQuantityButton");
	}
	
	public void clickOnAddToBasketQuantity() {
		appiumCommands.click("addToBasketQuantity");
	}

	public void clickOnAddToBasketButton() {
    appiumCommands.customWait(FrameworkConstants.longWait);
    appiumCommands.performScroll();
		appiumCommands.click("addToBasketButton");
	}

  public void clickOnBuyOnlineAndPickupLink(){
    if (appiumCommands.checkElementIsVisibleOnPage("scrollDownPopup")) {
      appiumCommands.click("scrollDownPopup");
    }
    appiumCommands.performScroll();
    appiumCommands.click("buyOnlineAndPickupLink");
  }

  public void clickOnCheckOtherStoresLink(){
    appiumCommands.click("checkOtherStoresLink");

  }

  public void clickOnViewSimilarProductsText() {
    if (appiumCommands.checkElementIsVisibleOnPage("scrollDownPopup")) {
      appiumCommands.click("scrollDownPopup");
    }
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.click("similarProductsText");
  }

  public void clickAndVerifySameDayDelivery(int i) {
    if (appiumCommands.checkElementIsVisibleOnPage("scrollDownPopup")) {
      appiumCommands.click("scrollDownPopup");
    }
    appiumCommands.performScroll();
    appiumCommands.click("sameDayDeliver");appiumCommands.customWait(FrameworkConstants.quickWait);
    if(appiumCommands.checkElementIsVisibleOnPage("sameDayDeliveryNotAvailable")){
      appiumCommands.click("sameDayDeliveryNotAvailable");
      appiumCommands.click("changeLocationLink");appiumCommands.customWait(FrameworkConstants.quickWait);
      appiumCommands.type("zipCodeTxtField",util.getTestCaseDataColumn(i,"SameDayDeliveryZipCode"));
      appiumCommands.customWait(FrameworkConstants.quickWait);
      appiumCommands.click("confirmButton");appiumCommands.customWait(FrameworkConstants.quickWait);
      if(appiumCommands.checkElementIsVisibleOnPage("okButton")){
        appiumCommands.click("okButton");appiumCommands.customWait(FrameworkConstants.quickWait);
      }
    }
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("orderTiming"));
  }
  public void verifyScrollDropDown(){
    if (appiumCommands.checkElementIsVisibleOnPage("scrollDownPopup")) {
      appiumCommands.click("scrollDownPopup");
    }
  }
}
