package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import io.reactivex.internal.operators.flowable.FlowableRange;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class SDUForm {

  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public SDUForm(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("ios/SDUForm.csv");
    util.readDataFile("ios/SDUFormData.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }

  public void clickCancelButton()
  {
      appiumCommands.click("sdu_addcardCancelButton");
  }


  public void addNewCard(int i) throws InterruptedException {

      appiumCommands.type("cardNumber",util.getTestCaseDataColumn(1,"cardNumber"));
      appiumCommands.type("securityCode",util.getTestCaseDataColumn(i,"securityCode"));

      appiumCommands.click("expiryDate");
      appiumCommands.type("expiryDateYear",util.getTestCaseDataColumn(i,"expiryDate"));
      appiumCommands.sendKeys("expiryDateYear",Keys.ENTER);

      appiumCommands.type("firstName",util.getTestCaseDataColumn(i,"firstName"));
      appiumCommands.type("lastName",util.getTestCaseDataColumn(i,"lastName"));
      appiumCommands.type("phone",util.getTestCaseDataColumn(i,"phone"));

      appiumCommands.performScroll();
      appiumCommands.performScroll();

      appiumCommands.type("address",util.getTestCaseDataColumn(i,"address"));

      appiumCommands.type("zipcode",util.getTestCaseDataColumn(i,"zipcode"));

      appiumCommands.type("city",util.getTestCaseDataColumn(i,"city"));
  }

  public void clickOnSave()
  {
    appiumCommands.click("sdu_addCardSaveButton");
  }

  public void deleteCard()
  {
    appiumCommands.performScroll();
    appiumCommands.click("deleteCard");

  }

}
