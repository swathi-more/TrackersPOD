package com.automate.pages.android;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class AllGroupsActivity {


	private static final Logger logger = LogManager.getLogger(AllGroupsActivity.class);
	AppiumDriver driver;
	ServiceLocator service = ServiceLocator.getInstance();
	Util util;
	AppiumCommands appiumCommands;

	public AllGroupsActivity(AppiumDriver driver) throws IOException, CsvException {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		util = new Util(driver);
    util.readCSV("android/AllGroupsActivityPage.csv");
    util.readDataFile("android/AllGroupsActivityPageData.csv");
		appiumCommands = new AppiumCommands(driver, util);
	}
  public void joinGroup(){
    appiumCommands.click("JoinButton");
    appiumCommands.customWait(3);
  }
  public void leaveGroup(){
    appiumCommands.click("MemberButton");
  }
  public void clickOnMyGroupsButton(){
    appiumCommands.click("MyGroupsButton");

  }

  public void enterNickName(int i) {
    appiumCommands.type("nickNameInputTextField",util.getTestCaseDataColumn(i,"NickName"));
  }

  public void clickOnJoinAndContinueButton() {
    appiumCommands.click("joinAndContinueButton");
  }
  public void clickOnAllGroupsButton() {
    appiumCommands.click("allGroupsButton");
  }
  public void selectGroup() {
    appiumCommands.click("selectJoinedGroup");
  }

  public void clickOnStartAConversation() {
    appiumCommands.click("startAConversation");
  }
}
