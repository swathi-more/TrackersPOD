package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import javax.swing.text.html.HTMLDocument;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class LoveActivity {

	AppiumDriver driver;
	ServiceLocator service = ServiceLocator.getInstance();
	Util util;
	AppiumCommands appiumCommands;

	public LoveActivity(AppiumDriver driver) throws IOException, CsvException {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		util = new Util(driver);
		util.readCSV("ios/LoveActivity.csv");
		util.readDataFile("ios/LoveActivityData.csv");
		appiumCommands = new AppiumCommands(driver, util);
	}

	public void IconLove() {
		appiumCommands.click("LoveIcon");
	}

	public void removeAll() {
		boolean status = true;
		while (status) {
			if (appiumCommands.checkElementIsVisibleOnPage("RemoveFromLove")) {
				appiumCommands.click("RemoveFromLove");
			} else {
				status = false;
			}
		}
	}

	public void ProductName(int i) {
		appiumCommands.type("ClickSearchBar", util.getTestCaseDataColumn(i, "ProductName"));
	}

	public void ClickonproductName() {
		appiumCommands.click("ClickOnProductName");
		boolean status = true;
		while (status) {
			if (!appiumCommands.checkElementIsVisibleOnPage("VerifyLipsticksVisible")) {
				appiumCommands.click("SearchSymbole");
				appiumCommands.click("ClickOnProductName");
			} else {
				status = false;
			}
		}
	}

	public void Clickonproduct() {
		boolean status = true;
		while (status) {
			if (appiumCommands.checkElementIsVisibleOnPage("ClickOnProduct")) {
				appiumCommands.click("ClickOnProduct");
				status = false;
			} else {
				appiumCommands.performScroll();
			}

		}

	}

	public void ProductScroll() {
		appiumCommands.customWait(6);
		appiumCommands.performScroll();
	}

	public void addwish() {
		if (appiumCommands.checkElementIsVisibleOnPage("RemoveFromwish")) {
			appiumCommands.click("RemoveFromwish");
			appiumCommands.click("AddtoWish");
			appiumCommands.checkElementIsVisibleOnPage("RemoveFromwish");
		} else {
			appiumCommands.click("AddtoWish");
			appiumCommands.checkElementIsVisibleOnPage("RemoveFromwish");
		}

	}

	public void Loveshare() {
		appiumCommands.click("LoveShare");
	}

	public void ListSort() {
		appiumCommands.click("SortList");
	}

	public void chooseSort() {
		appiumCommands.click("ChooseSort");
	}

	public void clickRemove() {
		appiumCommands.click("RemoveFromLove");
	}

	public void AddButton() {
		appiumCommands.click("AddToLoveButton");

	}

	public void ManuallySearch() {
		appiumCommands.click("SearchManual");
	}

	public void clickOnAddLoveSearchButton() {
		appiumCommands.click("searchAddLove");

	}
}
