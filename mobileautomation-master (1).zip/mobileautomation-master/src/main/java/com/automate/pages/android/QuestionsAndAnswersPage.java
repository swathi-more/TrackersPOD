package com.automate.pages.android;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class QuestionsAndAnswersPage {


  private static final Logger logger = LogManager.getLogger(ProductsPage.class);
  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public QuestionsAndAnswersPage(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("android/QuestionsAndAnswersPage.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }


  public void clickOnAnswersQuestion() {
    appiumCommands.click("answerQuestion");
  }

  public void clickSortQuestionsDropDown() {
    appiumCommands.click("sortQuestionsDropDown");
  }

  public void typeAnswer() {
    appiumCommands.type("answerInputField",appiumCommands.generateRandomString(40));
  }

  public void clickOnSubmitAnswer() {
    appiumCommands.performScroll();
    appiumCommands.click("answerSubmitButton");
  }

  public void selectReceivedSample() {
    Actions actions = new Actions(driver);
    actions.sendKeys(Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.ENTER).perform();
  }

  public void checkTerms() {
    Actions actions = new Actions(driver);
    actions.sendKeys(Keys.TAB,Keys.ENTER).perform();
  }

  public void clickOnAnswerDoneButton(){
    appiumCommands.click("answerSubmitDoneButton");
  }


    public void clickOnHelpFullLink() {
    appiumCommands.click("helpFullLink");appiumCommands.customWait(FrameworkConstants.quickWait);
    }
}
