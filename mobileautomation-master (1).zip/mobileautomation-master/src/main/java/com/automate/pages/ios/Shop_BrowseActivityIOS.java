package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class Shop_BrowseActivityIOS {


	private static final Logger logger = LogManager.getLogger(Shop_BrowseActivityIOS.class);
	AppiumDriver driver;
	ServiceLocator service = ServiceLocator.getInstance();
	Util util;
	AppiumCommands appiumCommands;

	public Shop_BrowseActivityIOS(AppiumDriver driver) throws IOException, CsvException {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		util = new Util(driver);
    util.readCSV("ios/Shop_BrowseActivity.csv");
		appiumCommands = new AppiumCommands(driver, util);
	}
  public void clickOnBestSellerLink(){
    appiumCommands.performScroll();
    appiumCommands.click("bestSellerLink");
  }
}
