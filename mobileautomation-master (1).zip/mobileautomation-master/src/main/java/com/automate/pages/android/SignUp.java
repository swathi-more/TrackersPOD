package com.automate.pages.android;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.io.IOException;

public class SignUp {


  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public SignUp(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("android/signIn.csv");
    util.readDataFile("android/SignInData.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }


  public void enterEmail(int i)
  {
    appiumCommands.type("email",util.getTestCaseDataColumn(i,"User_Email"));
  }

  public void enterPassword(int i)
  {
    appiumCommands.type("password",util.getTestCaseDataColumn(i,"User_Passowrd"));
  }

  public void enterInvalidEmail(int i)
  {
    appiumCommands.type("email",util.getTestCaseDataColumn(i,"InvalidEmail"));
  }

  public void enterInvalidPassword(int i)
  {
    appiumCommands.type("password",util.getTestCaseDataColumn(i,"InvalidPassword"));
  }


  public void clickOnSignInButton()
  {
    appiumCommands.click("signInButton");
  }

public  void clickOnSignInLink(){appiumCommands.click("signInLink");}
  public void login(int i)
  {
      enterEmail(i);
      enterPassword(i);
      clickOnSignInButton();
  }
  public void clickforgott(){
    appiumCommands.click("forgotPass");
  }
  public void clicksendmail(){
    appiumCommands.click("SendEmail");
  }
  public void resetpass(){
    appiumCommands.click("ResetPass");
  }
  public void emailsentok(){
    appiumCommands.click("emailsentok");
  }

  public void clickOnCreateNewAccountLink()
  {
    appiumCommands.click("createNewAccountLink");
  }

  public void clickOnCreateAccountButton() {
    appiumCommands.click("CreateAccountButton");
  }

  public void Resend(){
    appiumCommands.click("ResendMail");
  }

  public void clickOnSignInErrorOKButton()
  {
    appiumCommands.click("signInErrorOKButton");
  }
}
