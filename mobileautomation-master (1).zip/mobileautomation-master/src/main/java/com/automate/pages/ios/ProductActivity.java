package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.customannotations.FrameworkAnnotation;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;
import java.io.IOException;

public class ProductActivity {

  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public ProductActivity(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("ios/ProductActivity.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }

   public void ClickOutOfStockProduct(){
     boolean status=true;
     while (status){
       if(appiumCommands.checkElementIsVisibleOnPage("OutofStockProduct")){
         appiumCommands.click("OutofStockProduct");
         status=false;
       }
       else {
        appiumCommands.performScroll();
       }
     }


     }
     public void ClickOnStockButton(){

          appiumCommands.performScroll();
         if (appiumCommands.checkElementIsVisibleOnPage("ManageStock")) {
           appiumCommands.click("ManageStock");
           appiumCommands.click("StopMail");
           appiumCommands.click("GotIt");
           appiumCommands.click("OutofStockButton");
           appiumCommands.click("Continue");
           appiumCommands.click("GotIt");
           //driver.navigate().back();
           //appiumCommands.click("Notifyme");
         } else if (appiumCommands.checkElementIsVisibleOnPage("OutofStockButton")) {
           appiumCommands.click("OutofStockButton");
           appiumCommands.click("Continue");
           appiumCommands.click("GotIt");
           System.out.println("OutofStockDisplayed");

         }
         else {
           System.out.println("Product inStock");
         }



       }
       public void Unsubscribe(){
         appiumCommands.performScroll();
         if (appiumCommands.checkElementIsVisibleOnPage("OutofStockButton")) {
           appiumCommands.click("OutofStockButton");
           appiumCommands.click("Continue");
           appiumCommands.click("GotIt");
           appiumCommands.click("ManageStock");
           appiumCommands.click("StopMail");

           //driver.navigate().back();
           //appiumCommands.click("Notifyme");
         } else if (appiumCommands.checkElementIsVisibleOnPage("ManageStock")) {
           appiumCommands.click("ManageStock");
           appiumCommands.click("StopMail");
           appiumCommands.click("GotIt");
           //System.out.println("OutofStockDisplayed");

         }
         else {
           System.out.println("Product inStock");
         }


       }

       public void ClickOnQuantityICon(){
    appiumCommands.customWait(4);
       appiumCommands.performScroll();
       appiumCommands.click("Quantity");
       }
       public void Quantity(){
       WebElement Wheel= util.findElement("SelectQuantity");
       Wheel.sendKeys("2");
       appiumCommands.customWait(FrameworkConstants.quickWait);
       appiumCommands.click("doneButton");
         appiumCommands.customWait(FrameworkConstants.longWait);
         }

         public void showAll(){
    appiumCommands.performScroll();
    appiumCommands.click("ShowAll");
         }
         public void ClickShipping(){
    appiumCommands.customWait(4);
    appiumCommands.performScroll();
    appiumCommands.click("ChooseShipping");
    appiumCommands.customWait(FrameworkConstants.longWait);
         }
 public void ClickonSuggetionName(){
    appiumCommands.click("ProductNameSuggetion");
   boolean status=true;
   while (status){
     if(!appiumCommands.checkElementIsVisibleOnPage("VerifyProductNames")){
       appiumCommands.click("SearchSymbole");
       appiumCommands.click("ProductNameSuggetion");
     }
     else {
       status=false;
     }
   }
}

public void SwipeImages(){
 appiumCommands.performScroll();
 appiumCommands.performScrollBottomToUp();
  Actions actions= new Actions(driver);
  WebElement imageSlider= util.findElement("ImageSwipe");
  actions.clickAndHold(imageSlider).moveByOffset(200, 0) .perform();
  }
}




