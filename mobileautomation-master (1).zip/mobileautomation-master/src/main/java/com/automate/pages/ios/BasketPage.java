package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.io.IOException;
import java.util.List;

public class BasketPage {

  private static final Logger logger = LogManager.getLogger(BasketPage.class);
  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public BasketPage(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("ios/BasketPage.csv");
    util.readDataFile("ios/BasketPageAddressdataIos.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }

  public void verifyProductDetails() {
    Assert.assertEquals(util.getSessionMap("ProductName"), appiumCommands.getText("verifyCartProductName"));
  }

  public void clickOnCheckoutButton() {
    appiumCommands.click("checkoutButton");
  }

  public void verifyCheckoutButton() {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("checkoutButton"));
  }

  public void removeExistingProducts() {
    if (appiumCommands.checkElementIsVisibleOnPage("productsRemoveButton")) {
      List<WebElement> removeButton = util.findElements("productsRemoveButton");
      for (WebElement element : removeButton)
        appiumCommands.click("productsRemoveButton");
    }
  }

  public void verifySephoraCreditCardProgram() {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("sephoraCreditCardProgramText"));
  }

  public void verifyAndClickOnSeeDetailsButton() {
    appiumCommands.click("seeDetailsButton");
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("verifyCreditCardPage"));
  }

  public void verifyAndClickOnFreeSamplesLink() {
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.customWait(3);
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("FreeSamplesLink"));
    appiumCommands.click("FreeSamplesLink");
  }

  public void verifySelectSamplesPage() {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("verifySelectSamplesPage"));
  }

  public void clickOnSampleAddToBasketButton() {
    appiumCommands.click("selectSampleAddToBasketBtn");
  }

  public void clickOnDoneButton() {
    appiumCommands.click("DoneButton");
  }

  public void navigateBack() {
    driver.navigate().back();
  }

  public void clickOnAddPromoCodeLink() {
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.click("AddPromoCodeLink");
  }

  public void ShiptToAdd() {
    appiumCommands.click("ShiptToAdd");
  }

  public void SuggAddress() {
    appiumCommands.click("SuggAddress");
  }

  public void Addedit() {
    appiumCommands.click("AddEdit");
  }

  public void phonenumber(int i) {
    appiumCommands.click("phone");
    appiumCommands.type("phone", util.getTestCaseDataColumn(i, "phone"));

  }

  public void address(int i) {
    // appiumCommands.click("address");
    appiumCommands.type("address", util.getTestCaseDataColumn(i, "address"));
  }

  public void zipcode(int i) {
    // appiumCommands.click("zipbox");
    appiumCommands.type("zipbox", util.getTestCaseDataColumn(i, "EditZip"));
  }

  public void cityclick(int i) {
    // appiumCommands.customWait(4);
    appiumCommands.type("cityclick", util.getTestCaseDataColumn(i, "City"));
  }

  public void State() {
    appiumCommands.click("State");
  }

  public void statescroll() {
    appiumCommands.performScroll();
  }

  public void StateCA() {
    appiumCommands.click("StateCA");
  }

  public void AdddressDone() {
    appiumCommands.click("DoneAddress");
  }

  public void UseTheAddressIEntered() {
    appiumCommands.click("UseMyEnteredAddress");
  }

  public void SelectNearLocation() {
    appiumCommands.click("SelectNearLocation");
  }

  public void checkBox() {
    appiumCommands.click("CheckboxRecomendedAdd");
  }

  public void choosethisLocation() {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("ChooseThisLocation"));
    appiumCommands.click("ChooseThisLocation");
  }
  public void placeorderSamedelivery(){
    appiumCommands.click("PlaceOrder");
  }
  public void SamedaydeliveryDone(){
    appiumCommands.click("NotificationForMsg");
    appiumCommands.click("Done");
  }
}
