package com.automate.pages.android;

import com.automate.commands.AppiumCommands;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class RateAndReviewPage {


  private static final Logger logger = LogManager.getLogger(ProductsPage.class);
  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public RateAndReviewPage(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("android/RateAndReviewPage.csv");
    util.readDataFile("android/RateAndReviewPageData.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }

  public void typeReview() {
    appiumCommands.type("reviewField",appiumCommands.generateRandomString(200));
    appiumCommands.click("headLineField");
  }

  public void selectStars() {
  appiumCommands.type("ratingStars","2");
  }

  public void selectNoSuggestion() {
    Actions actions = new Actions(driver);
    actions.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.ENTER).perform();

  }

  public void selectFreeSampleCheckBox() {
    Actions actions = new Actions(driver);
    actions.sendKeys(Keys.TAB, Keys.ENTER).perform();
  }

  public void ClickOnTermsCheckBox() {
    Actions actions = new Actions(driver);
    actions.sendKeys(Keys.TAB, Keys.TAB,Keys.ENTER).perform();
  }

  public void clickOnNextButton() {
    appiumCommands.performScroll();
    appiumCommands.click("nextButton");
  }
    public void clickOnPostReviewButton() {
      appiumCommands.performScroll();
      appiumCommands.performScroll();
      appiumCommands.click("postReviewButton");
  }
}
