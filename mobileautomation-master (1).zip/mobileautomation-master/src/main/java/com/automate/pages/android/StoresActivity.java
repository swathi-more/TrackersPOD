package com.automate.pages.android;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.io.IOException;
import java.util.List;

public class  StoresActivity {

  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public StoresActivity(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("android/StoresActivity.csv");
    // util.readDataFile("StoresActivityData.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }

  public void clickOnStoreModeLink() {
    appiumCommands.click("storeModeLink");
  }

  public void clickOnFindASephoraLink() {
    appiumCommands.click("findASephoraLink");
  }

  public void clickOnStoreDetails() {
    appiumCommands.click("storeDetailsButton");
  }

  public void validateStoreName(String storeName) {
    String actualStoreName = appiumCommands.getText("storeName");

    Assert.assertEquals(actualStoreName, storeName);
  }

  public String getStoreName() {
    return appiumCommands.getText("storeNameFromInfoScreen");
  }

  public void clickOnAllTileServices() {
    appiumCommands.click("allTile_Services");
  }

  public void clickOnMakeUpTileServices() {
    appiumCommands.click("makeUpTile_Services");
  }

  public void clickOnHairTileServices() {
    appiumCommands.click("hairTile_Services");
  }

  public void clickOnWaxingTileServices() {
    appiumCommands.click("waxingTile_Services");
  }

  public void clickOnStoreModeAfterStoreIsEnabled() {
    appiumCommands.click("storeModeAfterStoreEnabled");
  }

  public void clickOnFirstEvent() {
    appiumCommands.click("firstEvent");
  }

  public void storeicon() {
    appiumCommands.click("Clickonstore");
  }

  public void clickOnViewAllLink() {
    appiumCommands.performScroll();
    appiumCommands.click("viewAllLink");
  }

  public void scrolltillview() {
    appiumCommands.performScroll();
  }

  public void checkviewall() {
    appiumCommands.click("clickonviewsevents");
  }

  public void filterbar() {
    appiumCommands.click("FilterbarforEvents");
  }

  public void clicklocation() {
    appiumCommands.click("ClickLocation");
  }

  public void suggestedadd() {
    appiumCommands.click("Suggestedadd");
  }

  public void showall() {
    appiumCommands.click("Clickonshowall");
  }

  public void verifyStoreModeHeader(String firstName) {
    String headerText[] = appiumCommands.getText("storeModeHeaderText").split("!");
    Assert.assertTrue(headerText[0].equalsIgnoreCase(firstName));
  }

  public void verifyStoreDetailsLink() {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("storeDetailsLink"));
  }

  public void verifyInsiderImage() {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("insiderImage"));
  }

  public void verifyInsiderImage_UnRecognizedUser() {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("verifyInsiderImage_UnRecognizedUser"));
  }

  public void verifyBeautyInsiderSummaryHeader() {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("beautyInsiderSummaryHeader"));
  }

  public void verifyPointsText() {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("pointsText"));
  }

  public void verifySummarySection() {
    verifyInsiderImage();
    verifyBeautyInsiderSummaryHeader();
    verifyPointsText();
  }

  public void verifyBasketCarousel() {
    if (appiumCommands.checkElementIsVisibleOnPage("basketJumpLink")) {
      appiumCommands.click("cartButton");
      Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("productsRemoveButton"));
      if (appiumCommands.checkElementIsVisibleOnPage("productsRemoveButton")) {
        List<WebElement> removeButton = util.findElements("productsRemoveButton");
        for (WebElement element : removeButton)
          appiumCommands.click("productsRemoveButton");
      }
      appiumCommands.click("storeNavigationButton");
      Assert.assertTrue(!appiumCommands.checkElementIsVisibleOnPage("basketJumpLink"));
    } else {
      appiumCommands.click("cartButton");
      Assert.assertTrue(!appiumCommands.checkElementIsVisibleOnPage("productsRemoveButton"));
      appiumCommands.click("storeNavigationButton");
      appiumCommands.click("yourLoveListCard");
      appiumCommands.click("addToBasket");
      appiumCommands.click("cartButton");
      Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("productsRemoveButton"));
    }

  }

  public void clickOnEventsJumpLink() {
    appiumCommands.click("eventsJumpLink");
  }

  public void verifyEventsDate() {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("eventsDate"));
  }

  public void verifyEventsPage() {
    verifyEventsDate();
    clickOnEventsViewAllLink();
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("verifyEventsPage"));
  }

  public void clickOnEventsViewAllLink() {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("eventsViewAllLink"));
    appiumCommands.click("eventsViewAllLink");
  }

  public void verifyServiceEventsPage() {
    appiumCommands.click("bookAServiceViewAllLink");
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("verifyServiceEventsPage"));
  }

  public void verifyEventsJumpLinkPage() {
    clickOnEventsJumpLink();
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("verifyEventsPage"));
    appiumCommands.performScrollBottomToUp();
  }

  public void verifyBeautyOffersJumpLinkPage() {
    appiumCommands.click("beautyOfferJumpLink");
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("verifyBeautyOffersPage"));
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
  }

  public void choosenForYouJumpLinkPage() {
    appiumCommands.click("chosenForYouJumpLink");
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("verifyChoosenForYouPage"));
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
  }

  public void verifyQuezzesJumpLinkPage() {
    appiumCommands.click("quizzesJumpLink");
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("verifyQuezzesPage"));
  }

  public void verifyServiceMakeUPJumpLink() {
    appiumCommands.click("serviceMakeUpJumpLink");
    Assert.assertTrue(appiumCommands.checkElementIsNotVisibleOnPage("verifyServiceMakeUpJumpLinkPage"));
    appiumCommands.performScrollBottomToUp();
  }

  public void verifyServiceSkinCareJumpLink() {
    appiumCommands.click("serviceSkinCareJumpLink");
    Assert.assertTrue(appiumCommands.checkElementIsNotVisibleOnPage("verifyServiceSkinCareJumpLinkPage"));
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
  }

  public void verifyServiceWaxingJumpLink() {
    appiumCommands.click("serviceWaxingJumpLink");
    Assert.assertTrue(appiumCommands.checkElementIsNotVisibleOnPage("verifyServiceWaxingJumpLinkPage"));
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
  }

  public void verifyServiceEventsJumpLink() {
    appiumCommands.click("serviceEventsJumpLink");
    Assert.assertTrue(appiumCommands.checkElementIsNotVisibleOnPage("verifyServiceEventsJumpLinkPage"));
  }

  public void verifyServicesJumpLinks() {
    verifyServiceMakeUPJumpLink();
    verifyServiceSkinCareJumpLink();
    verifyServiceWaxingJumpLink();
    verifyServiceEventsJumpLink();
  }
  public void scrollforEvents(){
    appiumCommands.performScroll();
  }
  public void ClickEvents() {
    appiumCommands.click("Events");
    appiumCommands.checkElementIsVisibleOnPage("VerifyEventPage");
  }
public void ViewBasket(){
  appiumCommands.click("StoreIcon");
}
public void StoreCheck(){
  if(appiumCommands.checkElementIsVisibleOnPage("REMOVE")){
    appiumCommands.click("REMOVE");
    appiumCommands.click("AgainStore");
  }
  else{
    appiumCommands.click("AgainStore");
  }
}
public void Quizzes(){
  if(appiumCommands.checkElementIsVisibleOnPage("PopUpGotit")){
     appiumCommands.click("PopUpGotit");
     appiumCommands.click("Quizzes");
}
  else {
    appiumCommands.click("Quizzes");
  }
  }


public void Need_little_guidance(){
  if(appiumCommands.checkElementIsVisibleOnPage("ValidateNeedLittle")){
    appiumCommands.click("ViewallQuiz");
  }
}
public void checkquizz(){
  appiumCommands.checkElementIsVisibleOnPage("QuizzesName");
}
public void clickQuizz(){
  appiumCommands.click("ClickonQuizz");
}
public void StartQuizz(){
  appiumCommands.click("ClickonGetStart");
}
public void ClickfirstAns(){
  appiumCommands.click("AnsFlora");
}
public void ClickSecAns(){

  appiumCommands.click("AnsFruity_Florals");

}
public void ClickThirdAns(){
  appiumCommands.click("AnsBestSeller");
}
public void CheckYouFound(){

  appiumCommands.checkElementIsVisibleOnPage("YouFoundIt");
}
  public void fragracequizz() {
    appiumCommands.click("FragranceIcon");
  }
}


