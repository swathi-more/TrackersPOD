package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class ProfileActivityIOS {

  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public ProfileActivityIOS(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("ios/ProfileActivity.csv");
    util.readDataFile("ios/MeActivityData.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }

  public void clickOnOrders()
  {
    appiumCommands.click("ordersButton");
  }

  public void clickOnBeautyInsiderSummaryLink()
  {
    appiumCommands.click("beautyInsiderSummaryButton");
  }

  public void clickOnLovesSection()
  {
    appiumCommands.click("lovesSection");
  }

  public void clickOnBeautyReferenceLink()
  {appiumCommands.click("beautyReferencesLink");}

  public void clickBeautyInsiderSummaryLink()
  {
    appiumCommands.click("beautyInsiderSummaryLink");
  }

  public void clickOnRewardsBazaarLink()
  {
    appiumCommands.click("rewardsBazaarLink");
  }

  public void clickOnBeautyInsiderChallengesLink()
  {
    appiumCommands.click("beautyInsiderChallengesLink");
  }

  public void clickOnAutoReplenishLink()
  {
    appiumCommands.click("autoReplenishLink");
  }

  public void clickOnBuyItAgainLink()
  {
    appiumCommands.click("buyItAgainLink");
  }

  public void clickOnAccountLink()
  {
    appiumCommands.click("accountLink");
  }

  public void clickOnSameDayUnlimitedLink()
  {
    appiumCommands.click("sameDayUnlimitedLink");
    }

    public void clickOnSephoraCreditCardProgramLink()
    {
      appiumCommands.click("sephoraCreditCardProgramLink");
    }

    public void clickOnFlashLink()
    {
      appiumCommands.click("flashLink");
    }

    public  void clickOnReservationsLink()
    {
      appiumCommands.click("reservationsLink");
    }

    public void clickOnSampleAndRewardsLink()
    {
      appiumCommands.click("sampleAndRewardsLink");
    }

    public void clickOnBeautyAdvisorRecommendationsLink()
    {
      appiumCommands.click("beautyAdvisorRecommendationsLink");
    }

    public void clickOnBeautyInsiderChallengesLink_1()
    {
      appiumCommands.click("beautyInsiderChallengesLink");
    }

    public void clickOnLiveBeautyHelplink()
    {
      appiumCommands.click("liveBeautyHelpLink");
    }

    public void clickOnAppSettingsLink()
    {
      appiumCommands.click("appSettingsLink");
      appiumCommands.customWait(8);
    }

    public void scrollToAppSettings()
    {
      appiumCommands.customWait(FrameworkConstants.prolongedWait);
      appiumCommands.performScroll();
      appiumCommands.performScroll();
      appiumCommands.performScroll();
      appiumCommands.performScroll();
    }
    
	public void clickOnYourLocationDropdown() {
		appiumCommands.click("yourLocation");
	}

	public void enterZipcode(int i) {
		appiumCommands.type("sameDayDeliveryZipcode", util.getTestCaseDataColumn(i, "zipcode"));
	}
	
	public void clickOnShowResultsButton() {
		appiumCommands.click("showResultsButton");
	}
	
	public void clickOnOKButton() {
		appiumCommands.click("okButton");
	}
	
	public void verifyTheZipcodeAppliedSuccessfully() {
		appiumCommands.checkElementIsVisibleOnPage("verifyZipcode");
	}

  public void clickSignoutButton() {
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.performScroll();
    appiumCommands.click("signOutTab");
  }

}
