package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.io.IOException;
import java.util.List;

public class StoresActivityIOS {

  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public StoresActivityIOS(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("ios/StoresActivity.csv");
    // util.readDataFile("StoresActivityData.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }

  public void clickOnStoreModeLink() {
    appiumCommands.click("storeModeLink");
  }

  public void clickOnFindASephoraLink() {
    appiumCommands.click("findASephoraLink");
  }

  public void clickOnStoreDetails() {
    appiumCommands.click("storeDetailsButton");
  }

  public void clickOnLoveListCard()
  {
    appiumCommands.performScroll();
    appiumCommands.click("yourLoveListCard");
  }

  public void clickOnbuyItAgainCard()
  {
    appiumCommands.performScroll();
    appiumCommands.click("buyItAgainCard");
  }
  public void validateStoreName(String storeName) {
    appiumCommands.customWait(FrameworkConstants.prolongedWait);
    String actualStoreName = appiumCommands.getText("storeName");

    Assert.assertEquals(actualStoreName, storeName);
  }

  public String getStoreName() {
    return appiumCommands.getText("storeNameFromInfoScreen");
  }

  public void clickOnAllTileServices() {
    appiumCommands.click("allTile_Services");
  }

  public void clickOnMakeUpTileServices() {
    appiumCommands.click("makeUpTile_Services");
  }

  public void clickOnHairTileServices() {
    appiumCommands.click("hairTile_Services");
  }

  public void clickOnWaxingTileServices() {
    appiumCommands.click("waxingTile_Services");
  }

  public void clickOnStoreModeAfterStoreIsEnabled() {
    appiumCommands.click("storeModeAfterStoreEnabled");
  }

  public void clickOnFirstEvent() {
    appiumCommands.click("firstEvent");
  }

  public void storeicon() {
    appiumCommands.click("Clickonstore");
  }

  public void clickOnViewAllLink() {
    appiumCommands.performScroll();
    appiumCommands.click("viewAllLink");
  }

  public void scrolltillview() {
    appiumCommands.customWait(FrameworkConstants.quickWait);
    appiumCommands.performScroll();
  }

  public void checkviewall() {
    // appiumCommands.customWait(3);
    appiumCommands.click("clickonviewsevents");
  }

  public void filterbar() {
    appiumCommands.click("FilterbarforEvents");
  }

  public void clicklocation() {
    appiumCommands.click("ClickLocation");
  }

  public void suggestedadd() {
    appiumCommands.click("Suggestedadd");
  }

  public void showall() {
    appiumCommands.click("Clickonshowall");
  }

  public void verifyStoreModeHeader(String firstName) {
    String headerText[] = appiumCommands.getText("storeModeHeaderText").split("!");
    Assert.assertTrue(headerText[0].equalsIgnoreCase(firstName));
  }

  public void verifyStoreDetailsLink() {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("storeDetailsLink"));
  }

  public void verifyInsiderImage() {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("insiderImage"));
  }
  public void verifyInsiderImage_UnRecognizedUser() {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("verifyInsiderImage_UnRecognizedUser"));
  }
  public void verifyBeautyInsiderSummaryHeader() {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("beautyInsiderSummaryHeader"));
  }

  public void verifyPointsText() {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("pointsText"));
  }

  public void verifySummarySection() {
    verifyInsiderImage();
    verifyBeautyInsiderSummaryHeader();
    verifyPointsText();
  }

  public void verifyBasketCarousel() {
    if (appiumCommands.checkElementIsVisibleOnPage("basketJumpLink")) {
      appiumCommands.click("cartButton");appiumCommands.customWait(2);
      Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("productsRemoveButton"));
      if (appiumCommands.checkElementIsVisibleOnPage("productsRemoveButton")) {
        List<WebElement> removeButton = util.findElements("productsRemoveButton");
        for (WebElement element : removeButton)
          appiumCommands.click("productsRemoveButton");
      }
      appiumCommands.click("storeNavigationButton");
      Assert.assertTrue(!appiumCommands.checkElementIsVisibleOnPage("basketJumpLink"));
    } else {
      appiumCommands.click("cartButton");
      Assert.assertTrue(!appiumCommands.checkElementIsVisibleOnPage("productsRemoveButton"));
      appiumCommands.click("storeNavigationButton");appiumCommands.customWait(2);
      appiumCommands.click("yourLoveListCard");appiumCommands.customWait(2);
      appiumCommands.click("addToBasket");appiumCommands.customWait(2);
      appiumCommands.click("cartButton");appiumCommands.customWait(2);
      Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("productsRemoveButton"));
    }

  }

  public void clickOnEventsJumpLink() {
    appiumCommands.click("eventsJumpLink");appiumCommands.customWait(FrameworkConstants.quickWait);
  }
  public void verifyEventsDate(){
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("eventsDate"));appiumCommands.customWait(FrameworkConstants.quickWait);
  }
  public void verifyEventsPage(){
    verifyEventsDate();
    clickOnEventsViewAllLink();
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("verifyEventsPage"));appiumCommands.customWait(FrameworkConstants.quickWait);
  }
  public void clickOnEventsViewAllLink(){
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("eventsViewAllLink"));
    appiumCommands.click("eventsViewAllLink");appiumCommands.customWait(FrameworkConstants.quickWait);
  }

  public void verifyServiceEventsPage() {
    appiumCommands.click("bookAServiceViewAllLink");appiumCommands.customWait(FrameworkConstants.quickWait);
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("verifyServiceEventsPage"));
  }

  public void verifyEventsJumpLinkPage() {
    clickOnEventsJumpLink();
    if(appiumCommands.checkElementIsVisibleOnPage("eventStartingSoonHeader"))
      Assert.assertTrue(true);
    else if (appiumCommands.checkElementIsVisibleOnPage("upcomingEvent"))
      Assert.assertTrue(true);
    else
      Assert.fail("Event Header Not Found");


    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("eventStartingSoonHeader"));
    appiumCommands.customWait(FrameworkConstants.quickWait);
    appiumCommands.performScrollBottomToUp();
  }

  public void verifyBeautyOffersJumpLinkPage() {
    appiumCommands.click("beautyOfferJumpLink");
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("beautyOffersSubHeading"));
    appiumCommands.customWait(FrameworkConstants.quickWait);
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
  }

  public void choosenForYouJumpLinkPage() {
    appiumCommands.click("chosenForYouJumpLink");
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("choosenForYouHeading"));
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
  }

  public void verifyQuizzesJumpLinkPage() {
    appiumCommands.click("quizzesJumpLink");
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("quiizzesHeader"));
    appiumCommands.customWait(FrameworkConstants.quickWait);

  }
  public void verifyServiceMakeUPJumpLink(){
    appiumCommands.click("serviceMakeUpJumpLink");appiumCommands.customWait(FrameworkConstants.quickWait);
    Assert.assertTrue(appiumCommands.checkElementIsNotVisibleOnPage("verifyServiceMakeUpJumpLinkPage"));
    appiumCommands.performScrollBottomToUp();
  }
  public void verifyServiceSkinCareJumpLink(){
    appiumCommands.click("serviceSkinCareJumpLink");appiumCommands.customWait(FrameworkConstants.quickWait);
    Assert.assertTrue(appiumCommands.checkElementIsNotVisibleOnPage("verifyServiceSkinCareJumpLinkPage"));
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
  }
  public void verifyServiceWaxingJumpLink(){
    appiumCommands.click("serviceWaxingJumpLink");appiumCommands.customWait(FrameworkConstants.quickWait);
    Assert.assertTrue(appiumCommands.checkElementIsNotVisibleOnPage("verifyServiceWaxingJumpLinkPage"));
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
    appiumCommands.performScrollBottomToUp();
  }
  public void verifyServiceEventsJumpLink(){
    appiumCommands.click("serviceEventsJumpLink");appiumCommands.customWait(FrameworkConstants.quickWait);
    Assert.assertTrue(appiumCommands.checkElementIsNotVisibleOnPage("verifyServiceEventsJumpLinkPage"));
  }
  public void verifyServicesJumpLinks() {
    verifyServiceMakeUPJumpLink();
    verifyServiceSkinCareJumpLink();
    verifyServiceWaxingJumpLink();
    verifyServiceEventsJumpLink();
  }

  public void clickOnAllowNotifications()
  {
    appiumCommands.click("allowNotifications");
  }

  public boolean checkAllowNotification()
  {
    return appiumCommands.checkElementIsVisibleOnPage("allowNotifications");
  }

  public void clickOnFirstService()
  {
      appiumCommands.click("firstService");
  }

  public void assertEventHeader()
  {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("eventHeader"));
  }

  public void assertEventComingSoonHeader()
  {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("eventStartingSoonHeader"));
  }

  public void assertBeautySubHeadingHeader()
  {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("eventStartingSoonHeader"));
  }

  public void assertChoosenForYouHeader()
  {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("eventStartingSoonHeader"));
  }

  public void assertQuizzesHeader()
  {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("eventStartingSoonHeader"));
  }

  public void clickOnChosenForYouViewALlLink()
  {
      appiumCommands.click("choosenForYouViewAll");
  }

  public void assertInStoreButton()
  {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("inAtStoreButton"));
  }

  public void clickOnInAtStoreButton()
  {
    appiumCommands.click("inAtStoreButton");
  }

  public void assertInStockAllButton()
  {
    Assert.assertTrue(appiumCommands.checkElementIsVisibleOnPage("inStockAllButton"));
  }

  public void clickOnInStockAllButton()
  {
    appiumCommands.click("inStockAllButton");
  }

  public void clickOnAddToBasket()
  {
    appiumCommands.click("addToBasket");
  }

}

