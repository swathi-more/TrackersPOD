package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.constants.FrameworkConstants;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class OnBoardActivityIOS {


  AppiumDriver driver;
  ServiceLocator service = ServiceLocator.getInstance();
  Util util;
  AppiumCommands appiumCommands;

  public OnBoardActivityIOS(AppiumDriver driver) throws IOException, CsvException {
    this.driver = driver;
    PageFactory.initElements(driver, this);
    util = new Util(driver);
    util.readCSV("ios/OnBoardingActivity.csv");
    util.readDataFile("ios/OnBoardingActivityData.csv");
    appiumCommands = new AppiumCommands(driver, util);
  }

  public void clickOnSignInButton() {
    appiumCommands.click("signInButton");
  }

  public void clickOnSkipNowButton() {
      appiumCommands.click("skipNoWButton");
  }
  public void createAccountButton() {
    appiumCommands.click("createAccountButton");
  }

  public void SignIn(int i) {
      appiumCommands.type("EmailAddress", util.getTestCaseDataColumn(i, "UserEmail"));
      appiumCommands.type("Password", util.getTestCaseDataColumn(i, "Password"));
      appiumCommands.click("signInButton");

  }
  public void EnterEmailForForgott(int i){
    appiumCommands.type("EmailAddress", util.getTestCaseDataColumn(i, "UserEmail"));
  }

  public void EnterInvalidEmailAndPass(int i) {
      appiumCommands.type("EmailAddress", util.getTestCaseDataColumn(i, "InvalidUserName"));
      appiumCommands.type("Password", util.getTestCaseDataColumn(i, "InvalidPass"));

  }

  public void ClickForgott() {
    appiumCommands.click("ForgottPass");
  }

  public void ClickSendEmail() {
    appiumCommands.click("SendEmail");
  }

  public void ClickOK() {
    appiumCommands.click("OK");
  }

  public void ResendPass(){
    appiumCommands.click("Resend");
  }
  public void VerifyError(){
    if(appiumCommands.checkElementIsVisibleOnPage("Error")){
      appiumCommands.click("ErrorOK");
    }
    else {
      appiumCommands.click("signInButton");
    }
  }

}
