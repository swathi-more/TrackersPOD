package com.automate.pages.ios;

import com.automate.commands.AppiumCommands;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class ShopActivityIOS {

	AppiumDriver driver;
	ServiceLocator service = ServiceLocator.getInstance();
	Util util;
	AppiumCommands appiumCommands;

	public ShopActivityIOS(AppiumDriver driver) throws IOException, CsvException {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		util = new Util(driver);
		util.readCSV("ios/ShopActivity.csv");
		// util.readDataFile("StoresActivityData.csv");
		appiumCommands = new AppiumCommands(driver, util);
	}

	public void enterSearchBox(String searchData) {
		appiumCommands.type("searchBox", searchData);
	}

	public void clickOnSearchIcon() {
		appiumCommands.click("searchIcon");
	}

	public void clickOnBrowseTab() {
		appiumCommands.click("browseTab");
	}

	public void clickOnOffersTab() {
		appiumCommands.click("offersTab");
	}

	public void clickOnRewardBazaarTab() {
		appiumCommands.click("rewardBazaarTab");
	}

	public void clickOnBrowseNewIcon() {
		appiumCommands.click("browseNewIcon");
	}

	public void clickOnBrowseBrandsIcon() {
		appiumCommands.click("browseBrandsIcon");
	}

	public void clickOnMakeupIcon() {
		appiumCommands.click("browseMakeupIcon");
	}

	public void clickOnSkinCareIcon() {
		appiumCommands.click("browseSkinCareIcon");
	}

	public void clickOnHairIcon() {
		appiumCommands.click("browseHairIcon");
	}

	public void clickOnFragranceIcon() {
		appiumCommands.click("browseFragranceIcon");
	}

	public void clickOnToolsBrushIcon() {
		appiumCommands.click("browseToolsBrushIcon");
	}

	public void clickOnBathIcon() {
		appiumCommands.click("browseBathIcon");
	}

	public void clickOnCleanBeautyIcon() {
		appiumCommands.click("browseCleanBeautyIcon");
	}

	public void clickOnMiniSizeIcon() {
		appiumCommands.click("browseMiniSizeIcon");
	}

	public void clickOnBeautyIcon() {
		appiumCommands.click("browseBeautyIcon");
	}

	public void clickOnGiftIcon() {
		appiumCommands.click("browseGiftIcon");
	}

	public void clickOnBestsellerIcon() {
		appiumCommands.click("browseBestsellerIcon");
	}

	public void clickOnSaleIcon() {
		appiumCommands.click("browseSaleIcon");
	}

	public void clickOnDeliverAndPickupOptionsLink() {
		appiumCommands.click("deliverAndPickupOptionsLink");
	}

	public void clickOnGiftCardsAndEGiftCardsLink() {
		appiumCommands.click("giftCardsAndEGiftCardsLink");
	}

	public void clickOnOnlyAtSephoraLink() {
		appiumCommands.click("onlyAtSephoraLink");
	}

	public void clickOnBuyingGuideAndQuizzesLink() {
		appiumCommands.click("buyingGuideAndQuizzesLink");
	}

	public void clickOnBlackOwnedBrandsLink() {
		appiumCommands.click("blackOwnedBrandsLink");
	}

	public void clickOnLuxurySkinCareLink() {
		appiumCommands.click("luxurySkincareLink");
	}

	public void clickOnCleanBeautyLink() {
		appiumCommands.click("cleanBeautyLink");
	}

}
