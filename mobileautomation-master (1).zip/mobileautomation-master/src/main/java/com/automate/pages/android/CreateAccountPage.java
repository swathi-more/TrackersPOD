package com.automate.pages.android;

import com.automate.commands.AppiumCommands;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class CreateAccountPage {


	private static final Logger logger = LogManager.getLogger(CreateAccountPage.class);
	AppiumDriver driver;
	ServiceLocator service = ServiceLocator.getInstance();
	Util util;
	AppiumCommands appiumCommands;

	public CreateAccountPage(AppiumDriver driver) throws IOException, CsvException {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		util = new Util(driver);
    util.readCSV("android/CreateAccountPage.csv");
    util.readDataFile("android/CreateAccountPageData.csv");
		appiumCommands = new AppiumCommands(driver, util);
	}

  public void enterEmailAddress(int i){
    String timeStamp= appiumCommands.getCurrentTime()+"@yopmail.com";
    appiumCommands.type("emailAddressInputText",util.getTestCaseDataColumn(i,"User_Email")+timeStamp);
  }

  public  void clickOnDoneButton(){
    appiumCommands.click("doneButton");
  }

  public  void enterFirstName(int i){
  appiumCommands.type("firstNameInputTextField",util.getTestCaseDataColumn(i,"User_FirstName"));
  }

  public void enterLastName(int i){
    appiumCommands.type("lastNameInputTextField",util.getTestCaseDataColumn(i,"User_LastName"));
  }
  public void enterPassword(int i){
    appiumCommands.type("passwordInputTextField",util.getTestCaseDataColumn(i,"User_Password"));

  }
  public void clickOnJoinNowButton(){
    appiumCommands.performScroll();
    appiumCommands.click("joinNowButton");
  }

  public void createUser(int i){
    enterEmailAddress(i);
    clickOnDoneButton();
    enterFirstName(i);
    enterLastName(i);
    enterPassword(i);
    clickOnJoinNowButton();
  }
}
