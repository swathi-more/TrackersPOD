package com.automate.enums;

public enum WaitStrategy {
  CLICKABLE, PRESENCE, VISIBLE, NONE
}
