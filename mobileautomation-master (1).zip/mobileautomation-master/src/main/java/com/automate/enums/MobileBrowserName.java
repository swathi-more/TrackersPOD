package com.automate.enums;

public enum MobileBrowserName {
  CHROME,
  SAFARI
}
