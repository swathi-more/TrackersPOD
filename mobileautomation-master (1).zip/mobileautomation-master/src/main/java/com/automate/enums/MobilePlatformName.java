package com.automate.enums;

public enum MobilePlatformName {

  ANDROID,
  ANDROID_WEB,
  IOS,
  IOS_WEB,
  BROWSER_STACK_WEB,
  BROWSER_STACK,
  ANDROID_WITH_PROXY,
  IOS_WITH_PROXY
}
