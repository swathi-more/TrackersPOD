package com.automate.enums;

public enum MobileFindBy {
  XPATH, CSS, ID, NAME, CLASS, ACCESSIBILITY_ID
}
