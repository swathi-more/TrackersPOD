package com.automate.enums;

public enum ConfigJson {
  APP_ACTIVITY, APP_PACKAGE, APPIUM_URL, AVD_LAUNCH_TIMEOUT,
  BUNDLE_ID,
  URL
}
