package com.automate.enums;

public enum CategoryType {

  REGRESSION, SANITY, SMOKE
}
