package com.automate.reports.tg;

import com.automate.interfaces.LoggerImpl;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

public class ExtentReportLogger implements LoggerImpl {
	
	ExtentReports extentReports;

	public ExtentReportLogger() {
		
		try {
			if(ExtentReportManager.getExtentReport()!=null)
			{
				extentReports = ExtentReportManager.getExtentReport();
			}
			else
			{
				ExtentReportManager.setupExtentReport();
				extentReports = ExtentReportManager.getExtentReport();
			}
		}catch(Exception e) {
			
		}		
	}
	
	
	public  ExtentTest startTest(String testName)
	{
		return extentReports.createTest(testName);
	}


	@Override
	public void infoWithMessage(LoggerImpl logger, String msg) {
		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.info(msg);
		
	}


	@Override
	public void infoWithMessageAndAuthor(LoggerImpl logger, String msg, String author) {
		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.assignAuthor(author);
		test.info(msg);
		
	}


	@Override
	public void infoWithMessageAndDevice(LoggerImpl logger, String msg, String device) {

		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.assignDevice(device);
		test.info(msg);
		
	}


	@Override
	public void infoWithMessageAndCategory(LoggerImpl logger, String msg, String category) {
		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.assignCategory(category);
		test.info(msg);
		
	}


	@Override
	public void info(LoggerImpl logger, String msg, String author, String device, String category) {

		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.assignCategory(category);
		test.assignAuthor(author);
		test.assignDevice(device);
		test.info(msg);
		
	}


	@Override
	public void passWithMessage(LoggerImpl logger, String msg) {
		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.pass(msg);
		
	}


	@Override
	public void passWithMessageAndAuthor(LoggerImpl logger, String msg, String author) {
		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.assignAuthor(author);
		test.pass(msg);
		
	}


	@Override
	public void passWithMessageAndDevice(LoggerImpl logger, String msg, String device) {
		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.assignDevice(device);
		test.pass(msg);
		
	}


	@Override
	public void passWithMessageAndCategory(LoggerImpl logger, String msg, String category) {
		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.assignCategory(category);
		test.pass(msg);
		
	}


	@Override
	public void pass(LoggerImpl logger, String msg, String author, String device, String category) {

		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.assignCategory(category);
		test.assignAuthor(author);
		test.assignDevice(device);
		test.pass(msg);
		
	}


	@Override
	public void failWithMessage(LoggerImpl logger, String msg) {
		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.fail(msg);
		
	}


	@Override
	public void failWithMessageAndAuthor(LoggerImpl logger, String msg, String author) {
		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.assignAuthor(author);
		test.fail(msg);
		
	}


	@Override
	public void failWithMessageAndDevice(LoggerImpl logger, String msg, String device) {
		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.assignDevice(device);
		test.fail(msg);
		
	}


	@Override
	public void failWithMessageAndCategory(LoggerImpl logger, String msg, String category) {
		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.assignCategory(category);
		test.fail(msg);
		
	}


	@Override
	public void fail(LoggerImpl logger, String msg, String author, String device, String category) {

		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.assignCategory(category);
		test.assignAuthor(author);
		test.assignDevice(device);
		test.fail(msg);
		
	}


	@Override
	public void warningWithMessage(LoggerImpl logger, String msg) {
		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.warning(msg);
		
	}


	@Override
	public void warningWithMessageAndAuthor(LoggerImpl logger, String msg, String author) {
		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.assignAuthor(author);
		test.warning(msg);
		
	}


	@Override
	public void warningWithMessageAndDevice(LoggerImpl logger, String msg, String device) {
		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.assignDevice(device);
		test.warning(msg);
		
	}


	@Override
	public void warningWithMessageAndCategory(LoggerImpl logger, String msg, String category) {
		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.assignCategory(category);
		test.warning(msg);
		
	}


	@Override
	public void warning(LoggerImpl logger, String msg, String author, String device, String category) {

		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.assignCategory(category);
		test.assignAuthor(author);
		test.assignDevice(device);
		test.warning(msg);
		
	}


	@Override
	public void skipWithMessage(LoggerImpl logger, String msg) {
		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.skip(msg);
		
	}


	@Override
	public void skipWithMessageAndAuthor(LoggerImpl logger, String msg, String author) {
		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.assignAuthor(author);
		test.skip(msg);
		
	}


	@Override
	public void skipWithMessageAndDevice(LoggerImpl logger, String msg, String device) {
		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.assignDevice(device);
		test.skip(msg);
		
	}


	@Override
	public void skipWithMessageAndCategory(LoggerImpl logger, String msg, String category) {
		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.assignCategory(category);
		test.skip(msg);
		
	}


	@Override
	public void skip(LoggerImpl logger, String msg, String author, String device, String category) {

		ExtentTest test=null;
		test = (ExtentTest) logger;
		test.assignCategory(category);
		test.assignAuthor(author);
		test.assignDevice(device);
		test.skip(msg);
		
	}
	
	

}
