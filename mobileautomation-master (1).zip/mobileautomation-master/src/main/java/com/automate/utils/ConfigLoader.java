package com.automate.utils;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ConfigLoader {
	
	static Properties p;
	
	public static void initConfig() throws IOException
	{
		
		System.out.println(System.getProperty("user.dir")+"/settings/+application.properties");
		FileReader reader=new FileReader(System.getProperty("user.dir")+"/settings/application.properties");  
	//	FileReader reader1=new FileReader("galen.config");
	      
	    p=new Properties();  
	    p.load(reader);  
	  //  p.load(reader1);
	}
	
	public static Object readProperty(String key)
	{
		
		return p.getProperty(key);
	}

}
