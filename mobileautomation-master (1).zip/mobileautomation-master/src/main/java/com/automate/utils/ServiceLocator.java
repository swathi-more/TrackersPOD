package com.automate.utils;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;

public class ServiceLocator {
	private static final Logger logger = LogManager.getLogger(ServiceLocator.class);

	private static ServiceLocator serviceLocator;
	public static Map<String, String> sessionMap = new HashMap<>();
	public static Properties properties = new Properties();

	static {
		try {
			serviceLocator = new ServiceLocator();
		} catch (Exception e) {
			logger.error(String.format("ProcessingStep=End of Service Locator||ERROR=%s", e.getMessage()));
		}
	}

	/**
	 * @return the sessionAttributes
	 */
	public static String getSessionMap(String key) {
		return sessionMap.get(Thread.currentThread().getName() + "_" + key);
	}

	/**
	 * @param sessionMap the sessionAttributes to set
	 */
	public static void setSessionMap(String key, String value) {
		sessionMap.put(Thread.currentThread().getName() + "_" + key, value);
	}

	public static ServiceLocator getInstance() {
		return serviceLocator;
	}

	private ServiceLocator() throws IOException, CsvException {
		String propertiesFile = "Automation.properties";
		try {
			properties.load(this.getClass().getClassLoader().getResourceAsStream(propertiesFile));
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	public static String getProperty(String key) {
		return properties.get(key).toString();
	}
}