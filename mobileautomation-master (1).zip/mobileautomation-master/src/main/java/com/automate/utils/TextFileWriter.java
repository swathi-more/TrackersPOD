package com.automate.utils;

import com.automate.eventspojo.Event;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class TextFileWriter {

  public void writeEventsToFile(List<Event> eventList) throws IOException {
    long timestamp = System.currentTimeMillis();
    String filename = System.getProperty("user.dir") + "/EventData/EventDataFile_" + timestamp + ".txt";
    System.out.println(filename);

    // Create a FileWriter and BufferedWriter to write to the new text file
    FileWriter fileWriter = new FileWriter(filename);
    BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

    for (Event obj : eventList) {
      bufferedWriter.write(obj.toString());
      bufferedWriter.newLine();
    }

    // Close the BufferedWriter
    bufferedWriter.close();
  }

}
