package com.automate.utils.screenrecording;

import com.automate.enums.ConfigProperties;
import com.automate.utils.configloader.PropertyUtils;

import io.appium.java_client.AppiumDriver;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class ScreenRecordingService {

  public static void startRecording(AppiumDriver driver) {
    if (PropertyUtils.getPropertyValue(ConfigProperties.RECORD_SCREEN).equalsIgnoreCase("yes")) {
      ScreenRecordingUtils.startScreenRecording(driver);
    }
  }

  public static void stopRecording(AppiumDriver driver,String methodName) {
    if (PropertyUtils.getPropertyValue(ConfigProperties.RECORD_SCREEN).equalsIgnoreCase("yes")) {
      ScreenRecordingUtils.stopScreenRecording(driver,methodName);
    }

  }
}
