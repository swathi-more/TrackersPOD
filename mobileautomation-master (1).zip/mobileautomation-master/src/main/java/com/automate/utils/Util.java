/**
 *
 */
package com.automate.utils;

import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.time.Duration;
import java.time.LocalDate;
import java.time.Month;
import java.util.*;
import java.util.stream.Collectors;

import com.automate.constants.FrameworkConstants;
import com.aventstack.extentreports.App;
import com.google.common.collect.ImmutableList;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.bys.builder.AppiumByBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;

import javax.lang.model.element.Element;

/**
 * @author Kumara Swamy
 */
public class Util {
	private static final Logger logger = LogManager.getLogger(Util.class);
	public static Map<String, String> sessionMap = new HashMap<>();
	public List<String[]> csvAllRows;
	public List<String> headers;
	WebDriver driver;
	ServiceLocator service = ServiceLocator.getInstance();
	private List<String[]> testCaseData;
	private List<String> testCaseDataColumns;

	public Util(WebDriver driver) {
		this.driver = driver;
	}

	public static String getSessionMap(String key) {
		return sessionMap.get(Thread.currentThread().getName() + "_" + key);
	}

	/**
	 * @paramsessionMap the sessionAttributes to set
	 */
	public static void setSessionMap(String key, String value) {
		sessionMap.put(Thread.currentThread().getName() + "_" + key, value);
	}

	public void readCSV(String filename) throws IOException, CsvException {
		try (CSVReader reader = new CSVReader(
				new InputStreamReader(this.getClass().getClassLoader().getResourceAsStream(filename)))) {

			csvAllRows = reader.readAll();
			headers = Arrays.asList(csvAllRows.get(0));
			headers = headers.stream().map(String::toLowerCase).map(String::trim).collect(Collectors.toList());
//			logger.info(String.format("CSV Headers %s", headers));
		}
	}

	public WebElement findElement(String variableName) {
		Optional<String[]> optional = csvAllRows.stream().filter(eachRow -> eachRow[0].equalsIgnoreCase(variableName))
				.findFirst();
		String[] row = null;
		if (optional.isPresent()) {
			row = optional.get();
		}
		Date startTime = new Date();
		int timeout = Integer.parseInt(ServiceLocator.getProperty("findElementTimeOut"));
		long maxTime = startTime.getTime() / 1000 + timeout;
//		logger.info(String.format("Filtered row from the CSV file %s", Arrays.asList(row)));
		if (row != null) {
			while (true) {
				for (int i = 1; i < row.length; i++) {
					try {
						By locator = getElementIdentifier(row, headers.get(i));
						WebElement element = driver.findElement(locator);
						WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(FrameworkConstants.EXPLICIT_WAIT));
						try {
							wait.until(ExpectedConditions.elementToBeClickable(element));
						} catch (Exception e) {
						}
//						if (element.isDisplayed()) {
//							logger.info("The element is visible on the screen");
//							return element;
//						}
						if (element != null) {
							return element;
						}
						Thread.sleep(1000);
						Date endTime = new Date();
						long responseTime = endTime.getTime() / 1000;
						if (responseTime >= maxTime) {
							return null;
						}
					} catch (Exception e) {
						logger.info(String.format("%s failed with %s", row[0], headers.get(i)));
						logger.info("######################  Trying to SELFHEAL..  #######################");
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e1) {
							e1.printStackTrace();
							Thread.currentThread().interrupt();
						}
						Date endTime = new Date();
						long responseTime = endTime.getTime() / 1000;
						if (responseTime >= maxTime) {
							return null;
						}
					}
				}
			}
		} else {
			return null;
		}
	}



  public WebElement findElementByAndroidUIAutomation(String variableName) {
    Optional<String[]> optional = csvAllRows.stream().filter(eachRow -> eachRow[0].equalsIgnoreCase(variableName))
      .findFirst();
    String[] row = null;
    if (optional.isPresent()) {
      row = optional.get();
    }
    Date startTime = new Date();
    int timeout = Integer.parseInt(ServiceLocator.getProperty("findElementTimeOut"));
    long maxTime = startTime.getTime() / 1000 + timeout;
//		logger.info(String.format("Filtered row from the CSV file %s", Arrays.asList(row)));
    if (row != null) {
      while (true) {
        for (int i = 1; i < row.length; i++) {
          try {
            AppiumBy locator = getAndroidElementIdentifier(row, headers.get(i));
            WebElement element = driver.findElement(locator);
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
//						wait.until(ExpectedConditions.presenceOfElementLocated(locator));
            try {
              wait.until(ExpectedConditions.elementToBeClickable(element));
            } catch (Exception e) {
            }
//						if (element.isDisplayed()) {
//							logger.info("The element is visible on the screen");
//							return element;
//						}
            if (element != null) {
              return element;
            }
            Thread.sleep(1000);
            Date endTime = new Date();
            long responseTime = endTime.getTime() / 1000;
            if (responseTime >= maxTime) {
              return null;
            }
          } catch (Exception e) {
            logger.info(String.format("%s failed with %s", row[0], headers.get(i)));
            logger.info("######################  Trying to SELFHEAL..  #######################");
            try {
              Thread.sleep(1000);
            } catch (InterruptedException e1) {
              e1.printStackTrace();
              Thread.currentThread().interrupt();
            }
            Date endTime = new Date();
            long responseTime = endTime.getTime() / 1000;
            if (responseTime >= maxTime) {
              return null;
            }
          }
        }
      }
    } else {
      return null;
    }
  }


  public String getXpathFromCSV(String variableName, String locator) {
		String xpath = null;
		try {
			Optional<String[]> optional = csvAllRows.stream()
					.filter(eachRow -> eachRow[0].equalsIgnoreCase(variableName)).findFirst();
			String[] row = null;
			if (optional.isPresent()) {
				row = optional.get();
			}

			if (row != null) {
				int index = headers.indexOf(locator);
				xpath = row[index];
			}

		} catch (Exception e) {
			logger.info("Unable to find xpath " + variableName);
		}
		return xpath;
	}

	public List<WebElement> findElements(String variableName) {
		Optional<String[]> optional = csvAllRows.stream().filter(eachRow -> eachRow[0].equalsIgnoreCase(variableName))
				.findFirst();
		String[] row = null;
		if (optional.isPresent()) {
			row = optional.get();
		}
//		logger.info(String.format("Filtered row from the CSV file %s", Arrays.asList(row)));
		if (row != null) {
			while (true) {
				Date startTime = new Date();
				int timeout = Integer.parseInt(ServiceLocator.getProperty("findElementTimeOut"));
				long maxTime = startTime.getTime() / 1000 + timeout;
				for (int i = 1; i < row.length; i++) {
					try {
						By locator = getElementIdentifier(row, headers.get(i));
						return driver.findElements(locator);
					} catch (Exception e) {
						logger.info(String.format("%s failed with %s", row[0], headers.get(i)));
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e1) {
							e1.printStackTrace();
							Thread.currentThread().interrupt();
						}
						Date endTime = new Date();
						long responseTime = endTime.getTime() / 1000;
						if (responseTime >= maxTime) {
							return null;
						}
					}
				}
			}
		} else {
			return null;
		}
	}

	public By getElementIdentifier(String[] row, String locatorType) {
		logger.info(String.format("%s trying with %s", row[0], locatorType));
		if (row.length > 1) {
			locatorType = locatorType.toLowerCase().trim();
			int index = 0;
			index = headers.indexOf(locatorType);

			if (locatorType.equalsIgnoreCase("default")) {
				locatorType = row[index];
				if (locatorType != null && !locatorType.equalsIgnoreCase("")) {
					index = headers.indexOf(locatorType);
					logger.info(String.format("%s default is %s", row[0], locatorType));
				} else {
					return null;
				}
			}

			if (row[index] == null || row[index].equalsIgnoreCase("")) {
				return null;
			}

			switch (locatorType) {
			case "id":
				return By.id(row[index]);
			case "css":
				return By.cssSelector(row[index]);
			case "name":
				return By.name(row[index]);
			case "linktext":
				return By.linkText(row[index]);
			case "partiallinktext":
				return By.partialLinkText(row[index]);
			case "classname":
				return By.className(row[index]);
			default:
				return By.xpath(row[index]);
			}
		} else {
			return null;
		}
	}


  public AppiumBy getAndroidElementIdentifier(String[] row, String locatorType) {
    logger.info(String.format("%s trying with %s", row[0], locatorType));
    if (row.length > 1) {
      locatorType = locatorType.toLowerCase().trim();
      int index = 0;
      index = headers.indexOf(locatorType);

      if (locatorType.equalsIgnoreCase("default")) {
        locatorType = row[index];
        if (locatorType != null && !locatorType.equalsIgnoreCase("")) {
          index = headers.indexOf(locatorType);
          logger.info(String.format("%s default is %s", row[0], locatorType));
        } else {
          return null;
        }
      }

      if (row[index] == null || row[index].equalsIgnoreCase("")) {
        return null;
      }

      switch (locatorType) {
        case "id":
          return (AppiumBy) AppiumBy.id(row[index]);
        case "css":
          return (AppiumBy) AppiumBy.cssSelector(row[index]);
        case "name":
          return (AppiumBy) AppiumBy.name(row[index]);
        case "linktext":
          return (AppiumBy) AppiumBy.linkText(row[index]);
        case "partiallinktext":
          return (AppiumBy) AppiumBy.partialLinkText(row[index]);
        case "classname":
          return (AppiumBy) AppiumBy.className(row[index]);
        default:
          return (AppiumBy) AppiumBy.xpath(row[index]);
      }
    } else {
      return null;
    }
  }



  public String getElementIdentifierString(String variableName, String locatorType) {
		Optional<String[]> row = csvAllRows.stream().filter(eachRow -> eachRow[0].equalsIgnoreCase(variableName))
				.findFirst();
		if (row.isPresent()) {
//			variableName,id,css,xpath,name,linkText,partialLinkText,className
			locatorType = locatorType.toLowerCase().trim();
			int index = 0;
			index = headers.indexOf(locatorType);
			return row.get()[index];
		} else {
			return null;
		}
	}

	public void readDataFile(String dataFileName) throws IOException, CsvException {
		try (CSVReader reader = new CSVReader(
				new InputStreamReader(this.getClass().getClassLoader().getResourceAsStream(dataFileName)))) {

			testCaseData = reader.readAll();
			if (!testCaseData.isEmpty()) {
				testCaseDataColumns = Arrays.asList(testCaseData.remove(0));
			}
		}
	}

	public String getTestCaseDataColumn(int rowIndex, int columnIndex) {
		String[] eachRow = testCaseData.get(rowIndex);
		return eachRow[columnIndex];
	}

	public int getTestCaseDataColumnIndex(String columnName) {
		return testCaseDataColumns.indexOf(
				testCaseDataColumns.stream().filter(column -> column.equalsIgnoreCase(columnName)).findFirst().get());
	}

	public String getTestCaseDataColumn(int rowIndex, String columnName) {
		String[] eachRow = testCaseData.get(rowIndex);
		int columnIndex = getTestCaseDataColumnIndex(columnName);
		return eachRow[columnIndex];
	}

	public String getDynamicXpath(String data, String xpath) {
		// String xpath="//div[@class='ant-picker-cell-inner' and
		// text()='<texttoreplace>']";
		xpath = xpath.replace("<texttoreplace>", data);
		return xpath;
	}

	public String getCurrentMonth() {
		LocalDate currentdate = LocalDate.now();
		Month currentMonth = currentdate.getMonth();
		return currentMonth.toString().toLowerCase();

	}

	public String getNextMonth() {
		LocalDate currentdate = LocalDate.now();
		LocalDate currentdatee = currentdate.plusMonths(1);
		Month nextMonthe = currentdatee.getMonth();
		System.out.println(nextMonthe);
		return nextMonthe.toString().toLowerCase();
	}

	public int getSixMothsAheadIndex() {
		int currentMonth = Calendar.getInstance().get(Calendar.MONTH);
		if (currentMonth < 6) {
			return currentMonth + 6;

		} else {
			return ((currentMonth + 6) % 12) + 2;
		}
	}

	/*
	 * this method provides list of data ()
	 */
	public List<BigInteger> getDataListForElementWithoutDelimiter(String variableName, String[] delimiterList) {

		int counter = 0;
		List<BigInteger> data = new ArrayList<>();
		List<WebElement> webElements = findElements(variableName);
		String innerText = "";

		Iterator<WebElement> itr = webElements.iterator();
		while (itr.hasNext()) {
			WebElement element = itr.next();

			// first data is blank
			if (counter == 0) {
				counter++;
				continue;
			}
			innerText = element.getText();

			for (String dilimiter : delimiterList) {
				innerText = innerText.replace(dilimiter, "");
			}
			if (innerText.equals("")) { // adding 0 since expecting null values initial in table , else will fail the
										// testcase
				data.add(BigInteger.valueOf(Long.valueOf("0")));
			} else {
				data.add(BigInteger.valueOf(Long.valueOf(innerText)));
			}

		}
		return data;
	}

	public void clickOnListOnWebElements(String variableName) {

		int counter = 0;
		List<String> data = new ArrayList<>();
		List<WebElement> webElements = findElements(variableName);

		Iterator<WebElement> itr = webElements.iterator();
		while (itr.hasNext()) {
			WebElement element = itr.next();
			// using javascript executor to avoid scroll
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click()", element);

			// loading time for data
			try {
				Thread.sleep(2000);
			} catch (Exception e) {
			}

		}

	}

	public WebElement waitForElement(By element_id) {
		Date startTime = new Date();
		int timeout = 30;
		long maxTime = startTime.getTime() / 1000 + timeout;
		WebElement element = null;
		while (true) {
			try {
				element = driver.findElement(element_id);
				return element;
			} catch (Exception e) {
				Date endTime = new Date();
				long responseTime = endTime.getTime() / 1000;
				if (responseTime >= maxTime) {
					return element;
				}
			}
		}
	}

	public WebElement findElement(By element_id) {
		return driver.findElement(element_id);
	}



  public  void scroll(WebElement panel, ScrollDirection dir, double scrollRatio,Duration duration) {
    Point midPoint;
    Dimension size;

    if (scrollRatio < 0 || scrollRatio > 1) {
      throw new Error("Scroll distance must be between 0 and 1");
    }

    if(panel != null){
      midPoint = getCenter(panel);
    }else{ //entire screen is scrollable
      size = driver.manage().window().getSize();
      System.out.println(size);
      midPoint = new Point((int) (size.width * 0.5), (int) (size.height * 0.5));
    }

    int bottom = midPoint.y + (int) (midPoint.y * scrollRatio);
    int top = midPoint.y - (int) (midPoint.y * scrollRatio);
    int left = midPoint.x - (int) (midPoint.x * scrollRatio);
    int right = midPoint.x + (int) (midPoint.x * scrollRatio);

    if (dir == ScrollDirection.UP) {
      swipe(new Point(midPoint.x, top), new Point(midPoint.x, bottom), duration);
    } else if (dir == ScrollDirection.DOWN) {
      swipe(new Point(midPoint.x, bottom), new Point(midPoint.x, top), duration);
    } else if (dir == ScrollDirection.LEFT) {
      swipe(new Point(left, midPoint.y), new Point(right, midPoint.y), duration);
    } else if (dir == ScrollDirection.RIGHT) {
      swipe(new Point(right, midPoint.y), new Point(left, midPoint.y), duration);
    }
  }

  protected  void swipe(Point start, Point end, Duration duration) {

    PointerInput input = new PointerInput(PointerInput.Kind.TOUCH, "finger1");
    Sequence swipe = new Sequence(input, 0);
    swipe.addAction(input.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), start.x, start.y));
    swipe.addAction(input.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
        /*if (isAndroid) {
            duration = duration.dividedBy(ANDROID_SCROLL_DIVISOR);
        } else {
            swipe.addAction(new Pause(input, duration));
            duration = Duration.ZERO;
        }*/
    swipe.addAction(input.createPointerMove(duration, PointerInput.Origin.viewport(), end.x, end.y));
    swipe.addAction(input.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
    ((AppiumDriver) driver).perform(ImmutableList.of(swipe));
  }

  private static Point getCenter(WebElement el) {
    Point location = el.getLocation();
    Dimension size = el.getSize();
    return new Point(location.x + size.getWidth() / 2, location.y + size.getHeight() / 2);
  }

  public enum ScrollDirection {
    UP, DOWN, LEFT, RIGHT
  }

  public String getSaltString() {
    String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
    StringBuilder salt = new StringBuilder();
    Random rnd = new Random();
    while (salt.length() < 18) { // length of the random string.
      int index = (int) (rnd.nextFloat() * SALTCHARS.length());
      salt.append(SALTCHARS.charAt(index));
    }
    String saltStr = salt.toString();
    return saltStr;

  }

}
