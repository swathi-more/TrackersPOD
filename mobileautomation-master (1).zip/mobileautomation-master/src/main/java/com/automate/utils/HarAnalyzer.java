package com.automate.utils;

import com.automate.eventspojo.Event;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.lightbody.bmp.core.har.Har;
import net.lightbody.bmp.core.har.HarEntry;

import java.util.ArrayList;
import java.util.List;

public class HarAnalyzer {

  private ObjectMapper mapper = new ObjectMapper();

  public List<Event> getRequestFromHar(Har harFile) {
    List<Event> eventList = new ArrayList<>();
    System.out.println("################################  HAR DATA ###########################");
    for (HarEntry entry : harFile.getLog().getEntries()) {
      if (entry.getRequest().getUrl().contains("https://qa-api-developer.sephora.com/v1/sot/evt?")) {
        if (entry.getRequest().getPostData() != null) {
          try {
            Event eventObj = mapper.readValue(entry.getRequest().getPostData().getText(), Event.class);
            eventList.add(eventObj);
            //System.out.println(entry.getRequest().getPostData().getText());
          } catch (Exception e) {
            e.printStackTrace();
          }

        }
      }
    }

    System.out.println("################################  HAR DATA ###########################");

    return eventList;
  }
}
