package com.automate.utils;

import com.automate.constants.FrameworkConstants;
import com.automate.driver.manager.DriverManager;
import com.automate.driver.manager.MITMProxyManager;
import com.automate.enums.ConfigProperties;
import com.automate.utils.configloader.PropertyUtils;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import io.appium.java_client.service.local.flags.GeneralServerFlag;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import static io.appium.java_client.service.local.flags.GeneralServerFlag.BASEPATH;
import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.sql.Driver;

import org.testng.annotations.AfterSuite;

public class AppiumServerManager extends MITMProxyManager {

	public ThreadLocal<AppiumDriverLocalService> appiumThreadLocal = new ThreadLocal<AppiumDriverLocalService>();

	private AppiumDriverLocalService service;

	static boolean checkIfServerIsRunning(int port) {
		boolean isServerRunning = false;
		try {
			ServerSocket serverSocket = new ServerSocket(port);
			serverSocket.close();
		} catch (IOException e) {
			isServerRunning = true;
		}
		return isServerRunning;
	}

	public void startAppiumServer(int freePort) throws InterruptedException {

		System.out.println("Start Appium Server called : " + freePort);
		if (PropertyUtils.getPropertyValue(ConfigProperties.START_APPIUM_SERVER).equalsIgnoreCase("yes")) {

			if (!AppiumServerManager.checkIfServerIsRunning(freePort)) {
				// Build the Appium service
				AppiumServiceBuilder builder = new AppiumServiceBuilder();
				  builder.usingDriverExecutable(new File(FrameworkConstants.NODEJS_PATH))
				  .withAppiumJS(new File(FrameworkConstants.APPIUM_JS_PATH))
				  .withIPAddress(FrameworkConstants.APPIUM_SERVER_HOST) .usingPort(freePort)
				  .withArgument(GeneralServerFlag.SESSION_OVERRIDE) .withArgument (BASEPATH,
				  "/wd/hub") .withArgument(GeneralServerFlag.ALLOW_INSECURE,
				  "chromedriver_autodownload") .withArgument(GeneralServerFlag.LOG_LEVEL, FrameworkConstants.appiumLogLevel).withLogFile(new File(FrameworkConstants.getAppiumServerLogsPath()));
				   
				// Start the server with the builder
				service = AppiumDriverLocalService.buildService(builder);
//				service = AppiumDriverLocalService.buildDefaultService();
				service.start();
				setAppiumThreadLocal(service);
				System.out.println("Appium Url" + service.getUrl());
				Thread.sleep(5000);
			}
		}

	}

	@AfterSuite
	public void stopAppiumServer() {
		if (PropertyUtils.getPropertyValue(ConfigProperties.START_APPIUM_SERVER).equalsIgnoreCase("yes")) {
			if (service != null) {
				service.stop();
			}

			Runtime runtime = Runtime.getRuntime();
			try {
			//	runtime.exec("taskkill /F /IM node.exe");
			//	runtime.exec("taskkill /F /IM cmd.exe");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public static int getFreePort() {
		int freePort = 0;
		try (ServerSocket serverSocket = new ServerSocket(0)) {
			freePort = serverSocket.getLocalPort();

			System.out.println(freePort);
		} catch (IOException e) {
			System.out.println("No Free port available");
			e.printStackTrace();
		}

		return freePort;
	}

	public ThreadLocal<AppiumDriverLocalService> getAppiumThreadLocal() {
		return appiumThreadLocal;
	}

	public void setAppiumThreadLocal(AppiumDriverLocalService appiumDriverLocalService) {
		appiumThreadLocal.set(appiumDriverLocalService);
	}
}
