package com.automate.utils;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class FindDuplicateMethods {

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        String javaFilesFolderPath = "src/main/java/com/truglobal/pageobjectmodel";
        Map<String, List<String>> duplicatesMap = new HashMap<>();

        File file = new File(javaFilesFolderPath);
        List<File> listOfJavaFiles = Arrays.asList(file.listFiles());
        for (File eachFile : listOfJavaFiles) {
            if (eachFile.getName().endsWith(".java") && !eachFile.getName().endsWith("Generator.java")
                    && !eachFile.getName().endsWith("Testing.java")) {
                Class<?> cls = FindDuplicateMethods.class.getClassLoader().loadClass("com.truglobal.pageobjectmodel."
                        + eachFile.getName().substring(0, eachFile.getName().length() - 5));

                List<Method> methods = Arrays.asList(cls.getDeclaredMethods());
                for (Method eachMethod : methods) {
                    List<String> classesList = new ArrayList<>();
                    if (duplicatesMap.containsKey(eachMethod.getName().toLowerCase())) {
                        classesList = duplicatesMap.get(eachMethod.getName().toLowerCase());
                    }
                    classesList.add(eachFile.getName());
                    duplicatesMap.put(eachMethod.getName().toLowerCase(), classesList);
                }
            }
        }
        for (Entry<String, List<String>> eachEntry : duplicatesMap.entrySet()) {
            if (eachEntry.getValue().size() > 1) {
                System.out.println(eachEntry);
            }
        }
    }
}
