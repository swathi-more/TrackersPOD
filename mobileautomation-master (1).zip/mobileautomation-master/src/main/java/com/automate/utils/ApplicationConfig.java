package com.automate.utils;

public class ApplicationConfig {

    public static String APPLICATION_BASE = System.getProperty("user.dir");
    public static String UPLOADFILE_NEGATIVE_SCENARIO_FOLDER = "src/test/resources/UploadFiles/negative/";

    // error text
    public static String VISIBILITY_ERROR = "ValidationError: Project_Properties.csv: '' is not a valid value for row 'visibility' under column 'projectName'";
    public static String EPC_MARGIN_ERROR = "ValidationError: Project_Properties.csv: '' is not a valid value for row 'value' under column 'epcMargin'";
    public static String MODULE_MARGIN_ERROR = "ValidationError: Project_Properties.csv: '' is not a valid value for row 'value' under column 'moduleMargin'";
    public static String SALES_TAX_ERROR = "ValidationError: Project_Properties.csv: '' is not a valid value for row 'value' under column 'salesTax'";
    public static String PORT_VALUE_ERROR = "ValidationError: Project_Properties.csv: '' is not a valid value for row 'value' under column 'port'";
    public static String SHIPING_VALUE_ERROR = "ValidationError: Project_Properties.csv: '' is not a valid value for row 'value' under column 'shipping'";
    public static String SCENARIO_VALUE_ERROR = "ValidationError: Project_Properties.csv: '' is not a valid value for row 'value' under column 'scenario'";
    public static String BMOT_VERSION_ERROR = "ValidationError: Project_Properties.csv: '' is not a valid value for row 'value' under column 'version'";
    public static String DISPLAY_NAME_MISSING_ERROR = "ValidationError: Project_Properties.csv: key Display Name is required";
    public static String QUATER_SELECTION_MISSING_ERROR = "ValidationError: Project_Properties.csv: '' is not a valid value for row 'Display Name' under column 'quarterSelection'";
    public static String NPV_RANK_DISPLAY_NAME_ERROR = "ValidationError: NPV_Rank.csv: key Display Name is required";
    public static String NPV_RANK_KEY_MISSING_ERROR = "ValidationError: NPV_Rank.csv: key key is required";
    public static String UUID_MISSING_ERROR = "ValidationError: NPV_Rank.csv: missing UUID for a non-baseline module. See row #12";
    public static String PROJECT_PROPERTIES_VALUE_MISSING_ERROR = "ValidationError: Project_Properties.csv: key value is required";
    public static String UNSUPPORTED_WATT_VALUE = "ValidationError: NPV_Rank.csv: '650.69' is not a valid value for row 'module' under column 'wattClass'";
    public static String DATA_TYPE_MISSING_NPV_ERROR = "ValidationError: NPV_Rank.csv: '' is not a valid value for row 'dataType' under column 'rank'";
    public static String SYSTEM_SIZE_VALUE_MISSING_ERROR = "ValidationError: NPV_Rank.csv: '' is not a valid value for row 'module' under column 'systemSizeInMwDc'";

    public static String DATA_TYPE_FIELDNAME_MISSING_NPV_ERROR = "ValidationError: NPV_Rank.csv: key dataType is required";

    public static String DISPLAYSIGNIFICANT_FIELDNAME_MISSING_NPV_ERROR = "ValidationError: NPV_Rank.csv: key displaySignificantDigits is required";

    public static String UNIT_FIELDNAME_MISSING_NPV_ERROR = "ValidationError: NPV_Rank.csv: key unit is required";

    public static String UNITPLACEMENT_FIELDNAME_MISSING_NPV_ERROR = "ValidationError: NPV_Rank.csv: key unitPlacement is required";
    public static String TEXTALINGMENT_FIELDNAME_MISSING_NPV_ERROR = "ValidationError: NPV_Rank.csv: '' is not a valid value for row 'module' under column 'systemSizeInMwDc'";
    public static String MODULE_FIELDNAME_MISSING_NPV_ERROR = "ValidationError: NPV_Rank.csv: key module is required";
    public static String VENDOR_VALUE_MISSING_NPV_ERROR = "ValidationError: NPV_Rank.csv: '' is not a valid value for row 'module' under column 'vendor'";
    public static String MODULENAME_VALUE_MISSING_NPV_ERROR = "ValidationError: NPV_Rank.csv: '' is not a valid value for row 'module' under column 'moduleName'";
    public static String MODULEFIRST_NULLVALUE_NPV_ERROR = "ValidationError: NPV_Rank.csv: 'null' is not a valid value for row 'module' under column 'moduleFirstAvailable'";

    public static String MODULEPRICEWITHOUTSALESTAX_VALUE_NPV_ERROR = "ValidationError: NPV_Rank.csv: '' is not a valid value for row 'module' under column 'modulePriceWithoutSalesTax'";
    public static String NPVDELTA_VALUE_MISSING_NPV_ERROR = "ValidationError: NPV_Rank.csv: '' is not a valid value for row 'module' under column 'npvDelta'";
    public static String EPCPRICESAVINGS_VALUE_MISSING_NPV_ERROR = "ValidationError: NPV_Rank.csv: '' is not a valid value for row 'module' under column 'epcPriceSavings'";
    public static String PROJECTVALUEDELTA_VALUE_MISSING_NPV_ERROR = "ValidationError: NPV_Rank.csv: '' is not a valid value for row 'module' under column 'projectValueDelta'";
    public static String WATTCLASS_VALUE_MISSING_NPV_ERROR = "ValidationError: NPV_Rank.csv: '' is not a valid value for row 'module' under column 'wattClass'";
    public static String MODULEPRICEWITHOUTMARGIN_VALUE_MISSING_NPV_ERROR = "ValidationError: NPV_Rank.csv: '' is not a valid value for row 'module' under column 'modulePriceWithShippingAndPortAdders'";
    public static String QUATERSELECTION_VALUE_MISSING_PROJECT_ERROR = "ValidationError: Project_Properties.csv: '' is not a valid value for row 'value' under column 'quarterSelection'";
    public static String KEYFIELD_MISSING_PROJECT_ERROR = "ValidationError: Project_Properties.csv: key key is required";
    public static String DATATYPE_MISSING_PROJECT_ERROR = "ValidationError: Project_Properties.csv: key dataType is required";
    public static String VISIBILITY_FIELD_MISSING_PROJECT_ERROR = "ValidationError: Project_Properties.csv: key visibility is required";
    public static String DISPLAYSIGNIFICANT_FIELD_MISSING_PROJECT_ERROR = "ValidationError: Project_Properties.csv: key displaySignificantDigits is required";
    public static String UNIT_FIELD_MISSING_PROJECT_ERROR = "ValidationError: Project_Properties.csv: key unit is required";
    public static String UNITPLACEMENT_FIELD_MISSING_PROJECT_ERROR = "ValidationError: Project_Properties.csv: key unitPlacement is required";
    public static String SPACE_PROJECT_ERROR = "ServerError: TypeError: Cannot read property 'quarter' of undefined";
    public static String KEY_VALUE_MISSING_NPV_ERROR = "ValidationError: NPV_Rank.csv: '' is not a valid value for row 'key' under column ''";
    public static String DISPLAY_NAME_VALUE_MISSING_ERROR = "ValidationError: NPV_Rank.csv: '' is not a valid value for row 'Display Name' under column 'rank'";
    public static String VISIBILITY_KEY_MISSING_NPV_ERROR = "ValidationError: NPV_Rank.csv: key visibility is required";
    public static String VISIBILITY_VALUE_MISSING_NPV_ERROR = "ValidationError: NPV_Rank.csv: '' is not a valid value for row 'visibility' under column 'rank'";

    public static String getError(String errorCode) {
        switch (errorCode) {
            case "VISIBILITY_ERROR":
                return VISIBILITY_ERROR;
            case "EPC_MARGIN_ERROR":
                return EPC_MARGIN_ERROR;
            case "MODULE_MARGIN_ERROR":
                return MODULE_MARGIN_ERROR;
            case "SALES_TAX_ERROR":
                return SALES_TAX_ERROR;
            case "PORT_VALUE_ERROR":
                return PORT_VALUE_ERROR;
            case "SHIPING_VALUE_ERROR":
                return SHIPING_VALUE_ERROR;
            case "SCENARIO_VALUE_ERROR":
                return SCENARIO_VALUE_ERROR;
            case "BMOT_VERSION_ERROR":
                return BMOT_VERSION_ERROR;
            case "DISPLAY_NAME_MISSING_ERROR":
                return DISPLAY_NAME_MISSING_ERROR;
            case "QUATER_SELECTION_MISSING_ERROR":
                return QUATER_SELECTION_MISSING_ERROR;
            case "NPV_RANK_DISPLAY_NAME_ERROR":
                return NPV_RANK_DISPLAY_NAME_ERROR;
            case "NPV_RANK_KEY_MISSING_ERROR":
                return NPV_RANK_KEY_MISSING_ERROR;
            case "UUID_MISSING_ERROR":
                return UUID_MISSING_ERROR;
            case "PROJECT_PROPERTIES_VALUE_MISSING_ERROR":
                return PROJECT_PROPERTIES_VALUE_MISSING_ERROR;
            case "UNSUPPORTED_WATT_VALUE":
                return UNSUPPORTED_WATT_VALUE;
            case "SYSTEM_SIZE_VALUE_MISSING_ERROR":
                return SYSTEM_SIZE_VALUE_MISSING_ERROR;
            case "DATA_TYPE_MISSING_NPV_ERROR":
                return DATA_TYPE_MISSING_NPV_ERROR;
            case "DATA_TYPE_FIELDNAME_MISSING_NPV_ERROR":
                return DATA_TYPE_FIELDNAME_MISSING_NPV_ERROR;
            case "DISPLAYSIGNIFICANT_FIELDNAME_MISSING_NPV_ERROR":
                return DISPLAYSIGNIFICANT_FIELDNAME_MISSING_NPV_ERROR;
            case "UNIT_FIELDNAME_MISSING_NPV_ERROR":
                return UNIT_FIELDNAME_MISSING_NPV_ERROR;
            case "UNITPLACEMENT_FIELDNAME_MISSING_NPV_ERROR":
                return UNITPLACEMENT_FIELDNAME_MISSING_NPV_ERROR;
            case "TEXTALINGMENT_FIELDNAME_MISSING_NPV_ERROR":
                return TEXTALINGMENT_FIELDNAME_MISSING_NPV_ERROR;
            case "MODULE_FIELDNAME_MISSING_NPV_ERROR":
                return MODULE_FIELDNAME_MISSING_NPV_ERROR;
            case "VENDOR_VALUE_MISSING_NPV_ERROR":
                return VENDOR_VALUE_MISSING_NPV_ERROR;
            case "MODULENAME_VALUE_MISSING_NPV_ERROR":
                return MODULENAME_VALUE_MISSING_NPV_ERROR;
            case "MODULEFIRST_NULLVALUE_NPV_ERROR":
                return MODULEFIRST_NULLVALUE_NPV_ERROR;
            case "MODULEPRICEWITHOUTSALESTAX_VALUE_NPV_ERROR":
                return MODULEPRICEWITHOUTSALESTAX_VALUE_NPV_ERROR;
            case "NPVDELTA_VALUE_MISSING_NPV_ERROR":
                return NPVDELTA_VALUE_MISSING_NPV_ERROR;
            case "PROJECTVALUEDELTA_VALUE_MISSING_NPV_ERROR":
                return PROJECTVALUEDELTA_VALUE_MISSING_NPV_ERROR;
            case "EPCPRICESAVINGS_VALUE_MISSING_NPV_ERROR":
                return EPCPRICESAVINGS_VALUE_MISSING_NPV_ERROR;
            case "WATTCLASS_VALUE_MISSING_NPV_ERROR":
                return WATTCLASS_VALUE_MISSING_NPV_ERROR;
            case "MODULEPRICEWITHOUTMARGIN_VALUE_MISSING_NPV_ERROR":
                return MODULEPRICEWITHOUTMARGIN_VALUE_MISSING_NPV_ERROR;
            case "QUATERSELECTION_VALUE_MISSING_PROJECT_ERROR":
                return QUATERSELECTION_VALUE_MISSING_PROJECT_ERROR;
            case "KEYFIELD_MISSING_PROJECT_ERROR":
                return KEYFIELD_MISSING_PROJECT_ERROR;
            case "DATATYPE_MISSING_PROJECT_ERROR":
                return DATATYPE_MISSING_PROJECT_ERROR;
            case "VISIBILITY_FIELD_MISSING_PROJECT_ERROR":
                return VISIBILITY_FIELD_MISSING_PROJECT_ERROR;
            case "DISPLAYSIGNIFICANT_FIELD_MISSING_PROJECT_ERROR":
                return DISPLAYSIGNIFICANT_FIELD_MISSING_PROJECT_ERROR;
            case "UNIT_FIELD_MISSING_PROJECT_ERROR":
                return UNIT_FIELD_MISSING_PROJECT_ERROR;
            case "UNITPLACEMENT_FIELD_MISSING_PROJECT_ERROR":
                return UNITPLACEMENT_FIELD_MISSING_PROJECT_ERROR;
            case "SPACE_PROJECT_ERROR":
                return SPACE_PROJECT_ERROR;
            case "DISPLAY_NAME_VALUE_MISSING_ERROR":
                return DISPLAY_NAME_VALUE_MISSING_ERROR;
            case "KEY_VALUE_MISSING_NPV_ERROR":
                return KEY_VALUE_MISSING_NPV_ERROR;
            case "VISIBILITY_KEY_MISSING_NPV_ERROR":
                return VISIBILITY_KEY_MISSING_NPV_ERROR;
            case "VISIBILITY_VALUE_MISSING_NPV_ERROR":
                return VISIBILITY_VALUE_MISSING_NPV_ERROR;
            default:
                throw new IllegalArgumentException("Unexpected value: " + errorCode);
        }
    }

}
