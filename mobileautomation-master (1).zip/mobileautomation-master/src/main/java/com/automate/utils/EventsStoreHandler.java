package com.automate.utils;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class EventsStoreHandler {

   public static Map<String,Map<String,String>> EventsStore = new HashMap<>();

   public static void generateEventStore()
   {

       try
       {
         String filePath = System.getProperty("user.dir")+"/validations/Validations.xlsx";

         // Reading file from local directory
         FileInputStream file = new FileInputStream(
           new File(filePath));

         // Create Workbook instance holding reference to
         // .xlsx file
         XSSFWorkbook workbook = new XSSFWorkbook(file);

         // Get first/desired sheet from the workbook
         XSSFSheet sheet = workbook.getSheetAt(0);

         // Iterate through each rows one by one
         Iterator<Row> rowIterator = sheet.iterator();

         // skipping headers
         rowIterator.next();

         // Till there is an element condition holds true
         while (rowIterator.hasNext()) {

           Row row = rowIterator.next();

           // For each row, iterate through all the
           // columns
           Iterator<Cell> cellIterator
             = row.cellIterator();

            String sotType = row.getCell(5).getStringCellValue();
            String valToProcess = row.getCell(6).getStringCellValue();
            Map<String,String> processedMap = processStringToEventMap(valToProcess);
            EventsStore.put(sotType,processedMap);
         }

         // Closing file output streams
         file.close();
       }

       // Catch block to handle exceptions
       catch (Exception e) {

         // Display the exception along with line number
         // using printStackTrace() method
         e.printStackTrace();
       }
   }


   private static Map<String,String> processStringToEventMap(String val)
   {
      Map<String,String> processedMap = new HashMap<>();

      try{
        if(val.equals("NA")|| val==null|| val.equals("N/A"))
        {
          return null;
        }
        else {
          String[] primaryData = val.split(",");
          for (String secondaryData : primaryData) {

            String[] process = secondaryData.split(":");
            if(process.length==2)
              processedMap.put(process[0],process[1]);
          }
        }

      }catch(Exception e){
        e.printStackTrace();
      }


      return processedMap;
   }

}
