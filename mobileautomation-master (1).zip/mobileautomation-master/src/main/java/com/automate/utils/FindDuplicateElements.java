package com.automate.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;

import java.util.Arrays;

public class FindDuplicateElements {

    public static void main(String[] args) throws IOException, CsvException {
        String csvFolderPath = "src/main/resources";
        Map<String, List<String>> duplicatesMap = new HashMap<>();

        File file = new File(csvFolderPath);
        List<File> allFiles = Arrays.asList(file.listFiles());

        for (File eachFile : allFiles) {
            if (eachFile.getName().endsWith(".csv") && !eachFile.getName().endsWith("Data.csv")) {
                try (CSVReader reader = new CSVReader(new FileReader(eachFile))) {
                    List<String[]> allCSVrows = reader.readAll();
                    List<String> headers = Arrays.asList(allCSVrows.remove(0));
                    for (String[] eachRow : allCSVrows) {
                        List<String> row = Arrays.asList(eachRow);
                        List<String> elementDuplicatedFilenames = new ArrayList<>();
                        String key = row.get(0).toLowerCase();
                        if (duplicatesMap.containsKey(key)) {
                            elementDuplicatedFilenames = duplicatesMap.get(key);
                        }
                        elementDuplicatedFilenames.add(eachFile.getName());
                        duplicatesMap.put(key, elementDuplicatedFilenames);
                    }
                }
            }
        }
        for (Entry<String, List<String>> eachEntry : duplicatesMap.entrySet()) {
            if (eachEntry.getValue().size() > 1) {
                System.out.println(eachEntry);
            }
        }
    }

}
