package com.automate.utils.screenshot;

import com.aventstack.extentreports.model.Media;
import io.appium.java_client.AppiumDriver;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class ScreenshotService {

  // Abstract layer to handle the change in business requirement
  public static String getScreenshotAsBase64(AppiumDriver driver) {
    return ScreenshotUtils.captureScreenshotAsBase64(driver);
  }
  
  public static void getScreenshotAsBase64() {
	   
	  }
}
