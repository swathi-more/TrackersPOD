package com.automate.utils.screenshot;

import com.automate.constants.FrameworkConstants;

import io.appium.java_client.AppiumDriver;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import java.io.File;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class ScreenshotUtils {

  // This class is to handle the change in third party library
  @SneakyThrows
  public static String captureScreenshotAsFile(AppiumDriver driver,String testName) {
    File source = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
    long timestamp = System.currentTimeMillis();
    String path = FrameworkConstants.SCREENSHOT_PATH + File.separator + testName+"_"+timestamp + ".png";
    File destination = new File(path);
    FileUtils.copyFile(source, destination);
    System.out.println(path);
    return path;
  }

  public static String captureScreenshotAsBase64(AppiumDriver driver) {
    return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
  }
  
  public static void captureScreenshotAsBase64() {
	   
	  }
}
