package com.automate.commands;

import java.io.File;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Collections;
import java.util.Date;

import com.automate.constants.FrameworkConstants;
import io.appium.java_client.TouchAction;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.touch.offset.PointOption;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.automate.utils.LoggingUtils;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;

import io.appium.java_client.AppiumDriver;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;


public class AppiumCommands {

	private static final Logger logger = LogManager.getLogger(MobileCommands.class);
	AppiumDriver driver;
	Util util;
	LoggingUtils loggingUtils;
	ServiceLocator service = ServiceLocator.getInstance();

	public AppiumCommands(AppiumDriver driver, Util util) {
		this.driver = driver;
		this.util = util;
	}

  public void customWait(int sec)
  {
    try {
      Thread.sleep(1000*sec);
    } catch (InterruptedException e) {
      throw new RuntimeException(e);
    }
  }

  public void hideIOSKeyBoard()
  {
    IOSDriver driver1 =(IOSDriver) driver;
    driver1.hideKeyboard();
  }

	public void click(String variableName) {
		logger.info("Start of Command Execution||CommandName=Click");

    checkElementIsVisibleOnPage(variableName);
		WebElement element = util.findElement(variableName);

		try {
			element.click();
		} catch (Exception e) {
			try {
				logger.info("WebElement click failed. Applying Autoheal..");
				
				if (element != null) {
					element = util.findElement(variableName);
					JavascriptExecutor js = (JavascriptExecutor) driver;
					js.executeScript("arguments[0].click()", element);
				} else {
					Assert.fail("Element Not Found||Error=" + e);

				}
			} catch (Exception ex) {
				logger.error("Javascript click also failed||Error=", ex);

				Assert.fail("Unable to click on element : " + variableName);
				driver.quit();
			}
		} finally {
			captureScreenshot();
		}
		logger.info("End of Command Execution||CommandName=Click");

	}

	@SuppressWarnings("finally")
	public String getText(String variableName) {
		logger.info("Start of Command Execution||CommandName=GetText");
    checkElementIsVisibleOnPage(variableName);
		WebElement element = util.findElement(variableName);
		String text = null;
		try {
			text = element.getText();
			logger.info("End of Command Execution||CommandName=GetText");

		} catch (Exception e) {
			logger.error("End of Command Execution||CommandName=GetText||Error=", e);

		} finally {
			captureScreenshot();
			return text;
		}
	}

	public boolean checkElementIsVisibleOnPage(String variableName) {
		try {
			WebElement element = util.findElement(variableName);
			logger.info("Start of Check Element Visibility");
			
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(FrameworkConstants.EXPLICIT_WAIT));
			wait.until(ExpectedConditions.visibilityOf(element));
			logger.info("End of Check Element Visibility on Screen");

			logger.info("Element present on Screen");

			return true;
		} catch (Exception e) {
			logger.info("End of Check Element Visibility on Screen");

		}
		return false;
	}

	public boolean checkElementIsVisibleOnPageMobile(String variableName) {
		try {
			WebElement element = util.findElement(variableName);
			logger.info("Start of Check Element Visibility");

			if (element != null) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			logger.info("End of Check Element Visibility on Screen");
		}
		return false;
	}

	public boolean checkElementIsVisibleOnPage(String variableName, int timeoutInSecs) {
		try {
			WebElement element = util.findElement(variableName);
			logger.info("Start of Check Element Visibility");

			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(FrameworkConstants.EXPLICIT_WAIT));
			wait.until(ExpectedConditions.visibilityOf(element));
			logger.info("End of Check Element Visibility on Screen");

			logger.info("Element present on Screen");

			return true;
		} catch (Exception e) {
			logger.info("End of Check Element Visibility on Screen");

		}
		return false;
	}

	public boolean checkElementIsNotVisibleOnPage(String variableName) {
		try {
			WebElement element = util.findElement(variableName);
			logger.info("Start of Check Element Not Visible");

			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(FrameworkConstants.EXPLICIT_WAIT));
			wait.until(ExpectedConditions.invisibilityOf(element));
			logger.info("End of Check Element Not Visible");

			return true;
		} catch (Exception e) {
			logger.info("End of Check Element Not Visible");

		}
		return false;
	}

	public boolean checkElementIsEnabledOnPage(String variableName) {
		try {
			WebElement element = util.findElement(variableName);
			logger.info("Start of Check Element Enabled");

			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(FrameworkConstants.EXPLICIT_WAIT));
			wait.until(ExpectedConditions.elementToBeClickable(element));

			logger.info("End of Check Element Enabled on Screen");

			return true;
		} catch (Exception e) {
			logger.info("End of Check Element Enabled on Screen");

		}
		return false;
	}
  public boolean checkElementIsDisabledOnPage(String variableName) {
    try {
      WebElement element = util.findElement(variableName);
      logger.info("Start of Check Element Enabled");

      WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(FrameworkConstants.EXPLICIT_WAIT));
      wait.until(ExpectedConditions.elementToBeClickable(element));

      logger.info("End of Check Element Disabled on Screen");

      return true;
    } catch (Exception e) {
      logger.info("End of Check Element Disabled on Screen");

    }
    return false;

  }

	public void type(String variableName, String str) {

		logger.info("Start of Command Execution||CommandName=Type");
    checkElementIsVisibleOnPage(variableName);
		WebElement element = util.findElement(variableName);

		if (str.startsWith("src/test/resources/UploadFiles/")) {
			str = new File(str).getAbsolutePath();
		}

		try {
			try {
				element.clear();
				element.sendKeys( "a");
				element.sendKeys(Keys.DELETE);
			} catch (Exception e) {
			}
			element.clear();
			element.sendKeys(str);
			logger.info("End of Command Execution||CommandName=Type");

		} catch (Exception e) {
			logger.error("End of Command Execution||CommandName=Type||Error=", e);

			Assert.fail("Unable to send keys to " + variableName);
			driver.quit();
		} finally {
			captureScreenshot();
		}
	}

	public void captureScreenshot() {

		TakesScreenshot scrShot = ((TakesScreenshot) driver);
		File srcFile = scrShot.getScreenshotAs(OutputType.FILE);
		LoggingUtils.log(srcFile, "Snapshot");
	}

	// This is not yet completed
	public void captureFullPageScreenshot() {
		try {
			Screenshot s = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000))
					.takeScreenshot(driver);
			File file = null;
//				ImageIO.write(s.getImage(), "PNG", file);
		} catch (Exception e) {
		}
	}
  public void sendKeys(String variableName, Keys key) throws InterruptedException {
    logger.info("Start of Command Execution||CommandName=SendKeys");
    checkElementIsVisibleOnPage(variableName);
    WebElement element = util.findElement(variableName);
    try {
      element.sendKeys(key);
      logger.info("End of Command Execution||CommandName=SendKeys");
    } catch (Exception e) {
      driver.quit();
      logger.error("End of Command Execution||CommandName=SendKeys||Error=", e);
      Assert.fail("Unable to send keys to " + variableName);
    } finally {
      captureScreenshot();
    }
  }
  public void scrollToViewElement(String variableName) {
    logger.info("Start of Command Execution||CommandName=ScrollToView");
    try {
      WebElement element = util.findElementByAndroidUIAutomation(variableName);
    } catch (Exception e) {
      logger.error("End of Command Execution||CommandName=ScrollToView||Error=", e);
      Assert.fail("Unable to scroll to element " + variableName);
      driver.quit();
    } finally {
      captureScreenshot();
    }
  }

  public void performScroll() {
    Dimension size = driver.manage().window().getSize();
    int startX = size.getWidth() / 2;
    int endX = size.getWidth() / 2;
    int startY = size.getHeight() / 2;
    int endY = (int) (size.getHeight() * 0.25);

    performScrollUsingSequence(startX, startY, endX, endY);
  }


  public void performScrollBottomToUp() {
    Dimension size = driver.manage().window().getSize();
    int startX = size.getWidth() / 2;
    int endX = size.getWidth() / 2;
    int startY = size.getHeight() / 2;
    int endY = (int) (size.getHeight() * 0.25);

    performScrollUsingSequence(endX, endY,startX, startY);
  }

  public void performScrollUsingSequence(int startX, int startY, int endX, int endY) {
    PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "first-finger");
    Sequence sequence = new Sequence(finger, 0)
      .addAction(finger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), startX, startY))
      .addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
      .addAction(finger.createPointerMove(Duration.ofMillis(300), PointerInput.Origin.viewport(), endX, endY))
      .addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));

    ((AppiumDriver)(driver)).perform(Collections.singletonList(sequence));
  }

  public String getCurrentTime() {
    logger.info("Start of Command Execution||CommandName=GetCurrentDate");
    String text = null;
    try {
      SimpleDateFormat formatter = new SimpleDateFormat("yyMMddHHmmss");
      Date date = new Date();
      text = formatter.format(date);

      logger.info("End of Command Execution||CommandName=GetCurrentDate");
    } catch (Exception e) {
      logger.error("End of Command Execution||CommandName=GetCurrentDate||Error=", e);
    } finally {
      captureScreenshot();
      return text;
    }
  }
  

    public String generateRandomString(int length) {
      logger.info("Start of Command Execution||CommandName=generateRandomString");
      String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
      SecureRandom secureRandom = new SecureRandom();
      StringBuilder stringBuilder = new StringBuilder(length);
      try {
        for (int i = 0; i < length; i++) {
          int randomIndex = secureRandom.nextInt(characters.length());
          char randomChar = characters.charAt(randomIndex);
          stringBuilder.append(randomChar);
        }
        logger.info("End of Command Execution||CommandName=GetCurrentDate");
      } catch (Exception e){
        logger.error("End of Command Execution||CommandName=GetCurrentDate||Error=", e);
      }finally {
        captureScreenshot();
        return stringBuilder.toString();
      }
    }

}
