package com.automate.commands;



import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.automate.utils.LoggingUtils;
import com.automate.utils.ServiceLocator;
import com.automate.utils.Util;

import io.appium.java_client.AppiumDriver;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;
import java.time.Duration;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;


public class MobileCommands {
   private static final Logger logger = LogManager.getLogger(MobileCommands.class);
   AppiumDriver driver;
   Util util;
   LoggingUtils loggingUtils;
   ServiceLocator service = ServiceLocator.getInstance();

   public MobileCommands(AppiumDriver driver, Util util) {
       this.driver = driver;
       this.util = util;
   }

   /**
    * Check if the element is visible on the screen The
    *
    * @param element
    * @return boolean
    */
   public boolean checkElementIsVisibleOnPage(String variableName) {
       try {
           WebElement element = util.findElement(variableName);
           logger.info("Start of Check Element Visibility");
           WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(90));
           wait.until(ExpectedConditions.visibilityOf(element));
           logger.info("End of Check Element Visibility on Screen");

           logger.info("Element present on Screen");
           return true;
       } catch (Exception e) {
           logger.info("End of Check Element Visibility on Screen");
       }
       return false;
   }
  

   @SuppressWarnings("finally")
   public String getCurrentYear() {
       logger.info("Start of Command Execution||CommandName=GetCurrentYear");
       String text = null;
       try {
           SimpleDateFormat formatter = new SimpleDateFormat("yyyy");
           Date year = new Date();
           text = formatter.format(year);

           logger.info("End of Command Execution||CommandName=GetCurrentYear");
       } catch (Exception e) {
           logger.error("End of Command Execution||CommandName=GetCurrentYear||Error=", e);
       } finally {
           captureScreenshot();
           return text;
       }
   }

   @SuppressWarnings("finally")
   public String getCurrentDay() {
       logger.info("Start of Command Execution||CommandName=GetCurrentDay");
       String text = null;
       try {
           SimpleDateFormat formatter = new SimpleDateFormat("dd");
           Date year = new Date();
           text = formatter.format(year);

           logger.info("End of Command Execution||CommandName=GetCurrentDay");
       } catch (Exception e) {
           logger.error("End of Command Execution||CommandName=GetCurrentDay||Error=", e);
       } finally {
           captureScreenshot();
           return text;
       }
   }
   
   @SuppressWarnings("finally")
   public String getCurrentDayZ() {
       logger.info("Start of Command Execution||CommandName=GetCurrentDay");
       String text = null;
       try {
           SimpleDateFormat formatter = new SimpleDateFormat("d");
           Date year = new Date();
           text = formatter.format(year);

           logger.info("End of Command Execution||CommandName=GetCurrentDay");
       } catch (Exception e) {
           logger.error("End of Command Execution||CommandName=GetCurrentDay||Error=", e);
       } finally {
           captureScreenshot();
           return text;
       }
   }

   public void customWait(int timeInSeconds) {
       try {
           Thread.sleep(timeInSeconds * 1000L);
       } catch (Exception e) {
       }
   }
   
   public void captureScreenshot() {
       TakesScreenshot scrShot = ((TakesScreenshot) driver);
       File srcFile = scrShot.getScreenshotAs(OutputType.FILE);
       LoggingUtils.log(srcFile, "Snapshot");
   }

   //	This is not yet completed
   public void captureFullPageScreenshot() {
       try {
           Screenshot s = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver);
           File file = null;
//			ImageIO.write(s.getImage(), "PNG", file);
       } catch (Exception e) {
       }
   }

}
