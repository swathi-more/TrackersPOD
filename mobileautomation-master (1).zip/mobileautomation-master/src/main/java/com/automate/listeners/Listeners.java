package com.automate.listeners;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.reports.main.ExtentReportLogger;
import com.automate.reports.main.ExtentReportManager;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class Listeners implements ITestListener, ISuiteListener {

  @Override
  public void onStart(ISuite suite) {
	  try {
		  ExtentReportManager.initExtentReport();
	  }catch(Exception e) {
		  e.printStackTrace();
	  }
    
  }

  @Override
  public void onTestStart(ITestResult result) {
	  try {
		  ExtentReportManager.createTest(result.getMethod().getMethodName());
		    ExtentReportManager.addAuthors(
		      result.getMethod().getConstructorOrMethod().getMethod().getAnnotation(FrameworkAnnotation.class).author());
		    ExtentReportManager.addCategories(
		      result.getMethod().getConstructorOrMethod().getMethod().getAnnotation(FrameworkAnnotation.class).category());
		    ExtentReportManager.addDevices();
		    ExtentReportLogger.logInfo("Test - <b>" + result.getMethod().getMethodName() + "</b> is started");
	  }catch(Exception e) {
		  e.printStackTrace();
	  }
    
  }

  @Override
  public void onTestSuccess(ITestResult result) {
    ExtentReportLogger.logPass("Test - <b>" + result.getMethod().getMethodName() + "</b> is passed");
  }

  @Override
  public void onTestFailure(ITestResult result) {
    ExtentReportLogger.logFail("Test - <b>" + result.getMethod().getMethodName() + "</b> is failed", result.getThrowable());
  }

  @Override
  public void onTestSkipped(ITestResult result) {
    ExtentReportLogger.logSkip("Test - <b>" + result.getMethod().getMethodName() + "</b> is skipped");
  }

  @Override
  public void onFinish(ISuite suite) {
    ExtentReportManager.flushExtentReport();
  }

  @Override
  public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
    // No implementation
  }

  @Override
  public void onStart(ITestContext iTestContext) {
    // No implementation
  }

  @Override
  public void onFinish(ITestContext iTestContext) {
    // No implementation
  }
}
