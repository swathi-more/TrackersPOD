package com.tests.android.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.android.*;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import com.tests.android.store.StoreSetup;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.geolocation.AndroidGeoLocation;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class QuizzQuestion extends BaseTest {

  // mandatory objects for TC
  private static final Logger logger = LogManager.getLogger(QuizzQuestion.class);
  private ExtentReportLogger extentLogger= new ExtentReportLogger();
  private BrowserMobProxyServer proxy;
  private AndroidDriver androidDriver;
  private ExtentTest test;
  private int i;

  // page objects
  private LovesActivity lovesActivity;
 private StoresActivity storesActivity;
  private FindASephoraActivity findASephoraActivity;
  private StoreModeActivity  storeModeActivity;
  private OnBoardingActivity onBoardingActivity;

  private BottomMenu bottomMenu;


  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {

    Har har =  proxy.getHar();
    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();

    boolean testCasesStatus=false;

    // iterating over Events captured
    while (itr.hasNext()) {
      Event obj = (Event) itr.next();
      if(obj.getSotVars().getSotType().equals("productfinder")) {
          testCasesStatus = true;
      }
      test.info("Event : " + obj.getSotVars().toString());
      logger.info(obj.getSotVars().toString());
    }
    if(!testCasesStatus) {
      test.fail("Event not found");
    }

    // write all backend data
    File harFile = new File("events/bottomMenuEvents.har");
    har.writeTo(harFile);
  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void BottomMenuLinksTest() throws InterruptedException, IOException, CsvException {

    // creating test case for report logging
    test = extentLogger.startTest("BeutyBoardLove");

    // getting proxy object
    proxy = getBMPObj();

    // assigning CA as default location to device
    androidDriver = (AndroidDriver) getDriver();
    androidDriver.setLocation(new AndroidGeoLocation(40.72410526596255, -73.9983931887117));

    // creating har file for end result
    proxy.newHar("test01");

    onBoardingActivity = new OnBoardingActivity(getDriver());
    bottomMenu = new BottomMenu(getDriver());
    storesActivity = new StoresActivity(getDriver());
    findASephoraActivity = new FindASephoraActivity(getDriver());
    StoreSetup storeSetup = new StoreSetup(getDriver());
    storeModeActivity = new StoreModeActivity(getDriver());
    lovesActivity = new LovesActivity(getDriver());

    //perform store setup
    storeSetup.createStore();
    test.info("User Perform store setup", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BeutyBoardQuizz")).build());
    logger.info("User Perform store setup");

    // click on Stores navigation
    bottomMenu.clickOnStoresNavIcon();
    test.info("User click on Stores navigation", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BeutyBoardQuizz")).build());
    logger.info("User click on Stores navigation");

    storesActivity.clickOnStoreModeAfterStoreIsEnabled();
    test.info("User click on Stores navigation", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BeutyBoardQuizz")).build());
    logger.info("User click on Stores navigation");
    //storesActivity.clickStoreIconCheck();

    //storesActivity.checkproductStore();

//    storesActivity.ViewBasket();
//    test.info("User click on ViewBasket", MediaEntityBuilder.createScreenCaptureFromPath(
//      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BeutyBoardQuizz")).build());
//
//    storesActivity.StoreCheck();
//    test.info("StoreCheck", MediaEntityBuilder.createScreenCaptureFromPath(
//      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BeutyBoardQuizz")).build());


    // click on store mode
    storesActivity.Quizzes();
    test.info("Click on quizz", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BeutyBoardQuizz")).build());
    logger.info("User click on Stores navigation");

    storesActivity.fragracequizz();
    test.info("Click on quizz", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BeutyBoardQuizz")).build());

    storesActivity.StartQuizz();
    test.info("Start the quizz", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BeutyBoardQuizz")).build());

    storesActivity.ClickfirstAns();
    test.info("Click on first Ans", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BeutyBoardQuizz")).build());

    storesActivity.ClickSecAns();
    test.info("click on SecAns", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BeutyBoardQuizz")).build());

    storesActivity.ClickThirdAns();
    test.info("Click on Third Ans", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BeutyBoardQuizz")).build());

    storesActivity.CheckYouFound();
    test.info("click on YouFound", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BeutyBoardQuizz")).build());


  }

}
