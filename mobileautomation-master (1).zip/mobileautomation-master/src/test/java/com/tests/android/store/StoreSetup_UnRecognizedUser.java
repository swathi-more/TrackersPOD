package com.tests.android.store;

import com.automate.pages.android.*;
import com.opencsv.exceptions.CsvException;
import io.appium.java_client.AppiumDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;


public class StoreSetup_UnRecognizedUser {

 // mandatory
  private static final Logger logger = LogManager.getLogger(StoreSetup_UnRecognizedUser.class);


  // pom
  private OnBoardingActivity onBoardingActivity;
  private BottomMenu bottomMenu;
  private ProfileActivity profileActivity;
  private AppSettingsActivity appSettingsActivity;
  private DebugActivity debugActivity;
  private DebugStoreModeActivity debugStoreModeActivity;
  private StoreModeVisitControllerActivity storeModeVisitControllerActivity;
  private CreateStoreVisitActivity createStoreVisitActivity;
  private SignUp signUp;
  private AppiumDriver driver;

  private int i;

  public StoreSetup_UnRecognizedUser(AppiumDriver localDriver)
  {
    this.driver = localDriver;
  }

  public AppiumDriver getDriver()
  {
    return driver;
  }

  public void createStore_UnRecognized() throws IOException, CsvException, InterruptedException {
    onBoardingActivity = new OnBoardingActivity(getDriver());
    bottomMenu = new BottomMenu(getDriver());
    profileActivity = new ProfileActivity(getDriver());
    appSettingsActivity = new AppSettingsActivity(getDriver());
    debugActivity = new DebugActivity(getDriver());
    debugStoreModeActivity = new DebugStoreModeActivity(getDriver());
    storeModeVisitControllerActivity = new StoreModeVisitControllerActivity(getDriver());
    createStoreVisitActivity = new CreateStoreVisitActivity(getDriver());
    signUp = new SignUp(getDriver());

    i=0;
    //click on Skip Now Button
    onBoardingActivity.clickOnSkipNowButton();

    // click on me profile tab
    bottomMenu.clickOnMeIcon();

    // scroll to App settings
    profileActivity.scrollToAppSettings();

    // click on app settings
    profileActivity.clickOnAppSettingsLink();

    // click on debug mode
    appSettingsActivity.clickOnDebugModeLink();

    // click on store mode
    debugActivity.clickOnStoreModeLink();

    // click on store mode visit controller
    debugStoreModeActivity.clickOnStoreModeVisitControllerLink();

    // click on add icon
    storeModeVisitControllerActivity.clickOnAddFakeStoreIcon();

    // create store with details
    createStoreVisitActivity.createStoreWithDefaultValues();

    // select the fake store
    storeModeVisitControllerActivity.selectFakeStore();

  }

}
