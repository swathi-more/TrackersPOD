package com.tests.android.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.android.*;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.TextFileWriter;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import com.tests.android.store.StoreSetup;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.geolocation.AndroidGeoLocation;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class SortDropDown extends BaseTest {

  private static final Logger logger = LogManager.getLogger(SortDropDown.class);
  private ExtentReportLogger extentLogger= new ExtentReportLogger();
  private BrowserMobProxyServer proxy;

  private OnBoardingActivity onBoardingActivity;
  private BottomMenu bottomMenu;

  private StoresActivity storesActivity;

  private FindASephoraActivity findASephoraActivity;
  private StoreModeActivity storeModeActivity;
  private LovesActivity lovesActivity;

  private AndroidDriver androidDriver;

  private ExtentTest test;
  TextFileWriter textFileWriter = new TextFileWriter();

  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {

    Har har =  proxy.getHar();

    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();
    textFileWriter.writeEventsToFile(eventList);
    while (itr.hasNext())
    {
      Event obj = (Event) itr.next();
      test.info("Event  : "+obj.getSotVars().toString());
      System.out.println( "Event SOTV01 : "+obj.getSotVars().getSotV01());
      System.out.println( "Event SOTV88 : "+obj.getSotVars().getSotV88());

    }
    File harFile = new File("event.har");
    har.writeTo(harFile);
  }
  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void storeLovesTest() throws IOException, CsvException, InterruptedException {

    test = extentLogger.startTest("Store Sort Dropdown");
    proxy = getBMPObj();

    androidDriver = (AndroidDriver) getDriver();
    androidDriver.setLocation(new AndroidGeoLocation(40.72410526596255, -73.9983931887117));

    proxy.newHar("storeDetails");

    Thread.sleep(5000);

    onBoardingActivity = new OnBoardingActivity(getDriver());
    bottomMenu = new BottomMenu(getDriver());
    storesActivity = new StoresActivity(getDriver());
    findASephoraActivity = new FindASephoraActivity(getDriver());
    StoreSetup storeSetup = new StoreSetup(getDriver());
    storeModeActivity = new StoreModeActivity(getDriver());
    lovesActivity = new LovesActivity(getDriver());

    //perform store setup
    storeSetup.createStore();
    test.info("User Perform store setup", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SortDropDown")).build());
    logger.info("User Perform store setup");

    //User click on Stores navigation
    bottomMenu.clickOnStoresNavIcon();
    test.info("User click on Stores navigation", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SortDropDown")).build());
    logger.info("User click on Stores navigation");

    // click on store mode
    storesActivity.clickOnStoreModeAfterStoreIsEnabled();
    test.info("User click on store mode", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SortDropDown")).build());
    logger.info("User click on store mode");

    // click on Buy it Again
    storeModeActivity.clickOnBuyItAgainCard();
    test.info("User click Buy it again Card", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SortDropDown")).build());
    logger.info("User click Buy it again Card");

    // validate store Dropdown
    lovesActivity.validateSortDropdown();
    test.info("User click and Validate the store Dropdown", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SortDropDown")).build());
    logger.info("User click and Validate the store Dropdown");

  }


}
