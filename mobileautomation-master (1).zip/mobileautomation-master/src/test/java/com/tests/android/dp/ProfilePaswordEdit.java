package com.tests.android.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.android.AccountDetailsPage;
import com.automate.pages.android.BottomMenu;
import com.automate.pages.android.HomeActivity;
import com.automate.pages.android.ProfilePage;
import com.automate.pages.android.SignUp;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.geolocation.AndroidGeoLocation;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class ProfilePaswordEdit extends BaseTest {

  // mandatory objects for TC
  private static final Logger logger = LogManager.getLogger(LinkPageTracking.class);
  private ExtentReportLogger extentLogger= new ExtentReportLogger();
  private BrowserMobProxyServer proxy;
  private AndroidDriver androidDriver;
  private ExtentTest test;


  private SignUp signUp;
  private HomeActivity homeActivity;

  private BottomMenu bottomMenu;

  private ProfilePage profilePage;

  private AccountDetailsPage accountDetailsPage;

  private int i;


  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {

    Har har =  proxy.getHar();
    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();

    // iterating over Events captured
    boolean testCaseStatus =false;
    // iterating over Events captured
    while (itr.hasNext())
    {
      Event obj = (Event) itr.next();
      if(obj.getSotVars().getSotType().equals("user profile my account password edit")){
        testCaseStatus = true;
      }
      test.info("Event : "+obj.getSotVars().toString());
      logger.info(obj.getSotVars().toString());
    }
    if(!testCaseStatus){
      test.fail("Event Not Found");
    }
    // write all backend data
    File harFile = new File("events/bottomMenuEvents.har");
    har.writeTo(harFile);
  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void ProfilePaswordEdit() throws InterruptedException, IOException, CsvException {

    // creating test case for report logging
    test = extentLogger.startTest("Verify that user is able to edit password from Me tab and required events are triggered for the same");

    // getting proxy object
    proxy = getBMPObj();

    // assigning CA as default location to device
    androidDriver = (AndroidDriver) getDriver();
    androidDriver.setLocation(new AndroidGeoLocation(40.72410526596255, -73.9983931887117));

    // creating har file for end result
    proxy.newHar("test01");

    signUp = new SignUp(getDriver());
    homeActivity = new HomeActivity(getDriver());
    bottomMenu =  new BottomMenu(getDriver());
    profilePage = new ProfilePage(getDriver());
    accountDetailsPage = new AccountDetailsPage(getDriver());

    //click on SignIn Link
    i = 0;
    //click on SignIn Link
    signUp.clickOnSignInLink();

    //Enter Username and Password and click on Signin Link
    signUp.login(i);
    test.info("User Enter Username and Password Then click on Sign in Link", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test01")).build());
    logger.info("User Enter Username and Password Then click on Sign in Link");

    test.info("User Enter Username and Password Then click on Signin Link", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test01")).build());

    test.info("User clicks on Me/Profile Tab", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test01")).build());
    //Click on Me tab
    bottomMenu.clickOnMeIcon();
    logger.info("Verify whether the profile page opened");

    test.info("User clicks on account Tab" ,MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test01")).build());
    //Click on Accont Tab
    profilePage.clickAccountTab();
    logger.info("Verify whether the accont detaisl page opned");

    test.info("User clicks on Password edit button", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test01")).build());
    //Click on Accont Tab
    accountDetailsPage.clickOnPasswordEditButton();
    logger.info("Verify whether Password pop-up is opned");

    test.info("User edits the Password" ,MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test01")).build());
    //Click on Accont Tab
    accountDetailsPage.editPassword(i);
    test.info("Verify whether Name is Password");


  }

}
