package com.tests.android.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.android.LovesActivity;
import com.automate.pages.android.SignUp;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.geolocation.AndroidGeoLocation;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class SkuListSort extends BaseTest {
  private static final Logger logger = LogManager.getLogger(SkuListSort.class);
  private ExtentReportLogger extentLogger = new ExtentReportLogger();
  private BrowserMobProxyServer proxy;
  private AndroidDriver androidDriver;
  private ExtentTest test;

  private int i;
  SignUp objsignUp;
  LovesActivity objlovemodule;


  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {

    Har har = proxy.getHar();
    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();

    boolean testCasesStatus = false;

    // iterating over Events captured
    while (itr.hasNext()) {
      Event obj = (Event) itr.next();
      if(obj.getSotVars().getSotType().equals("sku items list sort")) {
       if (!obj.getSotVars().getSotV84().equals("null")&&!obj.getSotVars().getSotV158().equals("null")) {
         testCasesStatus = true;
       }
        }
      test.info("Event : " + obj.getSotVars().toString());
      logger.info(obj.getSotVars().toString());
    }
    if(!testCasesStatus) {
      test.fail("Event not found");
    }
    // write all backend data
    File harFile = new File("events/bottomMenuEvents.har");
    har.writeTo(harFile);
  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void LoveModuleActivity() throws InterruptedException, IOException, CsvException {

    // creating test case for report logging
    test = extentLogger.startTest("SkuListSort");

    // getting proxy object
    proxy = getBMPObj();

    // assigning CA as default location to device
    androidDriver = (AndroidDriver) getDriver();
    androidDriver.setLocation(new AndroidGeoLocation(40.72410526596255, -73.9983931887117));

    // creating har file for end result
    proxy.newHar("test01");



    objsignUp = new SignUp(getDriver());
    objlovemodule=new LovesActivity(getDriver());
    i=0;
    objsignUp.clickOnSignInButton();

    objsignUp.enterEmail(i);
    test.info("type the email", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SkuListSort")).build());

    objsignUp.enterPassword(i);
    test.info("type the password", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SkuListSort")).build());

    objsignUp.clickOnSignInButton();
    test.info("checkOnSignInButton", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SkuListSort")).build());

    objlovemodule.clicksearchbar();
    test.info("Checksearchbar", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SkuListSort")).build());

    objlovemodule.searchproduct(i);
    test.info("product name", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SkuListSort")).build());

    objlovemodule.ClickonProductName();
    test.info("product name will visible click on it", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SkuListSort")).build());

    objlovemodule.clickonproduct();
    test.info("Click on product", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SkuListSort")).build());

    objlovemodule.clicklove();
    test.info("products will be visible then click on love", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SkuListSort")).build());

    objlovemodule.clickonloveicon();
    test.info("check loveicon and click", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SkuListSort")).build());

    objlovemodule.sort();
    test.info("click on sort",MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(),"SkuListSort")).build());

    objlovemodule.sortoption();
    test.info("User choose the sorted option",MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(),"SkuList")).build());


  }
}
