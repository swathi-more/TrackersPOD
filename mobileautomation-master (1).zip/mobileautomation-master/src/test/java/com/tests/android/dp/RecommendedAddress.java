package com.tests.android.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.android.AddToBasket;
import com.automate.pages.android.BasketPage;
import com.automate.pages.android.BottomMenu;
import com.automate.pages.android.CheckoutPage;
import com.automate.pages.android.HomeActivity;
import com.automate.pages.android.LovesActivity;
import com.automate.pages.android.ProductsPage;
import com.automate.pages.android.ProfileActivity;
import com.automate.pages.android.SignUp;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.geolocation.AndroidGeoLocation;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class RecommendedAddress extends BaseTest {
  private static final Logger logger = LogManager.getLogger(AddProductToCart.class);
	private ExtentReportLogger extentLogger = new ExtentReportLogger();
	private BrowserMobProxyServer proxy;

	private SignUp signUp;
	private HomeActivity homeActivity;
	private ProductsPage productsPage;
	private AddToBasket addToBasket;
	private BasketPage basketPage;
	private CheckoutPage checkoutPage;
	private BottomMenu bottomMenu;
	private ProfileActivity meActivity;

  private LovesActivity objLoveActivity;
	private AndroidDriver androidDriver;
	private int i;
	private ExtentTest test;

	@AfterMethod
	public void tearDown() throws IOException, InterruptedException {

		Har har = proxy.getHar();

		HarAnalyzer harAnalyzer = new HarAnalyzer();
		List<Event> eventList = harAnalyzer.getRequestFromHar(har);

		Iterator itr = eventList.iterator();
    boolean testCasesStatus = false;

    // iterating over Events captured
    while (itr.hasNext()) {
      Event obj = (Event) itr.next();
      if (obj.getSotVars().getSotType().equals("address verification use recommended address")) {
        testCasesStatus = true;
      }
      test.info("Event : " + obj.getSotVars().toString());
      logger.info(obj.getSotVars().toString());
    }
      if (!testCasesStatus) {
        test.fail("Event not found");
      }

		File harFile = new File("cancelOrder.har");
		har.writeTo(harFile);
	}

	@FrameworkAnnotation(author = "User-1", category = { CategoryType.REGRESSION })
	@Test
	public void test01() throws IOException, CsvException, InterruptedException {

		test = extentLogger.startTest("RecommendedAddress");
		proxy = getBMPObj();

		androidDriver = (AndroidDriver) getDriver();
		androidDriver.setLocation(new AndroidGeoLocation(40.72410526596255, -73.9983931887117));

		proxy.newHar("test01");

		Thread.sleep(5000);

		signUp = new SignUp(getDriver());
		homeActivity = new HomeActivity(getDriver());
		productsPage = new ProductsPage(getDriver());
		addToBasket = new AddToBasket(getDriver());
		basketPage = new BasketPage(getDriver());
		checkoutPage = new CheckoutPage(getDriver());
		bottomMenu = new BottomMenu(getDriver());
		meActivity = new ProfileActivity(getDriver());
    objLoveActivity=new LovesActivity(getDriver());

		i=0;
		// click on SignIn Link
		signUp.clickOnSignInLink();

		// Enter Username and Password and click on Sign in Link
		signUp.login(i);
		test.info("User Enter Username and Password Then click on Sign in Link");
    test.info("User Enter Username and Password Then click on Sign in Link", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AddressSuggsion")).build());

//		// Verify User log into application
//		homeActivity.verifyUserIcon();
//		test.info("Verify whether the user has logged into the application");

		// Click on Basket Button
		//homeActivity.clickOnBasketButton();
		//test.info("User Click on Basket Button");

		// Remove the Existing Products in the Basket
		//basketPage.removeExistingProducts();
		//test.info("User Removes existing produtcs from the Basket if exists");

		// Click on search box and Search the Product
    objLoveActivity.clicksearchbar();

    objLoveActivity.searchproduct(i);
    test.info("product name", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "unlove")).build());

    objLoveActivity.ClickonProductName();
    test.info("product name will visible click on it", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "unlove")).build());
		// Verifies the Selected Product in AddToBasket Page
    objLoveActivity.clickonproduct();
    test.info("product name will visible click on it", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "WishList")).build());

    // Click on AddToBasket Button
		addToBasket.clickOnAddToBasketButton();
    test.info("User Click on AddToBasket Button", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AddressSuggsion")).build());

		// Click on Basket Button
		homeActivity.clickOnBasketButton();
    test.info("User Click on Basket Button", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AddressSuggsion")).build());

		// Click on Checkout button
		checkoutPage.clickOnCheckoutButton();

    test.info("User Click on the Checkout button", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AddressSuggsion")).build());

		basketPage.ShiptToAdd();
    test.info("Shipt To Add", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AddressSuggsion")).build());

    basketPage.Addedit();
    test.info("User Enter Address", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AddressSuggsion")).build());

    basketPage.Typeaddress(i);
    test.info("User Enter Username Address", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AddressSuggsion")).build());


  }

}
