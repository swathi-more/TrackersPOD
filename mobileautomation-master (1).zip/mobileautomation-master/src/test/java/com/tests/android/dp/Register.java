package com.tests.android.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.android.AppSettingsActivity;
import com.automate.pages.android.BottomMenu;
import com.automate.pages.android.CreateAccount;
import com.automate.pages.android.HomeActivity;
import com.automate.pages.android.OnBoardingActivity;
import com.automate.pages.android.ProfileActivity;
import com.automate.pages.android.SignUp;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.TextFileWriter;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import com.tests.android.store.StoreTest;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.geolocation.AndroidGeoLocation;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class Register  extends BaseTest {


  private static final Logger logger = LogManager.getLogger(StoreTest.class);
  private ExtentReportLogger extentLogger= new ExtentReportLogger();
  private BrowserMobProxyServer proxy;

  private OnBoardingActivity onBoardingActivity;
  private BottomMenu bottomMenu;
  private ProfileActivity profileActivity;
  private AppSettingsActivity appSettingsActivity;
  private HomeActivity homeActivity;
  private SignUp signUp;
  private CreateAccount createAccount;

  private AndroidDriver androidDriver;

  private ExtentTest test;
  TextFileWriter textFileWriter = new TextFileWriter();

  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {

    Har har =  proxy.getHar();

    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();
    textFileWriter.writeEventsToFile(eventList);
    while (itr.hasNext())
    {
      Event obj = (Event) itr.next();
      test.info("Event  : "+obj.getSotVars().toString());
      System.out.println( "Event SOTV01 : "+obj.getSotVars().getSotV01());
      System.out.println( "Event SOTV88 : "+obj.getSotVars().getSotV88());

    }
    File harFile = new File("event.har");
    har.writeTo(harFile);
  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void registerFlowNonBI() throws IOException, CsvException, InterruptedException {

    test = extentLogger.startTest("registerFlowNonBI");
    proxy = getBMPObj();

    androidDriver = (AndroidDriver) getDriver();
    androidDriver.setLocation(new AndroidGeoLocation(40.72410526596255, -73.9983931887117));

    proxy.newHar("registerFlowNonBI");

    Thread.sleep(5000);

    onBoardingActivity = new OnBoardingActivity(getDriver());
    bottomMenu = new BottomMenu(getDriver());
    profileActivity = new ProfileActivity(getDriver());
    appSettingsActivity = new AppSettingsActivity(getDriver());
    homeActivity = new HomeActivity(getDriver());
    signUp = new SignUp(getDriver());
    createAccount = new CreateAccount(getDriver());

    //click on skip non button
    onBoardingActivity.clickOnSkipNowButton();
    test.info("click on skip non button", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "registerFlowNonBI")).build());

    //click on me tab
    bottomMenu.clickOnMeIcon();
    test.info("click on me tab", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "registerFlowNonBI")).build());

    // scroll to App settings
    profileActivity.scrollToAppSettings();
    test.info("click on me tab", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "registerFlowNonBI")).build());

    // click on App Settings
    profileActivity.clickOnAppSettingsLink();
    test.info("click on App Settings", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "registerFlowNonBI")).build());

    // click on canada english
    appSettingsActivity.clickOnCountryAndLanguageCanada_En();
    test.info("click on canada english", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "registerFlowNonBI")).build());

    // click on continue button
    appSettingsActivity.clickOnPopUpContinue();
    test.info("click on continue button", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "registerFlowNonBI")).build());

    // wait for home page to load
    bottomMenu.clickOnHomeMenuIcon();
    test.info("click on Home Menu", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "registerFlowNonBI")).build());

    //click on sign In
    homeActivity.clickOnSigInButton();
    test.info("click Sign In Button", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "registerFlowNonBI")).build());

    // click on create new account
    signUp.clickOnCreateNewAccountLink();
    test.info("click on create new account", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "registerFlowNonBI")).build());

    // register user
    createAccount.registerUserWithDefaultValues();
    test.info("register user", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "registerFlowNonBI")).build());

    Thread.sleep(3000);

  }

}
