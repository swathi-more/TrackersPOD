package com.tests.android.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.android.SignUp;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.geolocation.AndroidGeoLocation;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class LoginError extends BaseTest {

  // mandatory objects for TC
  private static final Logger logger = LogManager.getLogger(LoginError.class);
  private ExtentReportLogger extentLogger= new ExtentReportLogger();
  private BrowserMobProxyServer proxy;
  private AndroidDriver androidDriver;
  private ExtentTest test;

  private SignUp objSignUp;
  private int i;


  // page objects


  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {

    Har har =  proxy.getHar();
    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();

    boolean testCasesStatus=false;

    // iterating over Events captured
    while (itr.hasNext())
    {
      Event obj = (Event) itr.next();
      if(obj.getSotVars().getSotType().equals("login error")) {
        if (!obj.getSotVars().getSotV47().equals("null")) {
          testCasesStatus = true;
        }
        test.info("Event : " + obj.getSotVars().toString());
        logger.info(obj.getSotVars().toString());
      }
      if(!testCasesStatus) {
        test.fail("Event not found");
      }
    }


    // write all backend data
    File harFile = new File("events/bottomMenuEvents.har");
    har.writeTo(harFile);
  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void verifytheStaysignin() throws InterruptedException, IOException, CsvException {

    // creating test case for report logging
    test = extentLogger.startTest("StaySignein");

    // getting proxy object
    proxy = getBMPObj();

    // assigning CA as default location to device
    androidDriver = (AndroidDriver) getDriver();
    androidDriver.setLocation(new AndroidGeoLocation(40.72410526596255, -73.9983931887117));

    // creating har file for end result
    proxy.newHar("test01");
    objSignUp = new SignUp(getDriver());
    i=0;
    objSignUp.clickOnSignInButton();
    test.info("click on signin", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Error")).build());
    objSignUp.enterInvalidEmail(i);
    test.info("type Invalidemail", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Error")).build());
    objSignUp.enterInvalidPassword(i);
    test.info("type the InvalidPassword", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Error")).build());
    objSignUp.clickOnSignInButton();
    test.info("User Verifies the  login error", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Error")).build());

  }

}
