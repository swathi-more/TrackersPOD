package com.tests.android.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.android.BottomMenu;
import com.automate.pages.android.HomeActivity;
import com.automate.pages.android.ProfilePage;
import com.automate.pages.android.SignUp;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.geolocation.AndroidGeoLocation;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class  AppSignout extends BaseTest {

  // mandatory objects for TC
  private static final Logger logger = LogManager.getLogger(LinkPageTracking.class);
  private ExtentReportLogger extentLogger= new ExtentReportLogger();
  private BrowserMobProxyServer proxy;
  private AndroidDriver androidDriver;
  private ExtentTest test;


  private SignUp signUp;
  private HomeActivity homeActivity;

  private BottomMenu bottomMenu;

  private ProfilePage profilePage;

  private int i;


  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {

    Har har =  proxy.getHar();
    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();
    boolean testCaseStatus =false;
    // iterating over Events captured
    while (itr.hasNext())
    {
      Event obj = (Event) itr.next();
      if(obj.getSotVars().getSotType().equals("logout")){
          testCaseStatus = true;
      }
      if(obj.getSotVars().getSotType().equals("logout")){
          testCaseStatus = true;
        }
      test.info("Event : "+obj.getSotVars().toString());
      logger.info(obj.getSotVars().toString());

    }
    if(!testCaseStatus){
      test.fail("Event Not Found");
    }
    // write all backend data
    File harFile = new File("events/bottomMenuEvents.har");
    har.writeTo(harFile);

  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void AppSignout() throws InterruptedException, IOException, CsvException {

    // creating test case for report logging
    test = extentLogger.startTest("Verify that user is able to sign out from the application and required events are trigged");

    // getting proxy object
    proxy = getBMPObj();

    // assigning CA as default location to device
    androidDriver = (AndroidDriver) getDriver();
    androidDriver.setLocation(new AndroidGeoLocation(40.72410526596255, -73.9983931887117));

    // creating har file for end result
    proxy.newHar("test01");

    signUp = new SignUp(getDriver());
    homeActivity = new HomeActivity(getDriver());
    bottomMenu =  new BottomMenu(getDriver());
    profilePage = new ProfilePage(getDriver());

    //click on SignIn Link
    i = 0;
    //click on SignIn Link
    signUp.clickOnSignInLink();

    //Enter Username and Password and click on Sign in Link
    signUp.login(i);
    test.info("User Enter Username and Password Then click on Sign in Link", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test01")).build());
    logger.info("User Enter Username and Password Then click on Sign in Link");

    test.info("User clicks on Me tab",MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test01")).build());
    //Click on Me tab
    bottomMenu.clickOnMeIcon();
    logger.info("Verify whether the Profile page opened");

    test.info("User click on Sign out",MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test01")).build());
    //Click on Sign out button in profile page
    profilePage.clickSignoutButton();
    logger.info("Verify whether the user is Logged out");
  }

}
