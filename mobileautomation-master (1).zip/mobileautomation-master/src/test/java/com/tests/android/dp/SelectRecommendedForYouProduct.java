package com.tests.android.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.android.*;
import com.automate.pages.android.HomeActivity;
import com.automate.pages.android.OnBoardingActivity;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.geolocation.AndroidGeoLocation;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class SelectRecommendedForYouProduct extends BaseTest {

  private static final Logger logger = LogManager.getLogger(AddProductToCart.class);
  private ExtentReportLogger extentLogger = new ExtentReportLogger();
  private BrowserMobProxyServer proxy;


  private HomeActivity homeActivity;
  private AndroidDriver androidDriver;
  private ExtentTest test;

  private SignUp signUp;
  private OnBoardingActivity onBoardingActivity;
  private int i;


  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {

    Har har = proxy.getHar();

    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();

    while (itr.hasNext()) {
      Event obj = (Event) itr.next();
      test.info("Event : " + obj.getSotVars().toString());
      System.out.println("Event SOTV01 : " + obj.getSotVars().getSotV01());
      System.out.println("Event SOTV88 : " + obj.getSotVars().getSotV88());
    }

    File harFile = new File("events/SelectRecommendedForYouProduct.har");
    har.writeTo(harFile);
  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void SubmitAnswerForProductQuestion() throws IOException, CsvException, InterruptedException {

    test = extentLogger.startTest("SelectRecommendedForYouProduct");
    proxy = getBMPObj();

    androidDriver = (AndroidDriver) getDriver();
    androidDriver.setLocation(new AndroidGeoLocation(40.72410526596255, -73.9983931887117));

    proxy.newHar("test");

    Thread.sleep(5000);

    homeActivity = new HomeActivity(getDriver());
    signUp = new SignUp(getDriver());
    //click on SignIn Link
    i = 0;
//    //click on SignIn Link
    signUp.clickOnSignInLink();

//    //Enter Username and Password and click on Sign in Link
    signUp.login(i);
    test.info("User Enter Username and Password Then click on Sign in Link", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SelectRecommendedForYouProduct")).build());
    logger.info("User Enter Username and Password Then click on Sign in Link");

    //Select Recommended For You Product
    homeActivity.selectRecommendedForYouProduct();
    test.info("User Select Recommended For You Product", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SelectRecommendedForYouProduct")).build());
    logger.info("User Select Recommended For You Product");

  }
}
