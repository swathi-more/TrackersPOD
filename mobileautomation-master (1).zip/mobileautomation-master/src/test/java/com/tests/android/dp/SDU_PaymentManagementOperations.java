package com.tests.android.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.android.AddToBasket;
import com.automate.pages.android.BasketPage;
import com.automate.pages.android.BottomMenu;
import com.automate.pages.android.CheckoutPage;
import com.automate.pages.android.HomeActivity;
import com.automate.pages.android.ProductsPage;
import com.automate.pages.android.ProfileActivity;
import com.automate.pages.android.SignUp;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.geolocation.AndroidGeoLocation;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class SDU_PaymentManagementOperations extends BaseTest {

	private static final Logger logger = LogManager.getLogger(SDU_PaymentManagementOperations.class);
	private ExtentReportLogger extentLogger = new ExtentReportLogger();
	private BrowserMobProxyServer proxy;

	private SignUp signUp;
	private HomeActivity homeActivity;
	private ProductsPage productsPage;
	private AddToBasket addToBasket;
	private BasketPage basketPage;
	private CheckoutPage checkoutPage;
	private BottomMenu bottomMenu;
	private ProfileActivity meActivity;
	private AndroidDriver androidDriver;

	private ExtentTest test;

	private int i;

	@AfterMethod
	public void tearDown() throws IOException, InterruptedException {

		Har har = proxy.getHar();

		HarAnalyzer harAnalyzer = new HarAnalyzer();
		List<Event> eventList = harAnalyzer.getRequestFromHar(har);

		Iterator itr = eventList.iterator();

		while (itr.hasNext()) {
			Event obj = (Event) itr.next();
			test.info("Event : " + obj.getSotVars().toString());
			System.out.println("Event SOTV01 : " + obj.getSotVars().getSotV01());
			System.out.println("Event SOTV88 : " + obj.getSotVars().getSotV88());
		}

		File harFile = new File("events/SDU_PaymentManagementOperations.har");
		har.writeTo(harFile);
	}

	@FrameworkAnnotation(author = "User-1", category = { CategoryType.REGRESSION })
	@Test
	public void SDU_PaymentManagementOperations() throws IOException, CsvException, InterruptedException {

		test = extentLogger.startTest("SDU_PaymentManagementOperations");
		proxy = getBMPObj();

		androidDriver = (AndroidDriver) getDriver();
		androidDriver.setLocation(new AndroidGeoLocation(40.72410526596255, -73.9983931887117));

		proxy.newHar("AddToCart");

		Thread.sleep(5000);

		signUp = new SignUp(getDriver());
		homeActivity = new HomeActivity(getDriver());
		productsPage = new ProductsPage(getDriver());
		addToBasket = new AddToBasket(getDriver());
		basketPage = new BasketPage(getDriver());
    bottomMenu = new BottomMenu(getDriver());
    checkoutPage = new CheckoutPage(getDriver());
    meActivity = new  ProfileActivity(getDriver());

		i = 0;
		// click on SignIn Link
		signUp.clickOnSignInLink();

		// Enter Username and Password and click on Signin Link
		signUp.login(2);
		test.info("User Enter Username and Password Then click on Sign in Link",
				MediaEntityBuilder.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AddToCart")).build());
		logger.info("User Enter Username and Password Then click on Sign in Link");

    // Click on Basket Button
		homeActivity.clickOnBasketButton();
		test.info("User Click on Basket Button");

		// Remove the Existing Products in the Basket
		basketPage.removeExistingProducts();
		test.info("User Removes existing products from the Basket if exists");
		basketPage.navigateBack();

    //Click on Me Button
    bottomMenu.clickOnMeIcon();
    test.info("User Click on Me Button",
              MediaEntityBuilder.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "")).build());
    logger.info("User Click on Me Button");

    //Click on Same Day Unlimited Link
    meActivity.clickOnSameDayUnlimitedLink();
    test.info("User Click on Same Day Unlimited Link",
              MediaEntityBuilder.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "")).build());
    logger.info("User Click on Same Day Unlimited Link");

    //Click on Add Free Trial to Basket Button
    checkoutPage.clickOnFreeTrialToBasketButton();
    test.info("User Click on Add Free Trial to Basket Button",
              MediaEntityBuilder.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "")).build());
    logger.info("User Click on Add Free Trial to Basket Button");

    // Click on Basket Button
    homeActivity.clickOnBasketButton();
    test.info("User Click on Basket Button",
              MediaEntityBuilder.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "")).build());
    logger.info("User Click on Basket Button");

    // Click on Checkout Button
		basketPage.clickOnCheckoutButton();
		test.info("User Click on Checkout Button",
				MediaEntityBuilder
						.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AddToCart"))
						.build());
		logger.info("User Click on Checkout Button");

    // Click on Add Payment Or Gift Card button
    checkoutPage.clickOnAddPaymentOrGiftCard();
    test.info("User Click on Add Payment Or Gift Card button",
              MediaEntityBuilder.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "")).build());
    logger.info("User Click on Add Payment Or Gift Card button");

    checkoutPage.addPaymentOKPopup();

    // Click on Add New Credit or Debit card button
    checkoutPage.clickOnAddNewCreditOrDebitCard();
    test.info("User Click on Add New Credit or Debit card button",
              MediaEntityBuilder.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "")).build());
    logger.info("User Click on Add New Credit or Debit card button");

    // Enter Credit card info and click DONE button
    checkoutPage.enterCreditOrDebitCardInfo(1);
    test.info("User Enter Credit card info and click DONE button",
              MediaEntityBuilder.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "")).build());
    logger.info("User Enter Credit card info and click DONE button");

    checkoutPage.enterBillingAddress(i);
  }

}
