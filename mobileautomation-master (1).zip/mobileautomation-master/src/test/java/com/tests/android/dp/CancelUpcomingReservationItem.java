package com.tests.android.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.android.BottomMenu;
import com.automate.pages.android.EventDetailsPage;
import com.automate.pages.android.HomeActivity;
import com.automate.pages.android.ProfilePage;
import com.automate.pages.android.SignUp;
import com.automate.pages.android.StoresActivity;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.automate.utils.TextFileWriter;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import com.tests.android.store.StoreSetup;
import com.tests.android.store.StoreTest;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.geolocation.AndroidGeoLocation;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class CancelUpcomingReservationItem extends BaseTest {

  private static final Logger logger = LogManager.getLogger(StoreTest.class);
  private ExtentReportLogger extentLogger = new ExtentReportLogger();
  private BrowserMobProxyServer proxy;
  private HomeActivity homeActivity;
  private BottomMenu bottomMenu;
  private SignUp signUp;
  private StoresActivity storesActivity;
  private EventDetailsPage eventDetailsPage;
  private ProfilePage profilePage;
  private AndroidDriver androidDriver;
  private ExtentTest test;
  private int i;
  TextFileWriter textFileWriter = new TextFileWriter();

  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {

    Har har = proxy.getHar();

    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();
    // iterating over Events captured
    boolean testCaseStatus = false;
    // iterating over Events captured
    while (itr.hasNext()) {
      Event obj = (Event) itr.next();
      test.info("Event : " + obj.getSotVars().toString());
      logger.info(obj.getSotVars().toString());
      String a = obj.getSotVars().getSotType();
      if (obj.getSotVars().getSotType().equals("happening cancel booking")) {
        if (!obj.getSotVars().getSotV169().equals("null") && !obj.getSotVars().getSotV98().equals("null")
          && !obj.getSotVars().getSotV171().equals("null")
          && !obj.getSotVars().getSotV172().equals("null")) {
          testCaseStatus = true;
        }
      }

    }
    if(!testCaseStatus){
      test.fail("Event Not Found");
    }
    File harFile = new File("event.har");
    har.writeTo(harFile);

  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void CancelUpcomingReservationItem() throws IOException, CsvException, InterruptedException {

    test = extentLogger.startTest(
      "Verify that user is able to cancel reservation store and required events are triggered for the same");
    proxy = getBMPObj();
    androidDriver = (AndroidDriver) getDriver();
    androidDriver.setLocation(new AndroidGeoLocation(40.72410526596255, -73.9983931887117));

    proxy.newHar("test01");

    Thread.sleep(5000);

    signUp = new SignUp(getDriver());
    homeActivity = new HomeActivity(getDriver());
    eventDetailsPage = new EventDetailsPage(getDriver());
    bottomMenu = new BottomMenu(getDriver());
    storesActivity = new StoresActivity(getDriver());
    profilePage = new ProfilePage(getDriver());
    StoreSetup storeSetup = new StoreSetup(getDriver());

    i = 0;
    //click on SignIn Link
    signUp.clickOnSignInLink();

    // Enter Username and Password and click on Signin Link
    signUp.login(i);
    test.info("User Enter Username and Password Then click on Sign in Link", MediaEntityBuilder
      .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test01")).build());
    logger.info("User Enter Username and Password Then click on Sign in Link");

    test.info("User Enter Username and Password Then click on Signin Link", MediaEntityBuilder
      .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test01")).build());

    // click on me icon in bottom navigation
    bottomMenu.clickOnStoresNavIcon();
    test.info("User Clicks on Stores Navigation", MediaEntityBuilder
      .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test01")).build());
    logger.info("User Clicks on Stores Navigation");

    storesActivity.clickOnFirstEvent();
    test.info("User Clicks on Event", MediaEntityBuilder
      .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test01")).build());
    logger.info("User Clicks on Event ");

    // Click on RSVP in Event details page
    eventDetailsPage.clickOnRSVPButton();
    test.info("User Clicks on RSVP button in Event details page", MediaEntityBuilder
      .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test01")).build());
    logger.info("User Clicks on RSVP button in Event details page");

    // Click on Complete RSVP button
    eventDetailsPage.clickOnCompletedRSVPButton();
    test.info("User Clicks on Complete RSVP button in Event details page", MediaEntityBuilder
      .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test01")).build());
    logger.info("User Clicks on Complete RSVP button in Event details page");

    bottomMenu.clickOnMeIcon();
    test.info("User clicks on Me tab", MediaEntityBuilder
      .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test01")).build());
    // Click on Me tab
    logger.info("Verify whether the Profile page opened");

    profilePage.clickReservationLink();
    test.info("User clicks on Reservation Link", MediaEntityBuilder
      .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test01")).build());
    logger.info("Verify whether the My Reservations page opened");

    profilePage.clickOnFirstReservation();
    test.info("User clicks on the reservation", MediaEntityBuilder
      .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test01")).build());
    logger.info("Verify whether the Event details page opened");


    eventDetailsPage.clickOnCancelButton();
    test.info("User clicks on the reservation cancel button",MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test01")).build());
    logger.info("User clicks on the reservation cancel button");

    eventDetailsPage.clickOnYes();
    test.info("User clicks on the Yes", MediaEntityBuilder
      .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test01")).build());
    logger.info("User clicks on the Yes");

  }

}
