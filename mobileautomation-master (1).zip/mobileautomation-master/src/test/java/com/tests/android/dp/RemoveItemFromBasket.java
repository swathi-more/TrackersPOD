package com.tests.android.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.android.*;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.geolocation.AndroidGeoLocation;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class RemoveItemFromBasket extends BaseTest {

  private static final Logger logger = LogManager.getLogger(RemovePromoCode.class);
  private ExtentReportLogger extentLogger= new ExtentReportLogger();
  private BrowserMobProxyServer proxy;

  private SignUp signUp;
  private HomeActivity homeActivity;
  private ProductsPage productsPage;
  private AddToBasket addToBasket;
  private BasketPage basketPage;
  private AndroidDriver androidDriver;
  private int i;
  private ExtentTest test;


  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {

    Har har =  proxy.getHar();

    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();
    boolean testCaseStatus =false;
    // iterating over Events captured
    while (itr.hasNext())
    {
      Event obj = (Event) itr.next();
      if(obj.getSotVars().getSotType().equals("remove from basket")){
        String a =obj.getSotVars().getSotV04();
        String b =obj.getSotVars().getSotV05();
        String c =obj.getSotVars().getSotV07();
        String d =obj.getSotVars().getSotV15();
        String e =obj.getSotVars().getSotV192();
        String f =obj.getSotVars().getSotV215();
        String g =obj.getSotVars().getSotV217();
        String h =obj.getSotVars().getSotV216();
        String i =obj.getSotVars().getSotV254();

        if(!obj.getSotVars().getSotV04().equals("null")&&!obj.getSotVars().getSotV05().equals("null")&&!obj.getSotVars().getSotV15().equals("null")&&!obj.getSotVars().getSotV192().equals("null")&&!obj.getSotVars().getSotV07().equals("null")&&!obj.getSotVars().getSotV215().equals("null")&&!obj.getSotVars().getSotV216().equals("null")&&!obj.getSotVars().getSotV217().equals("null")&&!obj.getSotVars().getSotV254().equals("null")){
          testCaseStatus = true;
        }
      }
      test.info("Event : "+obj.getSotVars().toString());
      logger.info(obj.getSotVars().toString());
    }
    if(!testCaseStatus){
      test.fail("Event Not Found");
    }
    File harFile = new File("events/RemoveItemFromBasket.har");
    har.writeTo(harFile);
  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void test01() throws IOException, CsvException, InterruptedException {

    test = extentLogger.startTest("Remove an Item from the Basket");
    proxy = getBMPObj();

    androidDriver = (AndroidDriver) getDriver();
    androidDriver.setLocation(new AndroidGeoLocation(40.72410526596255, -73.9983931887117));

    proxy.newHar("test01");

    Thread.sleep(5000);

    signUp = new SignUp(getDriver());
    homeActivity = new HomeActivity(getDriver());
    productsPage = new ProductsPage(getDriver());
    addToBasket  = new AddToBasket(getDriver());
    basketPage = new BasketPage(getDriver());
  i=0;
  //click on SignIn Link
    signUp.clickOnSignInLink();

   //Enter Username and Password and click on Sign in Link
    signUp.login(i);
    test.info("User Enter Username and Password Then click on Sign in Link", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "RemovePromoCode")).build());
    logger.info("User Enter Username and Password Then click on Sign in Link");

    //Click on Basket Button
    homeActivity.clickOnBasketButton();
    test.info("User Click on Basket Button", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "RemovePromoCode")).build());
    logger.info("User Click on Basket Button");

    //Remove the Existing Products in the Basket
    basketPage.removeExistingProducts();
    test.info("User Removes existing products from the Basket if exists", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "RemovePromoCode")).build());
    logger.info("User Removes existing products from the Basket if exists");
    basketPage.navigateBack();

    //Click on search box and Search the Product
    homeActivity.searchProduct(i);
    test.info("User is searching for a product using the search box", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "RemovePromoCode")).build());
    logger.info("User is searching for a product using the search box");

    //Click on the First Product
    productsPage.userSelectTheProduct();
    test.info("User Selects the Product", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "RemovePromoCode")).build());
    logger.info("User Selects the Product");

    //Verifies the Selected Product in AddToBasket Page
    addToBasket.verifySelectedProduct();
    test.info("User Verifies the Selected Product in AddToBasket Page", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "RemovePromoCode")).build());
    logger.info("User Verifies the Selected Product in AddToBasket Page");

    //Click on AddToBasket Button
    addToBasket.clickOnAddToBasketButton();
    test.info("User Click on AddToBasket Button", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "RemovePromoCode")).build());
    logger.info("User Click on AddToBasket Button");

    //Click on Basket Button
    homeActivity.clickOnBasketButton();
    test.info("User Click on Basket Button", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "RemovePromoCode")).build());
    logger.info("User Click on Basket Button");

    //Remove the Product from the Basket
    basketPage.removeExistingProducts();
    test.info("User Remove the Product from the Basket", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "RemovePromoCode")).build());
    logger.info("User Remove the Product from the Basket");
  }

}
