package com.tests.android.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.android.AddToBasket;
import com.automate.pages.android.AskaQuestionPage;
import com.automate.pages.android.BasketPage;
import com.automate.pages.android.FilterAndSortPage;
import com.automate.pages.android.HomeActivity;
import com.automate.pages.android.OnBoardingActivity;
import com.automate.pages.android.ProductsPage;
import com.automate.pages.android.SignUp;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.geolocation.AndroidGeoLocation;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class FilteraddinProductpageRatingReviewsection extends BaseTest {

  private static final Logger logger = LogManager.getLogger(AddProductToCart.class);
  private ExtentReportLogger extentLogger = new ExtentReportLogger();
  private BrowserMobProxyServer proxy;

  private SignUp signUp;
  private HomeActivity homeActivity;
  private ProductsPage productsPage;
  private AddToBasket addToBasket;
  private BasketPage basketPage;
  private AndroidDriver androidDriver;
  private ExtentTest test;
  private AskaQuestionPage askaQuestionPage;
private FilterAndSortPage filterAndSortPage;
  private OnBoardingActivity onBoardingActivity;
  private int i;

  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {

    Har har = proxy.getHar();

    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();
    // iterating over Events captured
    boolean testCaseStatus = false;
    // iterating over Events captured
    while (itr.hasNext()) {
      Event obj = (Event) itr.next();
      test.info("Event : " + obj.getSotVars().toString());
      logger.info(obj.getSotVars().toString());
      String a = obj.getSotVars().getSotType();
      if (obj.getSotVars().getSotType().equals("reviews ratings and reviews filter")) {
        if (!obj.getSotVars().getSotV84().equals("null")) {
          testCaseStatus = true;
        }
      }
    }
    if(!testCaseStatus){
      test.fail("Event Not Found");
    }

    File harFile = new File("events/FilteraddinProductpageRatingReviewsection.har");
    har.writeTo(harFile);
  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void FilteraddinProductpageRatingReviewsection() throws IOException, CsvException, InterruptedException {

    test = extentLogger.startTest("Verify that user is able to add filter in rating and review section and required events are triggered for the same");
    proxy = getBMPObj();

    androidDriver = (AndroidDriver) getDriver();
    androidDriver.setLocation(new AndroidGeoLocation(40.72410526596255, -73.9983931887117));

    proxy.newHar("test");

    Thread.sleep(5000);

    signUp = new SignUp(getDriver());
    homeActivity = new HomeActivity(getDriver());
    productsPage = new ProductsPage(getDriver());
    addToBasket = new AddToBasket(getDriver());
    basketPage = new BasketPage(getDriver());
    askaQuestionPage = new AskaQuestionPage(getDriver());
    onBoardingActivity = new OnBoardingActivity(getDriver());
    filterAndSortPage =  new FilterAndSortPage(getDriver());
    //click on SignIn Link
    i = 0;
//    //click on SignIn Link
//    signUp.clickOnSignInLink();
//
//    //Enter Username and Password and click on Signin Link
//    signUp.login(i);
    onBoardingActivity.clickOnSkipNowButton();
    test.info("User Enter Username and Password Then click on Sign in Link", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test")).build());
    logger.info("User Enter Username and Password Then click on Sign in Link");

//    test.info("User Enter Username and Password Then click on Signin Link");
//    //Verify User logedinto application
//    homeActivity.verifyUserIcon();
//    logger.info("Verify whether the user has logged into the application");

    //Click on search box and Search the Product
    homeActivity.searchProduct(1);
    test.info("User is searching for a product using the search box", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test")).build());
    logger.info("User is searching for a product using the search box");

    //Click on the First Product
    productsPage.userSelectTheProduct();
    test.info("User Selects the Product", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test")).build());
    logger.info("User Selects the Product");

    //Click on the review filter  link on PD Page
    productsPage.clickOnreviewFilterButton();
    test.info("User Clicks on Review filter button", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test")).build());
    logger.info("User Clicks on Review filter button");

    //Click on the Sort DropDwn
    filterAndSortPage.clickOnSortFiler();
    test.info("User Clicks on Sort Filter Drop Down", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test")).build());
    logger.info("User Clicks on Sort Filter Drop Down");

    //Click on the Oldest option radio button
    filterAndSortPage.clickOnOldestOprtion();
    test.info("User Clicks on Oldest option", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test")).build());
    logger.info("User Clicks on Oldest option");

    //Click on the rating drop down
    filterAndSortPage.clickOnRatingDropDown();
    test.info("User Clicks on Rating Drop Down", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test")).build());
    logger.info("User Clicks on Rating Drop Down");

    //Click on the Five start rating
    filterAndSortPage.clickOnFiveStartCheckBox();
    test.info("User Selects Five Start options", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test")).build());
    logger.info("User Selects Five Start options");

    //Click on the Show Results button
    filterAndSortPage.clickOnShowResultsButton();
    test.info("User clicks on Show Results Button", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test")).build());
    logger.info("User clicks on Show Results Button");

  }

}
