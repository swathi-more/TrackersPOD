package com.tests.android.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.android.AddToBasket;
import com.automate.pages.android.BasketPage;
import com.automate.pages.android.CheckoutPage;
import com.automate.pages.android.HomeActivity;
import com.automate.pages.android.ProductsPage;
import com.automate.pages.android.SignUp;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.geolocation.AndroidGeoLocation;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class AfterpayPaymentSelection extends BaseTest {

  private static final Logger logger = LogManager.getLogger(AfterpayPaymentSelection.class);
  private ExtentReportLogger extentLogger = new ExtentReportLogger();
  private BrowserMobProxyServer proxy;

  private SignUp signUp;
  private HomeActivity homeActivity;
  private ProductsPage productsPage;
  private AddToBasket addToBasket;
  private BasketPage basketPage;
  private CheckoutPage checkoutPage;
  private AndroidDriver androidDriver;

  private ExtentTest test;

  private int i;

  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {

    Har har = proxy.getHar();

    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();
    boolean testCaseStatus =false;
    // iterating over Events captured
    while (itr.hasNext())
    {
      Event obj = (Event) itr.next();
      if(obj.getSotVars().getSotType().equals("checkout payment afterpay")){
          testCaseStatus = true;
      }
      test.info("Event : "+obj.getSotVars().toString());
      logger.info(obj.getSotVars().toString());
    }
    if(!testCaseStatus){
      test.fail("Event Not Found");
    }
    File harFile = new File("events/AfterpayPaymentSelection.har");
    har.writeTo(harFile);

  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void AddToCart() throws IOException, CsvException, InterruptedException {

    test = extentLogger.startTest("Add Product To the Cart");
    proxy = getBMPObj();

    androidDriver = (AndroidDriver) getDriver();
    androidDriver.setLocation(new AndroidGeoLocation(40.72410526596255, -73.9983931887117));

    proxy.newHar("AfterpayPaymentSelection");

    Thread.sleep(5000);

    signUp = new SignUp(getDriver());
    homeActivity = new HomeActivity(getDriver());
    productsPage = new ProductsPage(getDriver());
    addToBasket = new AddToBasket(getDriver());
    basketPage = new BasketPage(getDriver());
    checkoutPage = new CheckoutPage(getDriver());

    i = 0;
    // click on SignIn Link
    signUp.clickOnSignInLink();

    // Enter Username and Password and click on Signin Link
    signUp.login(1);
    test.info("User Enter Username and Password Then click on Sign in Link",
              MediaEntityBuilder
                .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AfterpayPaymentSelection"))
                .build());
    logger.info("User Enter Username and Password Then click on Sign in Link");

    test.info("User Enter Username and Password Then click on Signin Link");
    // Verify User logged into application
    homeActivity.verifyUserIcon();
    test.info("Verify whether the user has logged into the application");
    // Click on Basket Button
    homeActivity.clickOnBasketButton();
    test.info("User Click on Basket Button");

    // Remove the Existing Products in the Basket
    basketPage.removeExistingProducts();
    test.info("User Removes existing produtcs from the Basket if exists");
    basketPage.navigateBack();

    // Click on search box and Search the Product
    homeActivity.searchProduct(i);
    test.info("User is searching for a product using the search box",
              MediaEntityBuilder
                .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AfterpayPaymentSelection"))
                .build());
    logger.info("User is searching for a product using the search box");

    // Click on the First Product
    productsPage.userSelectTheProduct();
    test.info("User Selects the Product",
              MediaEntityBuilder
                .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AfterpayPaymentSelection"))
                .build());
    logger.info("User Selects the Product");

    // Verifies the Selected Product in AddToBasket Page
    addToBasket.verifyScrollDropDown();

    // Click on AddToBasket Button
    addToBasket.clickOnAddToBasketButton();
    test.info("User Click on AddToBasket Button",
              MediaEntityBuilder
                .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AfterpayPaymentSelection"))
                .build());
    logger.info("User Click on AddToBasket Button");

    // Click on Basket Button
    homeActivity.clickOnBasketButton();
    test.info("User Click on Basket Button",
              MediaEntityBuilder
                .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AfterpayPaymentSelection"))
                .build());
    logger.info("User Click on Basket Button");

    // Click on Checkout Button
    basketPage.clickOnCheckoutButton();
    test.info("User Click on Checkout Button", MediaEntityBuilder.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AfterpayPaymentSelection")).build());
    logger.info("User Click on Checkout Button");

    //Select the After Pay Option
    checkoutPage.selectAfterPay();
    test.info("User Select the After Pay Option", MediaEntityBuilder.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AfterpayPaymentSelection")).build());
    logger.info("User Select the After Pay Option");
  }
}
