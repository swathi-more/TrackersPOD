package com.tests.android.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.android.*;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.geolocation.AndroidGeoLocation;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class SameDayScheduleADeliveryWindowTimeConfirmation extends BaseTest {

    private static final Logger logger = LogManager.getLogger(SameDayScheduleADeliveryWindowTimeConfirmation.class);
    private ExtentReportLogger extentLogger = new ExtentReportLogger();
    private BrowserMobProxyServer proxy;

    private SignUp signUp;
    private HomeActivity homeActivity;
    private ProductsPage productsPage;
    private AddToBasket addToBasket;
    private BasketPage basketPage;
    private AndroidDriver androidDriver;
    private CheckoutPage checkoutPage;
    private ExtentTest test;

    private int i;

    @AfterMethod
    public void tearDown() throws IOException, InterruptedException {

        Har har = proxy.getHar();

        HarAnalyzer harAnalyzer = new HarAnalyzer();
        List<Event> eventList = harAnalyzer.getRequestFromHar(har);

        Iterator itr = eventList.iterator();

        while (itr.hasNext()) {
            Event obj = (Event) itr.next();
            test.info("Event : " + obj.getSotVars().toString());
            System.out.println("Event SOTV01 : " + obj.getSotVars().getSotV01());
            System.out.println("Event SOTV88 : " + obj.getSotVars().getSotV88());
        }

        File harFile = new File("events/SameDayScheduleADeliveryWindow.har");
        har.writeTo(harFile);
    }

    @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
    @Test
    public void AddToCart() throws IOException, CsvException, InterruptedException {

        test = extentLogger.startTest("Verify that user is able to SameDay Schedule a delivery window and required events are triggered for the same");
        proxy = getBMPObj();

        androidDriver = (AndroidDriver) getDriver();
        androidDriver.setLocation(new AndroidGeoLocation(40.72410526596255, -73.9983931887117));

        proxy.newHar("SameDayScheduleADeliveryWindow");

        Thread.sleep(5000);

        signUp = new SignUp(getDriver());
        homeActivity = new HomeActivity(getDriver());
        productsPage = new ProductsPage(getDriver());
        addToBasket = new AddToBasket(getDriver());
        basketPage = new BasketPage(getDriver());
        checkoutPage = new CheckoutPage(getDriver());

        i = 1;
        // click on SignIn Link
        signUp.clickOnSignInLink();

        // Enter Username and Password and click on Signin Link
        signUp.login(i);
        test.info("User Enter Username and Password Then click on Sign in Link",
                MediaEntityBuilder
                        .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AddToCart"))
                        .build());
        logger.info("User Enter Username and Password Then click on Sign in Link");

        // Click on Basket Button
        homeActivity.clickOnBasketButton();
        test.info("User Click on Basket Button");

        // Remove the Existing Products in the Basket
        basketPage.removeExistingProducts();
        test.info("User Removes existing produtcs from the Basket if exists");
        basketPage.navigateBack();

        // Click on search box and Search the Product
        homeActivity.searchProduct(3);
        test.info("User is searching for a product using the search box",
                MediaEntityBuilder
                        .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AddToCart"))
                        .build());
        logger.info("User is searching for a product using the search box");

        // Click on the First Product
        productsPage.userSelectTheProduct();
        test.info("User Selects the Product",
                MediaEntityBuilder
                        .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AddToCart"))
                        .build());
        logger.info("User Selects the Product");
        //User click And Verify SameDayDelivery
      addToBasket.clickAndVerifySameDayDelivery(i);
      test.info("User click And Verify Same Day Delivery", MediaEntityBuilder.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AddToCart")).build());
      logger.info("User click And Verify Same Day Delivery");
        // Click on AddToBasket Button
        addToBasket.clickOnAddToBasketButton();
        test.info("User Click on AddToBasket Button",
                MediaEntityBuilder
                        .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AddToCart"))
                        .build());
        logger.info("User Click on AddToBasket Button");

        // Click on Basket Button
        homeActivity.clickOnBasketButton();
        test.info("User Click on Basket Button",
                MediaEntityBuilder
                        .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AddToCart"))
                        .build());
        logger.info("User Click on Basket Button");

        // Click on Checkout Button
        basketPage.clickOnCheckoutButton();
        test.info("User Click on Checkout Button", MediaEntityBuilder.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AddToCart")).build());
        logger.info("User Click on Checkout Button");
      //Click On Schedule Deliver Window Button
      checkoutPage.clickOnScheduleDeliverWindowButton();
      test.info("User Click On Schedule Deliver Window Button", MediaEntityBuilder.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AddToCart")).build());
      logger.info("Click On Schedule Deliver Window Button");

      //Select Time Slot Radio Button and Click on Confirm Button
      checkoutPage.selectTimeAndConfirmIt();
      test.info("User Select Time Slot Radio Button and Click on Confirm Button", MediaEntityBuilder.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "AddToCart")).build());
      logger.info("User Select Time Slot Radio Button and Click on Confirm Button");
      
    }
}
