package com.tests.ios.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.ios.AccountDetailsPageIOS;
import com.automate.pages.ios.BottomMenuIOS;
import com.automate.pages.ios.NotificationsSettingsPageIOS;
import com.automate.pages.ios.OnBoardActivityIOS;
import com.automate.pages.ios.AppSettingsPageIOS;
import com.automate.pages.ios.PersonalizeExperienceIOS;
import com.automate.pages.ios.ProfileActivityIOS;
import com.automate.pages.ios.SignInIOS;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import com.tests.android.dp.LinkPageTracking;
import io.appium.java_client.ios.IOSDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.html5.Location;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class ProfileEmailEditIOS extends BaseTest {

  private static final Logger logger = LogManager.getLogger(ProfileEmailEditIOS.class);
  private ExtentReportLogger extentLogger= new ExtentReportLogger();
  private BrowserMobProxyServer proxy;

  private AppSettingsPageIOS appSettingsPageIOS;
  private OnBoardActivityIOS onBoardingActivity;
  private BottomMenuIOS bottomMenu;
  private SignInIOS signInIOS;
private AccountDetailsPageIOS accountDetailsPageIOS;
  private NotificationsSettingsPageIOS notificationsSettingsPageIOS;
  private ProfileActivityIOS profileActivityIOS;
  private PersonalizeExperienceIOS personalizeExperienceIOS;
  private ExtentTest test;
  private IOSDriver iosDriver;
  private int i;
  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {

    Har har =  proxy.getHar();
    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();

    // iterating over Events captured
    boolean testCaseStatus =false;
    // iterating over Events captured
    while (itr.hasNext())
    {
      Event obj = (Event) itr.next();
      if(obj.getSotVars().getSotType().equals("user profile my account email edit")){
        testCaseStatus = true;
      }
      test.info("Event : "+obj.getSotVars().toString());
      logger.info(obj.getSotVars().toString());
      String a = obj.getSotVars().getSotType();
      System.out.println(obj.getSotVars().getSotType());
    }
    if(!testCaseStatus){
      test.fail("Event Not Found");
    }
    // write all backend data
    File harFile = new File("events/ProfileEmailEditIOS.har");
    har.writeTo(harFile);

  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void test01() throws IOException, CsvException, InterruptedException {
    proxy = getBMPObj();

    // assigning CA as default location to device
    iosDriver = (IOSDriver) getDriver();
    Location loc = new Location(40.72410526596255, -73.9983931887117, 1000);  // latitude, longitude, altitude
    iosDriver.setLocation(loc);

    proxy.newHar("test01");
    test = extentLogger.startTest("Verify that user is able to edit email from Me tab and required events are triggered for the same");
    Thread.sleep(5000);

    onBoardingActivity = new OnBoardActivityIOS(getDriver());
    bottomMenu = new BottomMenuIOS(getDriver());
    profileActivityIOS = new ProfileActivityIOS(getDriver());
    notificationsSettingsPageIOS = new NotificationsSettingsPageIOS(getDriver());
    accountDetailsPageIOS = new AccountDetailsPageIOS(getDriver());
    signInIOS = new SignInIOS(getDriver());
    personalizeExperienceIOS = new PersonalizeExperienceIOS(getDriver());
    i =0;
    //Enter Username and Password and click on SignIn Link
    signInIOS.loginIOS(3);
    test.info("User Enter Username and Password Then click on Sign in Link", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "ProfileEmailEditIOS")).build());
    logger.info("User Enter Username and Password Then click on Sign in Link");

    personalizeExperienceIOS.waitForButtonToAppear(70);
    personalizeExperienceIOS.clickOnContinueButton();

    // click on me icon in bottom navigation
    bottomMenu.clickOnMeIcon();
    test.info("User clicks on Me icon", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "ProfileEmailEditIOS")).build());
    logger.info("User clicks on Me icon");

    //Click on Account link in profile page
    profileActivityIOS.clickOnAccountLink();
    test.info("User clicks Account tab",MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "ProfileEmailEditIOS")).build());
    logger.info("Verify whether the Account page opened");

    test.info("User clicks on Email edit button",MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "ProfileEmailEditIOS")).build());
    //Click on Account Tab
    accountDetailsPageIOS.clickOnEmailEditButton();
    logger.info("Verify whether email pop-up is opened");

    test.info("User edits the email address",MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "ProfileEmailEditIOS")).build());
    //Click on Account Tab
    accountDetailsPageIOS.editEmailAddress(1);
    logger.info("Verify whether email is updated");

  }

}
