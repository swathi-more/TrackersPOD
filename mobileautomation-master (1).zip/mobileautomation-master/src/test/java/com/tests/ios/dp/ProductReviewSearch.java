package com.tests.ios.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.ios.*;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import io.appium.java_client.ios.IOSDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.html5.Location;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class ProductReviewSearch extends BaseTest {


  private static final Logger logger = LogManager.getLogger(ProductReviewSearch.class);
  private ExtentReportLogger extentLogger = new ExtentReportLogger();
  private BrowserMobProxyServer proxy;
  private IOSDriver iosDriver;
  private ExtentTest test;



  // POM
  private SignInIOS signInIOS;
  private HomeActivityIOS homeActivityIOS;
  private BottomMenuIOS bottomMenuIOS;
  private PersonalizeExperienceIOS personalizeExperienceIOS;
  private ProductsPageIOS productsPageIOS;
  private AskaQuestionPageIOS askaQuestionPageIOS;

  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {

    Har har =  proxy.getHar();
    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();
    // iterating over Events captured
    boolean testCaseStatus = false;
    // iterating over Events captured
    while (itr.hasNext()) {
      Event obj = (Event) itr.next();
      if (obj.getSotVars().getSotType().equals("review null search")) {
        if (!obj.getSotVars().getSotV42().equals("null")&&!obj.getSotVars().getSotV15().equals("null")) {
          testCaseStatus = true;
        }
      }
      test.info("Event : "+obj.getSotVars().toString());
    }
    if(!testCaseStatus){
      test.fail("Event Not Found");
    }
    File harFile = new File("events/ProductReviewSearch.har");
    har.writeTo(harFile);

  }


  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void productReviewViewAll() throws InterruptedException, IOException, CsvException {

    // creating test case for report logging
    test = extentLogger.startTest("productReview");

    // getting proxy object
    proxy = getBMPObj();

    // assigning CA as default location to device
    iosDriver = (IOSDriver) getDriver();
    Location loc = new Location(40.72410526596255, -73.9983931887117, 1000);  // latitude, longitude, altitude
    iosDriver.setLocation(loc);

    // creating har file for end result
    proxy.newHar("test01");

    signInIOS = new SignInIOS(getDriver());
    homeActivityIOS = new HomeActivityIOS(getDriver());
    personalizeExperienceIOS = new PersonalizeExperienceIOS(getDriver());
    productsPageIOS = new ProductsPageIOS(getDriver());
    askaQuestionPageIOS = new AskaQuestionPageIOS(getDriver());

    //Enter Username and Password and click on Sign in Link
    signInIOS.login(2);
    test.info("User Enter Username and Password Then click on Sign in Link", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "ProductReviewSearch")).build());
    logger.info("User Enter Username and Password Then click on Sign in Link");

    personalizeExperienceIOS.waitForButtonToAppear(100);
    personalizeExperienceIOS.clickOnContinueButton();

    //Click on search box and Search the Product
    homeActivityIOS.searchProduct("Teint Idole Ultra 24H Long Wear Matte Foundation");
    test.info("User is searching for a product using the search box", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "ProductReviewSearch")).build());
    logger.info("User is searching for a product using the search box");

    //click on see all review Link
    productsPageIOS.clickOnSeeAllReview();
    test.info("User click on see all review Link", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "ProductReviewSearch")).build());
    logger.info("User click on see all review Link");

    //Click on Search Icon Review Page
    productsPageIOS.clickOnSearchIconReviewPage();
    test.info("User Click on Search Icon Review Page", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "ProductReviewSearch")).build());
    logger.info("User Click on Search Icon Review Page");

    //Search the Review
    productsPageIOS.searchReview("Good");
    test.info("User Search the Review", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "ProductReviewSearch")).build());
    logger.info("User Search the Review");

    //Asset the Review Found
    productsPageIOS.assetWhenReviewFound();
    test.info("User Asset the Review Found", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "ProductReviewSearch")).build());
    logger.info("User Asset the Review Found");

    productsPageIOS.searchReview("Unknown");

    productsPageIOS.assetWhenReviewNotFound();

  }
}
