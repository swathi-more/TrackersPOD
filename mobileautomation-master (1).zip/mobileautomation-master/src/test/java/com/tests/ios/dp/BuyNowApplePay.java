package com.tests.ios.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.ios.*;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import io.appium.java_client.ios.IOSDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.html5.Location;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class BuyNowApplePay extends BaseTest {

  private static final Logger logger = LogManager.getLogger(BuyNowApplePay.class);
  private ExtentReportLogger extentLogger= new ExtentReportLogger();
  private BrowserMobProxyServer proxy;

  private OnBoardActivityIOS onBoardingActivity;
  private SignInIOS signInIOS;
  private PersonalizeExperienceIOS personalizeExperienceIOS;
  private HomeActivityIOS homeActivityIOS;
  private ProductsPageIOS productsPageIOS;

  private LoveActivity objLoveActivity;

  private ProductActivity objProductActivity;

  private BasketActivity objBasketActivity;

  private ExtentTest test;
  private int i;

  private IOSDriver iosDriver;
  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {


    Har har = proxy.getHar();

    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();
    boolean testCaseStatus =false;
    // iterating over Events captured
    while (itr.hasNext())
    {
      Event obj = (Event) itr.next();
      if(obj.getSotVars().getSotType()!=null && obj.getSotVars().getSotType().equalsIgnoreCase("apple pay checkout")){

      }
      test.info("Event : "+obj.getSotVars().toString());
      logger.info(obj.getSotVars().toString());
    }
    if(!testCaseStatus){
      test.fail("Event Not Found");
    }
    File harFile = new File("events/BuyNowApplePay.har");
    har.writeTo(harFile);

  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void BuyNowApplePay_Event() throws IOException, CsvException, InterruptedException {
    test = extentLogger.startTest("Buy Now Apple Pay");
    proxy = getBMPObj();

    // assigning CA as default location to device
    iosDriver = (IOSDriver) getDriver();
    Location loc = new Location(40.72410526596255, -73.9983931887117, 1000);  // latitude, longitude, altitude
    iosDriver.setLocation(loc);

    proxy.newHar("BuyNowApplePay");

    Thread.sleep(5000);

    i=0;
    signInIOS = new SignInIOS(getDriver());
    personalizeExperienceIOS = new PersonalizeExperienceIOS(getDriver());
    homeActivityIOS = new HomeActivityIOS(getDriver());
    productsPageIOS = new ProductsPageIOS(getDriver());
    onBoardingActivity = new OnBoardActivityIOS(getDriver());
    objLoveActivity=new LoveActivity(getDriver());
    objProductActivity= new ProductActivity(getDriver());
    objBasketActivity= new BasketActivity(getDriver());


    signInIOS.login(2);
    test.info("Login To Application", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BuyNowApplePay")).build());

//    personalizeExperienceIOS.waitForButtonToAppear(90);
//    personalizeExperienceIOS.clickOnContinueButton();

    homeActivityIOS.searchProduct("Eye Liner");
    test.info("Search for product", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BuyNowApplePay")).build());

    productsPageIOS.clickOnFirstProduct();
    test.info("Click on first product", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BuyNowApplePay")).build());

    objBasketActivity.AddtoBasket();
    test.info("Add to Basket", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BuyNowApplePay")).build());
    objBasketActivity.BasketIcon();
    test.info("Basket Icon", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BuyNowApplePay")).build());


    objBasketActivity.clickOnApplePayButton();
    test.info("Check Out", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BuyNowApplePay")).build());

  }

}
