package com.tests.ios.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.ios.BottomMenuIOS;
import com.automate.pages.ios.OnBoardActivityIOS;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.aventstack.extentreports.ExtentTest;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import io.appium.java_client.ios.IOSDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class SampleTest extends BaseTest {
  private ExtentReportLogger extentLogger= new ExtentReportLogger();
  private BrowserMobProxyServer proxy;

  private OnBoardActivityIOS onBoardingActivity;
  private BottomMenuIOS bottomMenu;

  private IOSDriver iosDriver;
  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {
    proxy.stop();
  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void test01() throws IOException, CsvException, InterruptedException {
    proxy = getBMPObj();

    proxy.newHar("test01");
    ExtentTest test = extentLogger.startTest("Add To Cart");
    Thread.sleep(5000);

    onBoardingActivity = new OnBoardActivityIOS(getDriver());
    bottomMenu = new BottomMenuIOS(getDriver());


    // click onn skip link
    onBoardingActivity.clickOnSkipNowButton();

    // click on me icon in bottom navigation
    bottomMenu.clickOnMeIcon();

    Har har =  proxy.getHar();

    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();

    while (itr.hasNext())
    {
      Event obj = (Event) itr.next();
      System.out.println( "Event name : "+obj.getSotVars().toString());

    }

    File harFile = new File("google.har");
    har.writeTo(harFile);


  }

}
