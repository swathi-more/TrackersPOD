package com.tests.ios.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.android.*;
import com.automate.pages.ios.AppSettingsActivityIOS;
import com.automate.pages.ios.BottomMenuIOS;
import com.automate.pages.ios.CreateAccountIOS;
import com.automate.pages.ios.HomeActivityIOS;
import com.automate.pages.ios.OnBoardActivityIOS;
import com.automate.pages.ios.PersonalizeExperienceIOS;
import com.automate.pages.ios.ProfileActivityIOS;
import com.automate.pages.ios.SignInIOS;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.TextFileWriter;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import com.tests.android.store.StoreTest;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.geolocation.AndroidGeoLocation;
import io.appium.java_client.ios.IOSDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.html5.Location;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class RegisterFlowNONBIIOS extends BaseTest {
  private static final Logger logger = LogManager.getLogger(RegisterFlowNONBIIOS.class);
  private ExtentReportLogger extentLogger= new ExtentReportLogger();
  private BrowserMobProxyServer proxy;
  private OnBoardActivityIOS onBoardingActivity;
  private BottomMenuIOS bottomMenu;
  private ProfileActivityIOS profileActivity;
  private AppSettingsActivityIOS appSettingsActivity;
  private HomeActivityIOS homeActivity;
  private SignInIOS signUp;
  private CreateAccountIOS createAccount;
  private PersonalizeExperienceIOS personalizeExperienceIOS;
  private IOSDriver iosDriver;
  private ExtentTest test;
  TextFileWriter textFileWriter = new TextFileWriter();

  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {

    Har har =  proxy.getHar();

    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);
    boolean status=false;
    Iterator itr = eventList.iterator();
    //textFileWriter.writeEventsToFile(eventList);
   try {
     while (itr.hasNext()) {
       Event obj = (Event) itr.next();
       if (obj.getSotVars().getSotType() != null && obj.getSotVars().getSotType().equalsIgnoreCase("bi registration")) {
         if (obj.getSotVars().getSotV09() != null && obj.getSotVars().getSotV09().equalsIgnoreCase("CAD")) {
           if (obj.getSotVars().getSotV119() != null && obj.getSotVars().getSotV119().equalsIgnoreCase("CA")) {
             status = true;
           }
         }
       }
       test.info("Event : " + obj.getSotVars().toString());
     }

     if (!status) {
       test.fail("Event with bi registration not found");
     }

     File harFile = new File("events/RegisterFlowNONBIIOS.har");
     har.writeTo(harFile);
   }
   catch (Exception e){
     e.printStackTrace();
   }
  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void registerFlowNonBI() throws IOException, CsvException, InterruptedException {

    test = extentLogger.startTest("RegisterFlowNONBIIOS");
    proxy = getBMPObj();

    // assigning CA as default location to device
    iosDriver = (IOSDriver) getDriver();
    Location loc = new Location(40.72410526596255, -73.9983931887117, 1000);  // latitude, longitude, altitude
    iosDriver.setLocation(loc);

    proxy.newHar("registerFlowNonBI");

    Thread.sleep(5000);

    onBoardingActivity = new OnBoardActivityIOS(getDriver());
    bottomMenu = new BottomMenuIOS(getDriver());
    profileActivity = new ProfileActivityIOS(getDriver());
    appSettingsActivity = new AppSettingsActivityIOS(getDriver());
    homeActivity = new HomeActivityIOS(getDriver());
    signUp = new SignInIOS(getDriver());
    createAccount = new CreateAccountIOS(getDriver());
    personalizeExperienceIOS = new PersonalizeExperienceIOS(getDriver());

    //click on skip non button
    onBoardingActivity.clickOnSkipNowButton();
    test.info("click on skip non button", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "registerFlowNonBI")).build());

    // click on personalization continue button
    personalizeExperienceIOS.waitForButtonToAppear(80);
    personalizeExperienceIOS.clickOnContinueButton();
    test.info("click on continue button", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "registerFlowNonBI")).build());

    //click on me tab
    bottomMenu.clickOnMeIcon();
    test.info("click on me tab", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "registerFlowNonBI")).build());

    // scroll to App settings
    profileActivity.scrollToAppSettings();
    test.info("click on me tab", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "registerFlowNonBI")).build());

    // click on App Settings
    profileActivity.clickOnAppSettingsLink();
    test.info("click on App Settings", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "registerFlowNonBI")).build());

    // click on canada english
    appSettingsActivity.clickOnCountryAndLanguageCanada_En();
    test.info("click on canada english", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "registerFlowNonBI")).build());

    // wait for home page to load
    bottomMenu.clickOnHomeMenuIcon();
    test.info("click on Home Menu", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "registerFlowNonBI")).build());

    //click on sign In
    homeActivity.clickOnSigInButton();
    test.info("click Sign In Button", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "registerFlowNonBI")).build());

    // click on create new account
    signUp.clickOnCreateNewAccountLink();
    test.info("click on create new account", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "registerFlowNonBI")).build());

    // register user create Account.registerUserWithDefaultValues();
    test.info("register user", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "registerFlowNonBI")).build());

    Thread.sleep(3000);

  }

}
