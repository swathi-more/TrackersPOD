package com.tests.ios.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.ios.BottomMenuIOS;
import com.automate.pages.ios.OnBoardActivityIOS;
import com.automate.pages.ios.PersonalizeExperienceIOS;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import com.tests.android.dp.UnloveaProduct;
import io.appium.java_client.ios.IOSDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class ResetPassword extends BaseTest {

  private static final Logger logger = LogManager.getLogger(ResetPassword.class);
  private ExtentReportLogger extentLogger= new ExtentReportLogger();
  private BrowserMobProxyServer proxy;
  private OnBoardActivityIOS onBoardingActivity;
  private BottomMenuIOS bottomMenu;
  private PersonalizeExperienceIOS personalizeExperienceIOS;
  private int i;

  private ExtentTest test;

  private IOSDriver iosDriver;
  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {
    Har har = proxy.getHar();
    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();
    boolean testCaseStatus =false;
    // iterating over Events captured
    while (itr.hasNext()) {
      Event obj = (Event) itr.next();
      if(obj.getSotVars().getSotType().equals("forgot password email resent")){
        if(!obj.getSotVars().getSotV257().equals("null")){
          testCaseStatus = true;

        }
      }
      test.info("Event : "+obj.getSotVars().toString());
      logger.info(obj.getSotVars().toString());
    }
    if(testCaseStatus)
      test.fail("Event not found");

    // write all backend data
    File harFile = new File("events/ResetPassword.har");
    har.writeTo(harFile);

  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void test01() throws IOException, CsvException, InterruptedException {
    proxy = getBMPObj();

    proxy.newHar("test01");
    test = extentLogger.startTest("ResetEmail");
    Thread.sleep(5000);
    i=0;
    onBoardingActivity = new OnBoardActivityIOS(getDriver());
    personalizeExperienceIOS = new PersonalizeExperienceIOS(getDriver());

    onBoardingActivity.EnterEmailForForgott(i);
    test.info("Click on signIn", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "ResetEmail")).build());

    onBoardingActivity.ClickForgott();
    test.info("type the Click on Forgot", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "ResetEmail")).build());
    onBoardingActivity.ClickSendEmail();
    test.info("Click on sendEmail", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "ResetEmail")).build());

  }

}
