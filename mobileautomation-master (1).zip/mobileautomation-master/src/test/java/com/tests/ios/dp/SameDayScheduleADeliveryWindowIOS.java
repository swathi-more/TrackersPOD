package com.tests.ios.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.ios.*;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.geolocation.AndroidGeoLocation;
import io.appium.java_client.ios.IOSDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class SameDayScheduleADeliveryWindowIOS extends BaseTest {

    private static final Logger logger = LogManager.getLogger(SameDayScheduleADeliveryWindowIOS.class);
    private ExtentReportLogger extentLogger = new ExtentReportLogger();
    private BrowserMobProxyServer proxy;

    private SignUp signUp;
    private HomeActivityIOS homeActivity;
    private ProductsPageIOS productsPage;
    private AddToBasket addToBasket;
    private BasketPage basketPage;
    private IOSDriver iosDriver;
    private CheckoutPage checkoutPage;
    private ExtentTest test;
  private BottomMenuIOS bottomMenuIOS;
  private OnBoardActivityIOS onBoardingActivity;
  private PersonalizeExperienceIOS personalizeExperienceIOS;
    private int i;

    @AfterMethod
    public void tearDown() throws IOException, InterruptedException {

        Har har = proxy.getHar();

        HarAnalyzer harAnalyzer = new HarAnalyzer();
        List<Event> eventList = harAnalyzer.getRequestFromHar(har);

        Iterator itr = eventList.iterator();

      boolean testCasesStatus = false;
      try {
        while (itr.hasNext()) {
          Event obj = (Event) itr.next();
          if(obj.getSotVars().getSotV01().equals("same day-select delivery time")) {
            testCasesStatus = true;

          }
          test.info("Event : " + obj.getSotVars().toString());
          logger.info(obj.getSotVars().toString());
        }

        if(!testCasesStatus) {
          test.fail("Event not found");
        }

        File harFile = new File("events/SameDayScheduleADeliveryWindowIOS.har");
        har.writeTo(harFile);

      } catch (Exception e) {
        // Handle the exception. You can log it or take appropriate actions.
        e.printStackTrace(); // Print the stack trace for debugging purposes

      }
    }

    @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
    @Test
    public void AddToCart() throws IOException, CsvException, InterruptedException {

        test = extentLogger.startTest("Verify that user is able to SameDay Schedule a delivery window and required events are triggered for the same");
        proxy = getBMPObj();

      iosDriver = (IOSDriver) getDriver();
       // androidDriver.setLocation(new AndroidGeoLocation(40.72410526596255, -73.9983931887117));

        proxy.newHar("SameDayScheduleADeliveryWindow");

        Thread.sleep(5000);

        signUp = new SignUp(getDriver());
        homeActivity = new HomeActivityIOS(getDriver());
        productsPage = new ProductsPageIOS(getDriver());
        addToBasket = new AddToBasket(getDriver());
        basketPage = new BasketPage(getDriver());
        checkoutPage = new CheckoutPage(getDriver());
        onBoardingActivity=new OnBoardActivityIOS(getDriver());
      bottomMenuIOS = new BottomMenuIOS(getDriver());
      personalizeExperienceIOS = new PersonalizeExperienceIOS(getDriver());
        i = 0;

        // Enter Username and Password and click on SignIn Link
      onBoardingActivity.SignIn(i);
      test.info("type the EmailPass", MediaEntityBuilder.createScreenCaptureFromPath
        (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SameDayScheduleADeliveryWindowIOS")).build());


      personalizeExperienceIOS.waitForButtonToAppear(70);
      personalizeExperienceIOS.clickOnContinueButton();
      test.info("Accept personalization ",MediaEntityBuilder.createScreenCaptureFromPath(
        ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SameDayScheduleADeliveryWindowIOS")).build());

        // Click on Basket Button
        homeActivity.clickOnBasketButton();
        test.info("User Click on Basket Button");

        // Remove the Existing Products in the Basket
        basketPage.removeExistingProducts();
        test.info("User Removes existing products from the Basket if exists");
      bottomMenuIOS.clickOnHomeMenuIcon();

        // Click on search box and Search the Product
        homeActivity.searchProduct(3);
        test.info("User is searching for a product using the search box",
                MediaEntityBuilder
                        .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SameDayScheduleADeliveryWindowIOS"))
                        .build());
        logger.info("User is searching for a product using the search box");

        // Click on the First Product
        productsPage.userSelectTheProduct();
        test.info("User Selects the Product",
                MediaEntityBuilder
                        .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SameDayScheduleADeliveryWindowIOS"))
                        .build());
        logger.info("User Selects the Product");
        //User click And Verify SameDayDelivery
      addToBasket.clickAndVerifySameDayDelivery(i);
      test.info("User click And Verify Same Day Delivery", MediaEntityBuilder.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SameDayScheduleADeliveryWindowIOS")).build());
      logger.info("User click And Verify Same Day Delivery");
        // Click on AddToBasket Button
        addToBasket.clickOnAddToBasketButton();
        test.info("User Click on AddToBasket Button",
                MediaEntityBuilder
                        .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SameDayScheduleADeliveryWindowIOS"))
                        .build());
        logger.info("User Click on AddToBasket Button");

        // Click on Basket Button
        homeActivity.clickOnBasketButton();
        test.info("User Click on Basket Button",
                MediaEntityBuilder
                        .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SameDayScheduleADeliveryWindowIOS"))
                        .build());
        logger.info("User Click on Basket Button");

        // Click on Checkout Button
        basketPage.clickOnCheckoutButton();
        test.info("User Click on Checkout Button", MediaEntityBuilder.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SameDayScheduleADeliveryWindowIOS")).build());
        logger.info("User Click on Checkout Button");

      //Click On Schedule Deliver Window Button
      checkoutPage.clickOnScheduleDeliverWindowButton();
      test.info("User Click On Schedule Deliver Window Button", MediaEntityBuilder.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SameDayScheduleADeliveryWindowIOS")).build());
      logger.info("Click On Schedule Deliver Window Button");


    }
}
