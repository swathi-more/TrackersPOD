package com.tests.ios.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.ios.HomeActivityIOS;
import com.automate.pages.ios.LoveActivity;
import com.automate.pages.ios.OnBoardActivityIOS;
import com.automate.pages.ios.PersonalizeExperienceIOS;
import com.automate.pages.ios.ProductActivity;
import com.automate.pages.ios.ProductsPageIOS;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import io.appium.java_client.ios.IOSDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class SubscribeOutOfStock extends BaseTest {

  private static final Logger logger = LogManager.getLogger(SubscribeOutOfStock.class);
  private ExtentReportLogger extentLogger= new ExtentReportLogger();
  private BrowserMobProxyServer proxy;
  private HomeActivityIOS homeActivity;
  private ProductsPageIOS productsPage;
  private OnBoardActivityIOS onBoardingActivity;
  private LoveActivity objLoveActivity;
  private ProductActivity objProductActivity;
  private PersonalizeExperienceIOS personalizeExperienceIOS;
  private ExtentTest test;
  private int i;
  private int j;
  private IOSDriver iosDriver;
  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {
    Har har = proxy.getHar();
    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();

    // iterating over Events captured
    boolean testCasesStatus = false;

    // iterating over Events captured
    try {
      while (itr.hasNext()) {
        Event obj = (Event) itr.next();
        if (obj.getSotVars().getSotV106().equals("notify me:email and text notifications:n/a:*")) {
          if (!obj.getSotVars().getSotV01().equals("null") && !obj.getSotVars().getSotV15().equals("null") &&
            !obj.getSotVars().getSotV192().equals("null") && !obj.getSotVars().getSotV05().equals("null") &&
            !obj.getSotVars().getSotV06().equals("null") &&
            !obj.getSotVars().getSotV07().equals("null")) {
            testCasesStatus = true;

          }
        }
        test.info("Event : " + obj.getSotVars().toString());
        logger.info(obj.getSotVars().toString());
      }
      if (testCasesStatus)
        test.fail("Event not found");
      File harFile = new File("events/SubscribeOutOfStock.har");
      har.writeTo(harFile);
    }catch (Exception e) {
      // Handle the exception. You can log it or take appropriate actions.
      e.printStackTrace();
    }}


  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void test01() throws IOException, CsvException, InterruptedException {
    proxy = getBMPObj();

    proxy.newHar("test01");
    test = extentLogger.startTest("SubScribe");
    Thread.sleep(5000);
    i=0;
    j=1;
    onBoardingActivity = new OnBoardActivityIOS(getDriver());
    objLoveActivity=new LoveActivity(getDriver());
    objProductActivity= new ProductActivity(getDriver());
    personalizeExperienceIOS = new PersonalizeExperienceIOS(getDriver());
    homeActivity = new HomeActivityIOS(getDriver());
    productsPage = new ProductsPageIOS(getDriver());


    onBoardingActivity.SignIn(i);
    test.info("type the EmailPass", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SubScribe")).build());

    personalizeExperienceIOS.waitForButtonToAppear(70);
    personalizeExperienceIOS.clickOnContinueButton();
    test.info("Accept personalization ",MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test01")).build());

    objLoveActivity.ProductName(j);
    test.info("Enter Product Name ", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "UnSubScribeProduct")).build());

    objProductActivity.ClickonSuggetionName();

    //Click on the First Product
    productsPage.userSelectTheProduct();
    test.info("User Selects the Product", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SubscribeOutOfStock")).build());
    logger.info("User Selects the Product");

    objProductActivity.ClickOnStockButton();
    test.info("Click On StockButton", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SubScribe")).build());

  }

}
