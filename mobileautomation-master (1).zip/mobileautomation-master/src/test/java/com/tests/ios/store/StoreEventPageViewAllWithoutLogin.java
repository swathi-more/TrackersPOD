package com.tests.ios.store;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.ios.BottomMenuIOS;
import com.automate.pages.ios.LovesActivityIOS;
import com.automate.pages.ios.SignInIOS;
import com.automate.pages.ios.StoresActivityIOS;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.TextFileWriter;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import io.appium.java_client.ios.IOSDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.html5.Location;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class StoreEventPageViewAllWithoutLogin extends BaseTest {


  private static final Logger logger = LogManager.getLogger(StoreEventPageViewAllWithoutLogin.class);
  private ExtentReportLogger extentLogger= new ExtentReportLogger();
  private BrowserMobProxyServer proxy;

  private BottomMenuIOS bottomMenu;

  private StoreSetupIOS storeSetupIOS;

  private StoresActivityIOS storesActivityIOS;
  private LovesActivityIOS lovesActivity;
  private SignInIOS signInIOS;


  private IOSDriver iosDriver;

  private ExtentTest test;
  TextFileWriter textFileWriter = new TextFileWriter();

  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {

    Har har =  proxy.getHar();

    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();
    textFileWriter.writeEventsToFile(eventList);
    while (itr.hasNext())
    {
      Event obj = (Event) itr.next();
      test.info("Event  : "+obj.getSotVars().toString());
      System.out.println( "Event SOTV01 : "+obj.getSotVars().getSotV01());
      System.out.println( "Event SOTV88 : "+obj.getSotVars().getSotV88());

    }
    File harFile = new File("event.har");
    har.writeTo(harFile);

  }
  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void StoreEventPageViewAllWithoutLoginTest() throws IOException, CsvException, InterruptedException {

    test = extentLogger.startTest("Store Test Your Loves List");
    proxy = getBMPObj();

    iosDriver = (IOSDriver) getDriver();
    Location loc = new Location(40.72410526596255, -73.9983931887117, 1000);  // latitude, longitude, altitude
    iosDriver.setLocation(loc);

    proxy.newHar("storeDetails");

    Thread.sleep(5000);
    bottomMenu = new BottomMenuIOS(getDriver());
    StoreSetupIOS storeSetup = new StoreSetupIOS(getDriver());
    storesActivityIOS = new StoresActivityIOS(getDriver());
    lovesActivity = new LovesActivityIOS(getDriver());
    signInIOS = new SignInIOS(getDriver());


    signInIOS.login(2);

    //perform store setup
    storeSetup.createStore();
    test.info("User Perform store setup", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "StoreEventPageViewAllWithoutLoginTest")).build());
    logger.info("User Perform store setup");

    // click on Stores navigation
    bottomMenu.clickOnCommunityNavIcon();
    bottomMenu.clickOnStoresNavIcon();

    // click on Stores navigation
    bottomMenu.clickOnStoresNavIcon();
    test.info("click on Stores navigation", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "StoreEventPageViewAllWithoutLoginTest")).build());
    logger.info("click on Stores navigation");

    // click on store mode
    storesActivityIOS.clickOnStoreModeLink();
    test.info("User click on store mode", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "StoreEventPageViewAllWithoutLoginTest")).build());
    logger.info("User click on store mode");

    // accepting allow notification pop-up
    if(storesActivityIOS.checkAllowNotification())
    {
      storesActivityIOS.clickOnAllowNotifications();
      test.info("Accept Notification", MediaEntityBuilder.createScreenCaptureFromPath(
        ScreenshotUtils.captureScreenshotAsFile(getDriver(), "StoreEventPageViewAllWithoutLoginTest")).build());
      logger.info("User click on store mode");

    }

    storesActivityIOS.clickOnEventsJumpLink();
    test.info("User click on event Jump link", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "StoreEventPageViewAllWithoutLoginTest")).build());
    logger.info("User click on store mode");

    storesActivityIOS.clickOnEventsViewAllLink();
    test.info("User click view All", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "StoreEventPageViewAllWithoutLoginTest")).build());
    logger.info("User click on store mode");

    storesActivityIOS.assertEventHeader();
    Thread.sleep(6000);
  }


}
