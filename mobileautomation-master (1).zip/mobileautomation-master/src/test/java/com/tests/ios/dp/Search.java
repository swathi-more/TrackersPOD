package com.tests.ios.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.ios.BottomMenuIOS;
import com.automate.pages.ios.HomeActivityIOS;
import com.automate.pages.ios.OnBoardActivityIOS;
import com.automate.pages.ios.PersonalizeExperienceIOS;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import io.appium.java_client.ios.IOSDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.html5.Location;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class Search extends BaseTest {


  private static final Logger logger = LogManager.getLogger(VoiceSearchIOS.class);
  private ExtentReportLogger extentLogger = new ExtentReportLogger();
  private BrowserMobProxyServer proxy;
  private IOSDriver iosDriver;
  private ExtentTest test;


  // POM
  private OnBoardActivityIOS onBoardingActivity;
  private HomeActivityIOS homeActivityIOS;
  private BottomMenuIOS bottomMenuIOS;
  private PersonalizeExperienceIOS personalizeExperienceIOS;

  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {

    Har har =  proxy.getHar();
    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();
    boolean testCaseStatus =false;
    // iterating over Events captured
    while (itr.hasNext())
    {
      Event obj = (Event) itr.next();
      String aa = obj.getSotVars().getSotType();
      if(obj.getSotVars().getSotType().equals("search")){
        testCaseStatus = true;
      }
      test.info("Event : "+obj.getSotVars().toString());
      logger.info(obj.getSotVars().toString());
    }
    if(!testCaseStatus){
      test.fail("Event Not Found");
    }
    // write all backend data
    File harFile = new File("events/Search.har");
    har.writeTo(harFile);

  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void searchEvent() throws InterruptedException, IOException, CsvException {

    // creating test case for report logging
    test = extentLogger.startTest("searchEvent");

    // getting proxy object
    proxy = getBMPObj();

    // assigning CA as default location to device
    iosDriver = (IOSDriver) getDriver();
    Location loc = new Location(40.72410526596255, -73.9983931887117, 1000);  // latitude, longitude, altitude
    iosDriver.setLocation(loc);

    // creating har file for end result
    proxy.newHar("test01");

    onBoardingActivity = new OnBoardActivityIOS(getDriver());
    homeActivityIOS = new HomeActivityIOS(getDriver());
    personalizeExperienceIOS = new PersonalizeExperienceIOS(getDriver());


    // click on skip now
    onBoardingActivity.clickOnSkipNowButton();
    test.info("User click on skip now", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Search")).build());
    logger.info("User click on skip now");

    personalizeExperienceIOS.waitForButtonToAppear(100);
    personalizeExperienceIOS.clickOnContinueButton();

    //Click on search box and Search the Product
    homeActivityIOS.searchProduct("Sephora Collection");
    test.info("User is searching for a product using the search box", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Search")).build());
    logger.info("User is searching for a product using the search box");

    //Click on Shop Navigation Button
    bottomMenuIOS.clickOnShopNavIcon();
    test.info("User Click on Shop Navigation Button", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Search")).build());
    logger.info("User Click on Shop Navigation Button");

  }

}
