package com.tests.ios.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.ios.*;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import io.appium.java_client.ios.IOSDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class PDP_StoreSelectorPageStoreSelectedIOS extends BaseTest {
  // mandatory objects for TC
  private static final Logger logger = LogManager.getLogger(PDP_StoreSelectorPageStoreSelectedIOS.class);
  private ExtentReportLogger extentLogger= new ExtentReportLogger();
  private BrowserMobProxyServer proxy;
  private IOSDriver iosDriver;
  private ExtentTest test;
  private int i;

  // page objects
private SignUp signUp;
private HomeActivityIOS homeActivity;
private BottomMenuIOS bottomMenu;
private ShopActivityIOS shopActivity;
private ProductsPageIOS productsPage;
private AddToBasket addToBasket;
private PickupInStorePageIos pickupInStorePage;
  private PersonalizeExperienceIOS personalizeExperienceIOS;

  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {

    Har har =  proxy.getHar();
    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();
    boolean testCaseStatus =false;
    // iterating over Events captured
    while (itr.hasNext())
    {
      Event obj = (Event) itr.next();
      if(obj.getSotVars().getSotType().equals("bopis store selected")){
        if(!obj.getSotVars().getSotV04().equals("null")&&!obj.getSotVars().getSotV193().equals("null")&&!obj.getSotVars().getSotV195().equals("null")&&!obj.getSotVars().getSotV190().equals("null")&&!obj.getSotVars().getSotV196().equals("null")){
          testCaseStatus = true;
        }
      }
      test.info("Event : "+obj.getSotVars().toString());
      logger.info(obj.getSotVars().toString());
    }
    if(!testCaseStatus){
      test.fail("Event Not Found");
    }
    // write all backend data
    File harFile = new File("events/PDP_StoreSelectorPageStoreSelected.har");
    har.writeTo(harFile);
  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void BottomMenuLinksTest() throws InterruptedException, IOException, CsvException {

    // creating test case for report logging
    test = extentLogger.startTest("Verify that user is able to select a store on store selector under BOPIS option and required events are triggered");

    // getting proxy object
    proxy = getBMPObj();

    // assigning CA as default location to device
    iosDriver = (IOSDriver) getDriver();
    //androidDriver.setLocation(new AndroidGeoLocation(40.72410526596255, -73.9983931887117));

    // creating har file for end result
    proxy.newHar("test01");

    signUp = new SignUp(getDriver());
    homeActivity = new HomeActivityIOS(getDriver());
    bottomMenu = new BottomMenuIOS(getDriver());
    shopActivity = new ShopActivityIOS(getDriver());
    productsPage = new ProductsPageIOS(getDriver());
    addToBasket = new AddToBasket(getDriver());
    pickupInStorePage = new PickupInStorePageIos(getDriver());
    personalizeExperienceIOS = new PersonalizeExperienceIOS(getDriver());

    i = 0;
    //click on SignIn Link
    signUp.clickOnSignInLink();

    //Enter Username and Password and click on SignIn Link
    signUp.login(i);
    test.info("User Enter Username and Password Then click on Sign in Link", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "PDP_StoreSelectorPageStoreSelected")).build());
    logger.info("User Enter Username and Password Then click on Sign in Link");

    personalizeExperienceIOS.waitForButtonToAppear(70);
    personalizeExperienceIOS.clickOnContinueButton();

    //Click on Community Shop Navigation Icon
    bottomMenu.clickOnShopNavIcon();
    test.info("User Click on Shop Navigation Icon", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "PDP_StoreSelectorPageStoreSelected")).build());
    logger.info("User Click on Shop Navigation Icon");

    //Click on Browser Tab
    shopActivity.clickOnBrowseTab();
    test.info("User Click on Browser Tab", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "PDP_StoreSelectorPageStoreSelected")).build());
    logger.info("User Click on Browser Tab");

    //Click on Browser New Icon
    shopActivity.clickOnBrowseNewIcon();
    test.info("User Click on Browser New Icon", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "PDP_StoreSelectorPageStoreSelected")).build());
    logger.info("User Click on Browser New Icon");

    //Select the Product
    productsPage.userSelectTheProduct();
    test.info("User Select the Product", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "PDP_StoreSelectorPageStoreSelected")).build());
    logger.info("User Select the Product");

    //Click on Buy Online and Pickup
    addToBasket.clickOnBuyOnlineAndPickupLink();
    test.info("User Click on Buy Online and Pickup", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "PDP_StoreSelectorPageStoreSelected")).build());
    logger.info("User Click on Buy Online and Pickup");

    //Click on Check Other Stores Link
    addToBasket.clickOnCheckOtherStoresLink();
    test.info("User Click on Check Other Stores Link", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "PDP_StoreSelectorPageStoreSelected")).build());
    logger.info("User Click on Check Other Stores Link");

    //Select Another Store from the List
    pickupInStorePage.selectAnotherStoreFromList();
    test.info("User Select Another Store from the List", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "PDP_StoreSelectorPageStoreSelected")).build());
    logger.info("User Select Another Store from the List");

  }

}
