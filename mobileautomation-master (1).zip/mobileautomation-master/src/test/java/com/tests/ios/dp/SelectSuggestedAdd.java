package com.tests.ios.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.ios.BasketActivity;
import com.automate.pages.ios.HomeActivityIOS;
import com.automate.pages.ios.LoveActivity;
import com.automate.pages.ios.OnBoardActivityIOS;
import com.automate.pages.ios.PersonalizeExperienceIOS;
import com.automate.pages.ios.ProductActivity;
import com.automate.pages.ios.ProductsPageIOS;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import io.appium.java_client.ios.IOSDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class  SelectSuggestedAdd extends BaseTest {
  private static final Logger logger = LogManager.getLogger(SelectSuggestedAdd.class);
  private ExtentReportLogger extentLogger= new ExtentReportLogger();
  private BrowserMobProxyServer proxy;
  private PersonalizeExperienceIOS personalizeExperienceIOS;
  private OnBoardActivityIOS onBoardingActivity;
  private LoveActivity objLoveActivity;
  private ProductActivity objProductActivity;
  private BasketActivity objBasketActivity;
  private HomeActivityIOS homeActivity;
  private ProductsPageIOS productsPage;
  private int i;
  private ExtentTest test;
  private IOSDriver iosDriver;
  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {

    Har har = proxy.getHar();

    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();
    boolean testCaseStatus =false;
    // iterating over Events captured
    while (itr.hasNext())
    {
      Event obj = (Event) itr.next();
     if(obj.getSotVars().getSotType().equals("address verification use recommended address drop down")){
        testCaseStatus = true;
      }
      test.info("Event : "+obj.getSotVars().toString());
    }
    if(!testCaseStatus){
      test.fail("Event Not Found add promotion");
    }
    File harFile = new File("events/SelectSuggestedAdd.har");
    har.writeTo(harFile);

  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void test01() throws IOException, CsvException, InterruptedException {
    proxy = getBMPObj();

    proxy.newHar("test01");
    test = extentLogger.startTest("Suggested Address");
    Thread.sleep(5000);
    i=0;
    onBoardingActivity = new OnBoardActivityIOS(getDriver());
    objLoveActivity=new LoveActivity(getDriver());
    objProductActivity= new ProductActivity(getDriver());
    objBasketActivity= new BasketActivity(getDriver());
    personalizeExperienceIOS = new PersonalizeExperienceIOS(getDriver());
    homeActivity = new HomeActivityIOS(getDriver());
    productsPage = new ProductsPageIOS(getDriver());

    onBoardingActivity.SignIn(i);
    test.info("type the EmailPass", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SelectSuggestedAddress")).build());

    personalizeExperienceIOS.waitForButtonToAppear(90);
    personalizeExperienceIOS.clickOnContinueButton();

    //Click on search box and Search the Product
    homeActivity.searchProduct(i);
    test.info("User is searching for a product using the search box", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SelectSuggestedAddress")).build());
    logger.info("User is searching for a product using the search box");

    //Click on the First Product
    productsPage.userSelectTheProduct();
    test.info("User Selects the Product", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SelectSuggestedAddress")).build());
    logger.info("User Selects the Product");

    objBasketActivity.AddtoBasket();
    test.info("Add to Basket", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SelectSuggestedAddress")).build());
    objBasketActivity.BasketIcon();
    test.info("Basket Icon", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SelectSuggestedAddress")).build());
    objBasketActivity.CheckOut();
    test.info("Check Out", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SelectSuggestedAddress")).build());
    objBasketActivity.ClickOnShip();
    test.info("Click On Ship", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SelectSuggestedAddress")).build());
    objBasketActivity.SelectSuggested();
    test.info("Select Suggested", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "SelectSuggestedAddress")).build());

  }

}
