package com.tests.ios.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.ios.AddToBasket;
import com.automate.pages.ios.BasketPage;
import com.automate.pages.ios.BottomMenuIOS;
import com.automate.pages.ios.CheckoutPage;
import com.automate.pages.ios.HomeActivityIOS;
import com.automate.pages.ios.ProductsPageIOS;
import com.automate.pages.ios.ProfileActivityIOS;
import com.automate.pages.ios.SignUp;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.aventstack.extentreports.ExtentTest;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import io.appium.java_client.ios.IOSDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.testng.annotations.Test;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Iterator;
import java.util.List;

public class CancelOrder extends BaseTest {

	private ExtentReportLogger extentLogger = new ExtentReportLogger();
	private BrowserMobProxyServer proxy;

	private SignUp signUp;
	private HomeActivityIOS homeActivity;
	private ProductsPageIOS productsPage;
	private AddToBasket addToBasket;
	private BasketPage basketPage;
	private CheckoutPage checkoutPage;
	private BottomMenuIOS bottomMenu;
	private ProfileActivityIOS meActivity;
	private IOSDriver iosDriver;
	private int i;
	private ExtentTest test;

	@FrameworkAnnotation(author = "User-1", category = { CategoryType.REGRESSION })
	@Test
	public void cancelOrder() throws IOException, CsvException, InterruptedException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {

		test = extentLogger.startTest("Cancel the Order");
		proxy = getBMPObj();

		iosDriver = (IOSDriver) getDriver();

		proxy.newHar("CancelOrder");

		Thread.sleep(5000);

		System.out.println("Hi");
		signUp = new SignUp(getDriver());
		homeActivity = new HomeActivityIOS(getDriver());
		productsPage = new ProductsPageIOS(getDriver());
		addToBasket = new AddToBasket(getDriver());
		basketPage = new BasketPage(getDriver());
		checkoutPage = new CheckoutPage(getDriver());
		bottomMenu = new BottomMenuIOS(getDriver());
		meActivity = new ProfileActivityIOS(getDriver());
		i = 0;
		// click on SignIn Link
		signUp.clickOnSignInLink();

		// Enter Username and Password and click on Sign in Link
		signUp.login(i);
		test.info("User Enter Username and Password Then click on Sign in Link");

		// Click on Basket Button
		homeActivity.clickOnBasketButton();
		test.info("User Click on Basket Button");

		// Remove the Existing Products in the Basket
		basketPage.removeExistingProducts();
		test.info("User Removes existing Products from the Basket if exists");

		// Click on search box and Search the Product
		homeActivity.searchProduct(i);
		test.info("User is searching for a product using the search box");

		// Click on the First Product
		productsPage.userSelectTheProduct();
		test.info("User Selects the Product");

		// Verifies the Selected Product in AddToBasket Page
		addToBasket.verifySelectedProduct();
		test.info("User Verifies the Selected Product in AddToBasket Page");

		// Click on AddToBasket Button
		addToBasket.clickOnAddToBasketButton();
		test.info("User Click on AddToBasket Button");

		// Click on Basket Button
		homeActivity.clickOnBasketButton();
		test.info("User Click on Basket Button");

		// Click on Checkout button
		checkoutPage.clickOnCheckoutButton();
		test.info("User Click on the Checkout button");

		// Click on Add Payment Or Gift Card button
		checkoutPage.clickOnAddPaymentOrGiftCard();
		test.info("User Click on Add Payment Or Gift Card button");

		// Click on Add New Credit or Debit card button
		checkoutPage.clickOnAddNewCreditOrDebitCard();
		test.info("User Click on Add New Credit or Debit card button");

		// Enter Credit card info and click DONE button
		checkoutPage.enterCreditOrDebitCardInfo(i);
		test.info("User enter Credit card info and click DONE button");

		// click Place Order button
		checkoutPage.clickOnPlaceOrderButton();
		test.info("User click Place Order button");

		try {
			// click NO button on Review Sephora Dialog
			checkoutPage.clickNoButtonOnReviewSephora();
			test.info("User click NO button on Review Sephora Dialog");
		} catch (Exception e) {
		}

		// store OrderNumber
		checkoutPage.storeOrderNumber();
		test.info("User store Order Number");

		// click SHOP button
		checkoutPage.clickOnShopButton();
		test.info("User click SHOP button");

		// click Me Icon
		bottomMenu.clickOnMeIcon();
		test.info("User click Me button");

		// click on orders button
		meActivity.clickOnOrders();
		test.info("User click Orders button");

		// click on View Details button
		checkoutPage.clickOnViewDetailsButton(i);
		test.info("User click on View Details button");

		// click on Cancel your order link
		checkoutPage.clickOnCancelOrderLinkAndVerifyHeader();
		test.info("User click on Cancel your order link");

		Har har = proxy.getHar();

		HarAnalyzer harAnalyzer = new HarAnalyzer();
		List<Event> eventList = harAnalyzer.getRequestFromHar(har);

		Iterator<Event> itr = eventList.iterator();
		boolean testCaseStatus = false;
		while (itr.hasNext()) {
			Event obj = (Event) itr.next();
			if (obj.getSotVars().getSotType().equals("cmnty joingroup")) {
				if (!(obj.getSotVars().getSotV04().equals("null") && obj.getSotVars().getSotV05().equals("null")
						&& obj.getSotVars().getSotV06().equals("null") && obj.getSotVars().getSotV188().equals("null")
						&& obj.getSotVars().getSotV189().equals("null") && obj.getSotVars().getSotV15().equals("null")
						&& obj.getSotVars().getSotV187().equals("null") && obj.getSotVars().getSotV193().equals("null")
						&& obj.getSotVars().getSotV192().equals("null") && obj.getSotVars().getSotV07().equals("null")
						&& obj.getSotVars().getSotV199().equals("null") && obj.getSotVars().getSotV63().equals("null")
						&& obj.getSotVars().getSotV215().equals("null") && obj.getSotVars().getSotV216().equals("null")
						&& obj.getSotVars().getSotV217().equals("null")
						&& obj.getSotVars().getSotV236().equals("null"))) {
					testCaseStatus = true;
				}
			}
			test.info("Event : " + obj.getSotVars().toString());
		}
		if (!testCaseStatus) {
			test.fail("Event Not Found");
		}
	}

	@FrameworkAnnotation(author = "User-1", category = { CategoryType.REGRESSION })
	@Test
	public void declineCancelOrder() throws IOException, CsvException, InterruptedException {

		test = extentLogger.startTest("Decline order cancel");
		proxy = getBMPObj();

		iosDriver = (IOSDriver) getDriver();
//		iosDriver.setLocation(new AndroidGeoLocation(40.72410526596255, -73.9983931887117));

		proxy.newHar("test01");

		Thread.sleep(5000);

		signUp = new SignUp(getDriver());
		homeActivity = new HomeActivityIOS(getDriver());
		productsPage = new ProductsPageIOS(getDriver());
		addToBasket = new AddToBasket(getDriver());
		basketPage = new BasketPage(getDriver());
		checkoutPage = new CheckoutPage(getDriver());
		bottomMenu = new BottomMenuIOS(getDriver());
		meActivity = new ProfileActivityIOS(getDriver());
		i = 0;
		// click on SignIn Link
		signUp.clickOnSignInLink();

		// Enter Username and Password and click on Sign in Link
		signUp.login(i);
		test.info("User Enter Username and Password Then click on Sign in Link");

		// Click on Basket Button
		homeActivity.clickOnBasketButton();
		test.info("User Click on Basket Button");

		// Remove the Existing Products in the Basket
		basketPage.removeExistingProducts();
		test.info("User Removes existing products from the Basket if exists");

		// Click on search box and Search the Product
		homeActivity.searchProduct(i);
		test.info("User is searching for a product using the search box");

		// Click on the First Product
		productsPage.userSelectTheProduct();
		test.info("User Selects the Product");

		// Verifies the Selected Product in AddToBasket Page
		addToBasket.verifySelectedProduct();
		test.info("User Verifies the Selected Product in AddToBasket Page");

		// Click on AddToBasket Button
		addToBasket.clickOnAddToBasketButton();
		test.info("User Click on AddToBasket Button");

		// Click on Basket Button
		homeActivity.clickOnBasketButton();
		test.info("User Click on Basket Button");

		// Click on Checkout button
		checkoutPage.clickOnCheckoutButton();
		test.info("User Click on the Checkout button");

		// Click on Add Payment Or Gift Card button
		checkoutPage.clickOnAddPaymentOrGiftCard();
		test.info("User Click on Add Payment Or Gift Card button");

		// Click on Add New Credit or Debit card button
		checkoutPage.clickOnAddNewCreditOrDebitCard();
		test.info("User Click on Add New Credit or Debit card button");

		// Enter Credit card info and click DONE button
		checkoutPage.enterCreditOrDebitCardInfo(i);
		test.info("User enter Credit card info and click DONE button");

		// click Place Order button
		checkoutPage.clickOnPlaceOrderButton();
		test.info("User click Place Order button");

		try {
			// click NO button on Review Sephora Dialog
			checkoutPage.clickNoButtonOnReviewSephora();
			test.info("User click NO button on Review Sephora Dialog");
		} catch (Exception e) {
		}

		// store OrderNumber
		checkoutPage.storeOrderNumber();
		test.info("User store Order Number");

		// click SHOP button
		checkoutPage.clickOnShopButton();
		test.info("User click SHOP button");

		// click Me Icon
		bottomMenu.clickOnMeIcon();
		test.info("User click Me button");

		// click on orders button
		meActivity.clickOnOrders();
		test.info("User click Orders button");

		// click on View Details button
		checkoutPage.clickOnViewDetailsButton(i);
		test.info("User click on View Details button");

		// click on Cancel your order link
		checkoutPage.clickOnCancelOrderLinkAndVerifyHeader();
		test.info("User click on Cancel your order link");

		// click on Back button to decline the Cancel order
		checkoutPage.clickOnBackButtonToDeclineCancelOrder();
		test.info("click on Back button to decline the Cancel order");

		Har har = proxy.getHar();

		HarAnalyzer harAnalyzer = new HarAnalyzer();
		List<Event> eventList = harAnalyzer.getRequestFromHar(har);

		Iterator<Event> itr = eventList.iterator();
		boolean testCaseStatus = false;
		while (itr.hasNext()) {
			Event obj = (Event) itr.next();
			if (obj.getSotVars().getSotType().equals("cmnty joingroup")) {
				if (!obj.getSotVars().getSotV10().equals("null")) {
					testCaseStatus = true;
				}
			}
			test.info("Event : " + obj.getSotVars().toString());
		}
		if (!testCaseStatus) {
			test.fail("Event Not Found");
		}
	}

	@FrameworkAnnotation(author = "User-1", category = { CategoryType.REGRESSION })
	@Test
	public void successfulOrderCancel() throws IOException, CsvException, InterruptedException {

		test = extentLogger.startTest("Successful order cancel");
		proxy = getBMPObj();

		iosDriver = (IOSDriver) getDriver();
//		iosDriver.setLocation(new AndroidGeoLocation(40.72410526596255, -73.9983931887117));

		proxy.newHar("test01");

		Thread.sleep(5000);

		signUp = new SignUp(getDriver());
		homeActivity = new HomeActivityIOS(getDriver());
		productsPage = new ProductsPageIOS(getDriver());
		addToBasket = new AddToBasket(getDriver());
		basketPage = new BasketPage(getDriver());
		checkoutPage = new CheckoutPage(getDriver());
		bottomMenu = new BottomMenuIOS(getDriver());
		meActivity = new ProfileActivityIOS(getDriver());
		i = 0;
		// click on SignIn Link
		signUp.clickOnSignInLink();

		// Enter Username and Password and click on Sign in Link
		signUp.login(i);
		test.info("User Enter Username and Password Then click on Sign in Link");

		// Click on Basket Button
		homeActivity.clickOnBasketButton();
		test.info("User Click on Basket Button");

		// Remove the Existing Products in the Basket
		basketPage.removeExistingProducts();
		test.info("User Removes existing products from the Basket if exists");

		// Click on search box and Search the Product
		homeActivity.searchProduct(i);
		test.info("User is searching for a product using the search box");

		// Click on the First Product
		productsPage.userSelectTheProduct();
		test.info("User Selects the Product");

		// Verifies the Selected Product in AddToBasket Page
		addToBasket.verifySelectedProduct();
		test.info("User Verifies the Selected Product in AddToBasket Page");

		// Click on AddToBasket Button
		addToBasket.clickOnAddToBasketButton();
		test.info("User Click on AddToBasket Button");

		// Click on Basket Button
		homeActivity.clickOnBasketButton();
		test.info("User Click on Basket Button");

		// Click on Checkout button
		checkoutPage.clickOnCheckoutButton();
		test.info("User Click on the Checkout button");

		// Click on Add Payment Or Gift Card button
		checkoutPage.clickOnAddPaymentOrGiftCard();
		test.info("User Click on Add Payment Or Gift Card button");

		// Click on Add New Credit or Debit card button
		checkoutPage.clickOnAddNewCreditOrDebitCard();
		test.info("User Click on Add New Credit or Debit card button");

		// Enter Credit card info and click DONE button
		checkoutPage.enterCreditOrDebitCardInfo(i);
		test.info("User enter Credit card info and click DONE button");

		// click Place Order button
		checkoutPage.clickOnPlaceOrderButton();
		test.info("User click Place Order button");

		try {
			// click NO button on Review Sephora Dialog
			checkoutPage.clickNoButtonOnReviewSephora();
			test.info("User click NO button on Review Sephora Dialog");
		} catch (Exception e) {
		}

		// store OrderNumber
		checkoutPage.storeOrderNumber();
		test.info("User store Order Number");

		// click SHOP button
		checkoutPage.clickOnShopButton();
		test.info("User click SHOP button");

		// click Me Icon
		bottomMenu.clickOnMeIcon();
		test.info("User click Me button");

		// click on orders button
		meActivity.clickOnOrders();
		test.info("User click Orders button");

		// click on View Details button
		checkoutPage.clickOnViewDetailsButton(i);
		test.info("User click on View Details button");

		// click on Cancel your order link
		checkoutPage.clickOnCancelOrderLinkAndVerifyHeader();
		test.info("User click on Cancel your order link");

		// click on Back button to decline the Cancel order
		checkoutPage.clickOnBackButtonToDeclineCancelOrder();
		test.info("click on Back button to decline the Cancel order");

		// click on Cancel your order link
		checkoutPage.clickOnCancelOrderLinkAndVerifyHeader();
		test.info("User click on Cancel your order link");

		// click and select any reason for cancel order
		checkoutPage.clickOnCancelOrderReason();
		test.info("User click and select any reason for cancel order");

		// click SEND button
		checkoutPage.clickOnSendButton();
		test.info("User click and select any reason for cancel order");

		// verify cancel order message
		checkoutPage.verifyCancelOrderMessage(i);
		test.info("User verify cancel order message");

		Har har = proxy.getHar();

		HarAnalyzer harAnalyzer = new HarAnalyzer();
		List<Event> eventList = harAnalyzer.getRequestFromHar(har);

		Iterator<Event> itr = eventList.iterator();
		boolean testCaseStatus = false;
		while (itr.hasNext()) {
			Event obj = (Event) itr.next();
			if (obj.getSotVars().getSotType().equals("cmnty joingroup")) {
				if (!obj.getSotVars().getSotV10().equals("null")) {
					testCaseStatus = true;
				}
			}
			test.info("Event : " + obj.getSotVars().toString());
		}
		if (!testCaseStatus) {
			test.fail("Event Not Found");
		}
	}

	@FrameworkAnnotation(author = "User-1", category = { CategoryType.REGRESSION })
	@Test
	public void sameDayUnlimited() throws IOException, CsvException, InterruptedException {

		test = extentLogger.startTest("Same-day unlimited zip code unavailable");
		proxy = getBMPObj();

		iosDriver = (IOSDriver) getDriver();
//		iosDriver.setLocation(new AndroidGeoLocation(40.72410526596255, -73.9983931887117));

		proxy.newHar("Same-day unlimited");

		Thread.sleep(5000);

		signUp = new SignUp(getDriver());
		homeActivity = new HomeActivityIOS(getDriver());
		productsPage = new ProductsPageIOS(getDriver());
		addToBasket = new AddToBasket(getDriver());
		basketPage = new BasketPage(getDriver());
		checkoutPage = new CheckoutPage(getDriver());
		bottomMenu = new BottomMenuIOS(getDriver());
		meActivity = new ProfileActivityIOS(getDriver());
		i = 0;
		// click on SignIn Link
		signUp.clickOnSignInLink();

		// Enter Username and Password and click on Sign in Link
		signUp.login(i);
		test.info("User Enter Username and Password Then click on Sign in Link");

		// click Me Icon
		bottomMenu.clickOnMeIcon();
		test.info("User click Me button");

		// click on same day unlimited link
		meActivity.clickOnSameDayUnlimitedLink();
		test.info("User click on same day unlimited link");

		meActivity.clickOnYourLocationDropdown();
		test.info("User click on your location dropdown");

		meActivity.enterZipcode(i);
		test.info("User enters zipcode");

		meActivity.clickOnShowResultsButton();
		test.info("User click on Show Results button");

		meActivity.clickOnOKButton();
		test.info("User click on OK button");

		meActivity.verifyTheZipcodeAppliedSuccessfully();
		test.info("User verify the zipcode applied successfully");

		Har har = proxy.getHar();

		HarAnalyzer harAnalyzer = new HarAnalyzer();
		List<Event> eventList = harAnalyzer.getRequestFromHar(har);

		Iterator<Event> itr = eventList.iterator();
		boolean testCaseStatus = false;
		while (itr.hasNext()) {
			Event obj = (Event) itr.next();
			if (obj.getSotVars().getSotType().equals("cmnty joingroup")) {
				if (!obj.getSotVars().getSotV187().equals("null")) {
					testCaseStatus = true;
				}
			}
			test.info("Event : " + obj.getSotVars().toString());
		}
		if (!testCaseStatus) {
			test.fail("Event Not Found");
		}
	}

}
