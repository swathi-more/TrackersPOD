package com.tests.ios.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.ios.*;
import com.automate.pages.ios.OnBoardActivityIOS;
import com.automate.pages.ios.StoreActivity;
import com.automate.pages.ios.StoresActivityIOS;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import com.tests.ios.store.StoreSetupIOS;
import io.appium.java_client.ios.IOSDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.html5.Location;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class BeautyBoardQuiz extends BaseTest {

  // mandatory objects for TC
  private static final Logger logger = LogManager.getLogger(BeautyBoardQuiz.class);
  private ExtentReportLogger extentLogger= new ExtentReportLogger();
  private BrowserMobProxyServer proxy;
  private IOSDriver iosDriver;
  private ExtentTest test;
  private int i;

  // page objects
  private OnBoardActivityIOS onBoardingActivity;
  private SignInIOS signInIOS;
  private BottomMenuIOS objBottomMenu;
  private StoreActivity objStoreActivity;
  private StoresActivityIOS storesActivityIOS;


  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {

    Har har =  proxy.getHar();
    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();
    boolean testCaseStatus =false;
    // iterating over Events captured
    while (itr.hasNext())
    {
      Event obj = (Event) itr.next();
      String aa = obj.getSotVars().getSotType();
      if(obj.getSotVars().getSotType().equals("productfinder")){
        testCaseStatus = true;
      }
      test.info("Event : "+obj.getSotVars().toString());
      logger.info(obj.getSotVars().toString());
    }
    if(!testCaseStatus){
      test.fail("Event Not Found");
    }
    // write all backend data
    File harFile = new File("events/BeautyBoardQuiz.har");
    har.writeTo(harFile);

  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void CommunityGalleryTabClick() throws InterruptedException, IOException, CsvException {

    // creating test case for report logging
    test = extentLogger.startTest("Verify that user is able to Click on BeautyBoard Quiz and required events are triggered");

    // getting proxy object
    proxy = getBMPObj();

    // assigning CA as default location to device

    // assigning CA as default location to device
    iosDriver = (IOSDriver) getDriver();
    Location loc = new Location(40.72410526596255, -73.9983931887117, 1000);  // latitude, longitude, altitude
    iosDriver.setLocation(loc);
    // creating har file for end result

    proxy.newHar("CommunityGalleryTabClick");

    onBoardingActivity = new OnBoardActivityIOS(getDriver());
    objBottomMenu=new BottomMenuIOS(getDriver());
    objStoreActivity=new StoreActivity(getDriver());
    StoreSetupIOS storeSetup = new StoreSetupIOS(getDriver());
    storesActivityIOS = new StoresActivityIOS(getDriver());
    signInIOS = new SignInIOS(getDriver());

    i = 0;

    //Enter Username and Password and click on SignIn Link
    signInIOS.loginIOS(2);
    test.info("User Enter Username and Password Then click on Sign in Link", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "CommunityGalleryTabClick")).build());
    logger.info("User Enter Username and Password Then click on Sign in Link");

    storeSetup.createStore();
    test.info("User Perform store setup", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BeautyBoardQuiz")).build());
    logger.info("User Perform store setup");
    objBottomMenu.clickOnCommunityNavIcon();

    objBottomMenu.clickOnStoresNavIcon();

    storesActivityIOS.clickOnStoreModeLink();
    test.info("User click on store mode", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BeautyBoardQuiz")).build());
    logger.info("User click on store mode");

    // accepting allow notification pop-up
    if(storesActivityIOS.checkAllowNotification())
    {
      storesActivityIOS.clickOnAllowNotifications();

    }
    objStoreActivity.ClickQuizzes();
    test.info("Click Quizzes", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BeautyBoardQuiz")).build());


    objStoreActivity.clickonAll();
    test.info("Click Quizzes", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BeautyBoardQuiz")).build());

    objStoreActivity.ClickonInsideFragrance();
    test.info("Fragrance Quiz", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BeautyBoardQuiz")).build());

    objStoreActivity.GetStartedQuizz();
    test.info("Get Started Quiz", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BeautyBoardQuiz")).build());

    objStoreActivity.ClickonAns();
    test.info("Click on Ans", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BeautyBoardQuiz")).build());

    objStoreActivity.VerifyResult();
    test.info("Verify Result", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BeautyBoardQuiz")).build());

  }

}
