package com.tests.ios.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.ios.BottomMenuIOS;
import com.automate.pages.ios.HomeActivityIOS;
import com.automate.pages.ios.NotificationsSettingsPageIOS;
import com.automate.pages.ios.OnBoardActivityIOS;
import com.automate.pages.ios.AppSettingsPageIOS;
import com.automate.pages.ios.PersonalizeExperienceIOS;
import com.automate.pages.ios.ProductsPageIOS;
import com.automate.pages.ios.ProfileActivityIOS;
import com.automate.pages.ios.SignInIOS;
import com.automate.pages.ios.SignUp;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import com.tests.android.dp.LinkPageTracking;
import io.appium.java_client.ios.IOSDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class CustomSetItemsViewMoreIOS extends BaseTest {

  private static final Logger logger = LogManager.getLogger(LinkPageTracking.class);
  private ExtentReportLogger extentLogger= new ExtentReportLogger();
  private BrowserMobProxyServer proxy;

  private AppSettingsPageIOS appSettingsPageIOS;
  private OnBoardActivityIOS onBoardingActivity;
  private BottomMenuIOS bottomMenu;

  private HomeActivityIOS homeActivityIOS;
  private NotificationsSettingsPageIOS notificationsSettingsPageIOS;
  private ProfileActivityIOS profileActivityIOS;
  private IOSDriver iosDriver;
  private PersonalizeExperienceIOS personalizeExperienceIOS;
  private SignInIOS signInIOS;
  private ProductsPageIOS productsPageIOS;
  private int i;
  private ExtentTest test;
  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {

    Har har = proxy.getHar();

    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();
    // iterating over Events captured
    boolean testCaseStatus = false;
    // iterating over Events captured
    while (itr.hasNext()) {
      Event obj = (Event) itr.next();
      test.info("Event : " + obj.getSotVars().toString());
      logger.info(obj.getSotVars().toString());
      String a = obj.getSotVars().getSotType();
      if (obj.getSotVars().getSotType().equals("custom set items view more")) {
        if (!obj.getSotVars().getSotV15().equals("null")) {
          testCaseStatus = true;
        }
      }

    }
    if(!testCaseStatus){
      test.fail("Event Not Found");
    }

    File harFile = new File("events/CustomSetItemsViewMoreIOS.har");
    har.writeTo(harFile);

  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void test01() throws IOException, CsvException, InterruptedException {
    proxy = getBMPObj();

    proxy.newHar("test01");
    test = extentLogger.startTest("Verify that user is able to view more item in a custom set and required events are triggered for the same");
    Thread.sleep(5000);

    onBoardingActivity = new OnBoardActivityIOS(getDriver());
    bottomMenu = new BottomMenuIOS(getDriver());
    profileActivityIOS = new ProfileActivityIOS(getDriver());
    notificationsSettingsPageIOS = new NotificationsSettingsPageIOS(getDriver());
    homeActivityIOS = new HomeActivityIOS(getDriver());
    signInIOS = new SignInIOS(getDriver());
    personalizeExperienceIOS = new PersonalizeExperienceIOS(getDriver());
    productsPageIOS = new ProductsPageIOS(getDriver());

    i =0;

    //Enter Username and Password and click on Sign in Link
    signInIOS.login(i);
    test.info("User Enter Username and Password Then click on Sign in Link", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "RemovePromoCode")).build());
    logger.info("User Enter Username and Password Then click on Sign in Link");

    personalizeExperienceIOS.waitForButtonToAppear(70);
    personalizeExperienceIOS.clickOnContinueButton();

    //Click on search box and Search the Product
    homeActivityIOS.searchProduct(2);
    test.info("User is searching for a product using the search box", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test")).build());
    logger.info("User is searching for a product using the search box");

    productsPageIOS.userSelectTheProduct();
    test.info("User Selects the Product", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "CustomSetItemsViewMoreIOS")).build());
    logger.info("User ");

    productsPageIOS.clickOnChooseYourItemsButton();
    test.info("User on the Choose your Item button", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "CustomSetItemsViewMoreIOS")).build());
    logger.info("User on the Choose your Item button");

    productsPageIOS.clickOnCollectionsViewMore();
    test.info("User Clicks on the View more", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "CustomSetItemsViewMoreIOS")).build());
    logger.info("User Clicks on the View more");

  }

}
