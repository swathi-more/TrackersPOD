package com.tests.ios.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.ios.AppSettingsActivityIOS;
import com.automate.pages.ios.BottomMenuIOS;
import com.automate.pages.ios.MeActivity;
import com.automate.pages.ios.OnBoardActivityIOS;
import com.automate.pages.ios.PersonalizeExperienceIOS;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import com.tests.android.dp.LinkPageTracking;
import io.appium.java_client.ios.IOSDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class TrackPurchaseHistoryStartShoppingButtonClick extends BaseTest {

  private static final Logger logger = LogManager.getLogger(TrackPurchaseHistoryStartShoppingButtonClick.class);
  private ExtentReportLogger extentLogger= new ExtentReportLogger();
  private BrowserMobProxyServer proxy;

  private OnBoardActivityIOS onBoardingActivity;

  private PersonalizeExperienceIOS personalizeExperienceIOS;

 private BottomMenuIOS objBottomMenu;

 private MeActivity objMeActivity;

 private AppSettingsActivityIOS objAppSettingsActivityIOS;

 private ExtentTest test;

  private int i;

  private IOSDriver iosDriver;
  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {
    Har har =  proxy.getHar();
    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();
    boolean testCasesStatus = false;
try {
  // iterating over Events captured
  while (itr.hasNext()) {
    Event obj = (Event) itr.next();
    if (obj.getSotVars().getSotV01().equals("lists-purchases")) {
      testCasesStatus = true;

    }
    test.info("Event : " + obj.getSotVars().toString());
    logger.info(obj.getSotVars().toString());
  }
  if (!testCasesStatus)
    test.fail("Event not found");

  // write all backend data
  File harFile = new File("events/TrackPurchaseHistory.har");
  har.writeTo(harFile);
}
catch (Exception e) {
  // Handle the exception. You can log it or take appropriate actions.
  e.printStackTrace();

}
  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void test01() throws IOException, CsvException, InterruptedException {
    proxy = getBMPObj();

    proxy.newHar("test01");
    test = extentLogger.startTest("TrackPurchaseHistory");
    Thread.sleep(5000);
    onBoardingActivity = new OnBoardActivityIOS(getDriver());
    objBottomMenu =new BottomMenuIOS(getDriver());
    objMeActivity= new MeActivity(getDriver());
    objAppSettingsActivityIOS= new AppSettingsActivityIOS(getDriver());
    personalizeExperienceIOS = new PersonalizeExperienceIOS(getDriver());

    onBoardingActivity.SignIn(i);
    test.info("type the EmailPass", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "TrackPurchaseHistoryStartShoppingButtonClick")).build());


    personalizeExperienceIOS.waitForButtonToAppear(70);
    personalizeExperienceIOS.clickOnContinueButton();
    test.info("Accept personalization ",MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "TrackPurchaseHistoryStartShoppingButtonClick")).build());

    objBottomMenu.ClickMeIconRajesh();
    test.info("Click Me Icon Rajesh", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "TrackPurchaseHistoryStartShoppingButtonClick")).build());

    objMeActivity.clickOnBuyAgain();
    test.info("click On BuyAgain", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "TrackPurchaseHistoryStartShoppingButtonClick")).build());


    objMeActivity.ClickStartShopping();
    test.info("Click Start Shopping", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "TrackPurchaseHistoryStartShoppingButtonClick")).build());
  }

}
