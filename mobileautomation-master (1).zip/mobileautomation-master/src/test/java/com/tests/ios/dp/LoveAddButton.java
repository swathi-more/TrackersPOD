package com.tests.ios.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.ios.OnBoardActivityIOS;
import com.automate.pages.ios.PersonalizeExperienceIOS;
import com.automate.pages.ios.SignInIOS;
import com.automate.pages.ios.LoveActivity;
import com.automate.pages.ios.OnBoardActivityIOS;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import io.appium.java_client.ios.IOSDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class LoveAddButton extends BaseTest {


  private ExtentReportLogger extentLogger= new ExtentReportLogger();
  private BrowserMobProxyServer proxy;

  private SignInIOS signInIOS;
  private OnBoardActivityIOS onBoardingActivity;
  private LoveActivity objLoveActivity;
  private PersonalizeExperienceIOS personalizeExperienceIOS;

  private ExtentTest test;

  private int i;

  private IOSDriver iosDriver;
  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {
    boolean status = false;
    Har har =  proxy.getHar();
    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();

    while (itr.hasNext())
    {
      Event obj = (Event) itr.next();
      if(obj.getSotVars()!=null && obj.getSotVars().getSotType().equalsIgnoreCase("love list add click"))
      {
        status = true;
      }
      test.info("Event : "+obj.getSotVars().toString());
    }

    if(!status) {
      test.fail("Event : love list add click not found!!"); }

    File harFile = new File("events/LoveAddButton.har");
    har.writeTo(harFile);

  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void LoveAddButton() throws IOException, CsvException, InterruptedException {
    proxy = getBMPObj();

    proxy.newHar("test01");
    test = extentLogger.startTest("LoveAddButton");
    Thread.sleep(5000);
    i=0;
    onBoardingActivity = new OnBoardActivityIOS(getDriver());
    onBoardingActivity = new OnBoardActivityIOS(getDriver());
    objLoveActivity=new LoveActivity(getDriver());
    personalizeExperienceIOS = new PersonalizeExperienceIOS(getDriver());
    signInIOS = new SignInIOS(getDriver());


    signInIOS.login(3);
    test.info("Login to Application", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Add Button")).build());


    personalizeExperienceIOS.waitForButtonToAppear(90);
    personalizeExperienceIOS.clickOnContinueButton();
    test.info("Click continue", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Add Button")).build());

    objLoveActivity.IconLove();
    test.info("Click On Love icon", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Add Button")).build());

    objLoveActivity.removeAll();
    test.info("Click On Remove", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Add Button")).build());

    objLoveActivity.AddButton();
    test.info("Click On AddButton", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Add Button")).build());

    objLoveActivity.clickOnAddLoveSearchButton();
    test.info("Click On search", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Add Button")).build());

      Thread.sleep(10000);

  }

}
