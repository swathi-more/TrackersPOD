package com.tests.ios.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.ios.LoveActivity;
import com.automate.pages.ios.OnBoardActivityIOS;
import com.automate.pages.ios.PersonalizeExperienceIOS;
import com.automate.pages.ios.SignInIOS;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import com.tests.android.dp.LinkPageTracking;
import io.appium.java_client.ios.IOSDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class ManuallySearchTap extends BaseTest {
  private static final Logger logger = LogManager.getLogger(ManuallySearchTap.class);
  private ExtentReportLogger extentLogger= new ExtentReportLogger();
  private BrowserMobProxyServer proxy;
  private OnBoardActivityIOS onBoardingActivity;
  private LoveActivity objLoveActivity;
  private PersonalizeExperienceIOS personalizeExperienceIOS;
  private SignInIOS signInIOS;
  private ExtentTest test;
  private int i;

  private IOSDriver iosDriver;
  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {
    Har har =  proxy.getHar();
    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();
    boolean testCaseStatus =false;
    // iterating over Events captured
    while (itr.hasNext())
    {
      Event obj = (Event) itr.next();
      if(obj.getSotVars().getSotType().equals("love list manual search")){
          testCaseStatus = true;
      }
      test.info("Event : "+obj.getSotVars().toString());
      logger.info(obj.getSotVars().toString());
    }
    if(!testCaseStatus){
      test.fail("Event Not Found");
    }
    // write all backend data
    File harFile = new File("events/ManuallySearchTap.har");
    har.writeTo(harFile);

  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void test01() throws IOException, CsvException, InterruptedException {
    proxy = getBMPObj();

    proxy.newHar("test01");
    test = extentLogger.startTest("Manually Search");
    Thread.sleep(5000);
    i=0;
    onBoardingActivity = new OnBoardActivityIOS(getDriver());
    objLoveActivity=new LoveActivity(getDriver());
    personalizeExperienceIOS = new PersonalizeExperienceIOS(getDriver());
    signInIOS = new SignInIOS(getDriver());

    //Enter Username and Password and click on SignIn Link
    signInIOS.login(i);
    test.info("User Enter Username and Password Then click on Sign in Link", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "GalleryImageClick")).build());
    logger.info("User Enter Username and Password Then click on Sign in Link");

    personalizeExperienceIOS.waitForButtonToAppear(70);
    personalizeExperienceIOS.clickOnContinueButton();
    test.info("Accept personalization ",MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "test01")).build());


    objLoveActivity.IconLove();
    test.info("Click On Love icon", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Manually Search")).build());

    objLoveActivity.removeAll();
    test.info("Click On Remove", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Manually Search")).build());

    objLoveActivity.AddButton();
    test.info("AddButton", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Manually Search")).build());

    objLoveActivity.ManuallySearch();
    test.info("Manually Search", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Manually Search")).build());

  }

}
