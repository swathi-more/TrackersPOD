package com.tests.ios.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.ios.BottomMenuIOS;
import com.automate.pages.ios.NotificationsSettingsPageIOS;
import com.automate.pages.ios.OnBoardActivityIOS;
import com.automate.pages.ios.AppSettingsPageIOS;
import com.automate.pages.ios.PersonalizeExperienceIOS;
import com.automate.pages.ios.ProfileActivityIOS;
import com.automate.pages.ios.SignInIOS;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import com.tests.android.dp.LinkPageTracking;
import io.appium.java_client.ios.IOSDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class ToggleBeautyInsiderUpdatesNotificationIOS extends BaseTest {

  private static final Logger logger = LogManager.getLogger(LinkPageTracking.class);
  private ExtentReportLogger extentLogger= new ExtentReportLogger();
  private BrowserMobProxyServer proxy;
  private AppSettingsPageIOS appSettingsPageIOS;
  private OnBoardActivityIOS onBoardingActivity;
  private BottomMenuIOS bottomMenu;
  private SignInIOS signInIOS;
  private PersonalizeExperienceIOS personalizeExperienceIOS;
  private NotificationsSettingsPageIOS notificationsSettingsPageIOS;
  private ProfileActivityIOS profileActivityIOS;
  private IOSDriver iosDriver;
  private ExtentTest test;
  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {

    Har har =  proxy.getHar();
    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();
    // iterating over Events captured
    boolean testCaseStatus = false;
    // iterating over Events captured
    while (itr.hasNext()) {
      Event obj = (Event) itr.next();
      if (obj.getSotVars().getSotType().equals("toggle beauty insider updates notification")) {
        if (!obj.getSotVars().getSotV177().equals("null")) {
          testCaseStatus = true;
        }
      }
      test.info("Event : " + obj.getSotVars().toString());
      logger.info(obj.getSotVars().toString());
      if(!testCaseStatus){
        test.fail("Event Not Found");
      }
    }
    // write all backend data
    File harFile = new File("events/ToggleBeautyInsiderUpdatesNotificationIOS.har");
    har.writeTo(harFile);

  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void test01() throws IOException, CsvException, InterruptedException {
    proxy = getBMPObj();

    proxy.newHar("test01");
    test = extentLogger.startTest("Verify that user is able to Toggle Beauty insider update notification and required events are triggered for the same");
    Thread.sleep(5000);

    onBoardingActivity = new OnBoardActivityIOS(getDriver());
    bottomMenu = new BottomMenuIOS(getDriver());
    profileActivityIOS = new ProfileActivityIOS(getDriver());
    notificationsSettingsPageIOS = new NotificationsSettingsPageIOS(getDriver());

    signInIOS = new SignInIOS(getDriver());
    appSettingsPageIOS = new AppSettingsPageIOS(getDriver());
    personalizeExperienceIOS = new PersonalizeExperienceIOS(getDriver());

    //Enter Username and Password and click on Sign in Link
    signInIOS.login(0);
    test.info("User Enter Username and Password Then click on Sign in Link", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "ApplyPromoCode")).build());
    logger.info("User Enter Username and Password Then click on Sign in Link");

    personalizeExperienceIOS.waitForButtonToAppear(90);
    personalizeExperienceIOS.clickOnContinueButton();

    // click on me icon in bottom navigation
    bottomMenu.clickOnMeIcon();
    test.info("User clicks on Me icon", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "ToggleBeautyInsiderUpdatesNotificationIOS")).build());
    logger.info("User clicks on Me icon");

    //Click on AppSettings Tab in profile page
    profileActivityIOS.scrollToAppSettings();
    profileActivityIOS.clickOnAppSettingsLink();
    test.info("User clicks AppSettings tab",MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "ToggleBeautyInsiderUpdatesNotificationIOS")).build());
    logger.info("Verify whether the appSettings page opened");

    //Click on NotificationsSettings Tab in profile page
    appSettingsPageIOS.clickOnNotificationsSettingsTab();
    test.info("User clicks NotificationSettings Tab",MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "ToggleBeautyInsiderUpdatesNotificationIOS")).build());
    logger.info("Verify whether the Notifications page opened");


    //Click on App Only Rewards switch in notifications settings page
    notificationsSettingsPageIOS.clickOnbeautyInsiderToggleSwitch();
    test.info("User clicks on Beauty insider update Toggle Switch",MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "ToggleBeautyInsiderUpdatesNotificationIOS")).build());
    logger.info("Verify whether the state of toggle switch is changed");

  }

}
