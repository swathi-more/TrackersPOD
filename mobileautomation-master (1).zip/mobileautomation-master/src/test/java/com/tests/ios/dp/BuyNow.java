package com.tests.ios.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.ios.BasketActivity;
import com.automate.pages.ios.CheckoutPage;
import com.automate.pages.ios.HomeActivityIOS;
import com.automate.pages.ios.LoveActivity;
import com.automate.pages.ios.OnBoardActivityIOS;
import com.automate.pages.ios.PersonalizeExperienceIOS;
import com.automate.pages.ios.ProductActivity;
import com.automate.pages.ios.ProductsPageIOS;
import com.automate.pages.ios.SignInIOS;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import io.appium.java_client.ios.IOSDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class BuyNow extends BaseTest {
	private ExtentReportLogger extentLogger = new ExtentReportLogger();
	private BrowserMobProxyServer proxy;
  private CheckoutPage checkoutPage;
	private OnBoardActivityIOS onBoardingActivity;
	private SignInIOS signInIOS;
	private PersonalizeExperienceIOS personalizeExperienceIOS;
	private HomeActivityIOS homeActivityIOS;
	private ProductsPageIOS productsPageIOS;
	private LoveActivity objLoveActivity;
	private ProductActivity objProductActivity;
	private BasketActivity objBasketActivity;
	private ExtentTest test;
	private int i;

	private IOSDriver iosDriver;

	@AfterMethod
	public void tearDown() throws IOException, InterruptedException {

		Har har = proxy.getHar();

		HarAnalyzer harAnalyzer = new HarAnalyzer();
		List<Event> eventList = harAnalyzer.getRequestFromHar(har);
		boolean status = false;
		Iterator itr = eventList.iterator();

		while (itr.hasNext()) {
			Event obj = (Event) itr.next();

			if (obj.getSotVars().getSotSubType() != null
					&& obj.getSotVars().getSotSubType().equalsIgnoreCase("checkout")) {
				if (obj.getSotVars().getSotV01() != null
						&& obj.getSotVars().getSotV01().equalsIgnoreCase("place order")) {
					if (obj.getSotVars().getSotV106() != null
							&& obj.getSotVars().getSotV106().equalsIgnoreCase("checkout:payment:n/a:*")) {
						status = true;
					}
				}
			}
      test.info("Event : "+obj.getSotVars().toString());
		}

		if (!status) {
			test.fail("Event not found checkout");
		}
		File harFile = new File("buyNow.har");
		har.writeTo(harFile);

	}

	@FrameworkAnnotation(author = "User-1", category = { CategoryType.REGRESSION })
	@Test
	public void test01() throws IOException, CsvException, InterruptedException {
		proxy = getBMPObj();

		proxy.newHar("test01");
		test = extentLogger.startTest("BuyNow");
		Thread.sleep(5000);
		i = 0;
		signInIOS = new SignInIOS(getDriver());
		personalizeExperienceIOS = new PersonalizeExperienceIOS(getDriver());
		homeActivityIOS = new HomeActivityIOS(getDriver());
		productsPageIOS = new ProductsPageIOS(getDriver());
		onBoardingActivity = new OnBoardActivityIOS(getDriver());
		objLoveActivity = new LoveActivity(getDriver());
		objProductActivity = new ProductActivity(getDriver());
		objBasketActivity = new BasketActivity(getDriver());
    checkoutPage = new CheckoutPage(getDriver());

		signInIOS.login(i);
		test.info("Login To Application", MediaEntityBuilder
				.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BuyNow")).build());

		personalizeExperienceIOS.waitForButtonToAppear(90);
		personalizeExperienceIOS.clickOnContinueButton();

		homeActivityIOS.searchProduct("Eye Liner");
		test.info("Search for product", MediaEntityBuilder
				.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BuyNow")).build());

		productsPageIOS.clickOnFirstProduct();
		test.info("Click on first product", MediaEntityBuilder
				.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BuyNow")).build());

		objBasketActivity.AddtoBasket();
		test.info("Add to Basket", MediaEntityBuilder
				.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BuyNow")).build());
		objBasketActivity.BasketIcon();
		test.info("Basket Icon", MediaEntityBuilder
				.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BuyNow")).build());
		objBasketActivity.CheckOut();
		test.info("Check Out", MediaEntityBuilder
				.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BuyNow")).build());

		/*
		 * objBasketActivity.clickOnSameDayUnlimitedCheckbox();
		 * test.info("click radio button same day unlimited",
		 * MediaEntityBuilder.createScreenCaptureFromPath
		 * (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BuyNow")).build());
		 */

    objBasketActivity.clickOnAddCreditOrDebitCard();
    checkoutPage.enterCreditOrDebitCardInfo(i);

    objBasketActivity.placedOrderClick(i);
    test.info("ClickPlacedOrder", MediaEntityBuilder
      .createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BuyNow")).build());

  }

}
