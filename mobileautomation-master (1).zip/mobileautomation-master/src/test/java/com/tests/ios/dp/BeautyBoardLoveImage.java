package com.tests.ios.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.ios.BottomMenuIOS;
import com.automate.pages.ios.CommunityActivity;
import com.automate.pages.ios.GalleryActivityIOSPage;
import com.automate.pages.ios.OnBoardActivityIOS;
import com.automate.pages.ios.PersonalizeExperienceIOS;
import com.automate.pages.ios.SignInIOS;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import com.tests.android.dp.BeautyBoardloveImage;
import io.appium.java_client.ios.IOSDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class BeautyBoardLoveImage extends BaseTest {
  private static final Logger logger = LogManager.getLogger(BeautyBoardloveImage.class);
	private ExtentReportLogger extentLogger = new ExtentReportLogger();
	private BrowserMobProxyServer proxy;
	private OnBoardActivityIOS onBoardingActivity;
	private BottomMenuIOS objBottomMenu;
  private SignInIOS signInIOS;
  private PersonalizeExperienceIOS personalizeExperienceIOS;
  private GalleryActivityIOSPage galleryActivity;
	private CommunityActivity objCommunityActivity;
  private ExtentTest test;
	private int i;
	private IOSDriver iosDriver;
	@AfterMethod
	public void tearDown() throws IOException, InterruptedException {
    Har har =  proxy.getHar();
    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);
    Iterator itr = eventList.iterator();
    boolean testCasesStatus=false;

    // iterating over Events captured
    while (itr.hasNext()) {
      Event obj = (Event) itr.next();
      if(obj.getSotVars().getSotType().equals("community gallery tab click")) {
        if (!obj.getSotVars().getSotV18().equals("null")) {
          testCasesStatus = true;
        }
      }
      test.info("Event : " + obj.getSotVars().toString());
      logger.info(obj.getSotVars().toString());
    }
    if(!testCasesStatus)
      test.fail("Event not found");
  }
	@FrameworkAnnotation(author = "User-1", category = { CategoryType.REGRESSION })
	@Test
	public void test01() throws IOException, CsvException, InterruptedException {
		proxy = getBMPObj();

		proxy.newHar("test01");
		 test = extentLogger.startTest("BeautyBoard");
		Thread.sleep(5000);
		i = 0;
		onBoardingActivity = new OnBoardActivityIOS(getDriver());
		objBottomMenu = new BottomMenuIOS(getDriver());
		objCommunityActivity = new CommunityActivity(getDriver());
    signInIOS = new SignInIOS(getDriver());
    personalizeExperienceIOS = new PersonalizeExperienceIOS(getDriver());
    galleryActivity   = new GalleryActivityIOSPage(getDriver());

    //Enter Username and Password and click on SignIn Link
    signInIOS.loginIOS(2);
    test.info("User Enter Username and Password Then click on Sign in Link", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "CommunityGalleryTabClick")).build());
    logger.info("User Enter Username and Password Then click on Sign in Link");

    personalizeExperienceIOS.waitForButtonToAppear(70);
    personalizeExperienceIOS.clickOnContinueButton();

    objBottomMenu.clickOnCommunityNavIcon();
		test.info("clickOnCommunityNavIcon", MediaEntityBuilder
				.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BeautyBoard"))
				.build());

		objCommunityActivity.GallaryBar();
		test.info("Click GalleryBar", MediaEntityBuilder
				.createScreenCaptureFromPath(ScreenshotUtils.captureScreenshotAsFile(getDriver(), "BeautyBoard"))
				.build());

    //Click on I mage
    galleryActivity.clickOnImage();
    test.info("User Click on I mage", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "GalleryImageClick")).build());
    logger.info("User Click on I mage");

	}

}
