package com.tests.ios.dp;

import com.automate.customannotations.FrameworkAnnotation;
import com.automate.enums.CategoryType;
import com.automate.eventspojo.Event;
import com.automate.pages.ios.BottomMenuIOS;
import com.automate.pages.ios.CreateDummyStoreIOS;
import com.automate.pages.ios.OnBoardActivityIOS;
import com.automate.pages.ios.PersonalizeExperienceIOS;
import com.automate.pages.ios.SignUp;
import com.automate.pages.ios.StoreActivity;
import com.automate.pages.ios.StoresActivityIOS;
import com.automate.reports.tg.ExtentReportLogger;
import com.automate.utils.HarAnalyzer;
import com.automate.utils.screenshot.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.opencsv.exceptions.CsvException;
import com.tests.BaseTest;
import com.tests.android.dp.BeautyBoardloveImage;
import com.tests.ios.store.StoreSetupIOS;
import io.appium.java_client.ios.IOSDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class Quiz extends BaseTest {

 private static final Logger logger = LogManager.getLogger(Quiz.class);

  private ExtentReportLogger extentLogger= new ExtentReportLogger();
  private BrowserMobProxyServer proxy;
  private SignUp signUp;
  private OnBoardActivityIOS onBoardingActivity;
  private BottomMenuIOS objBottomMenu;
  private StoreActivity objStoreActivity;
  private StoresActivityIOS storesActivityIOS;
  private PersonalizeExperienceIOS personalizeExperienceIOS;
  private ExtentTest test;
  private int i;

  private IOSDriver iosDriver;
  @AfterMethod
  public void tearDown() throws IOException, InterruptedException {

    Har har =  proxy.getHar();
    HarAnalyzer harAnalyzer = new HarAnalyzer();
    List<Event> eventList = harAnalyzer.getRequestFromHar(har);

    Iterator itr = eventList.iterator();

    boolean testCasesStatus=false;

    try {
      // iterating over Events captured
      while (itr.hasNext()) {
        Event obj = (Event) itr.next();
        if (obj.getSotVars().getSotType().equals("productfinder start quiz")) {
          testCasesStatus = true;
        }
        test.info("Event : " + obj.getSotVars().toString());

      }
      if (!testCasesStatus)
        test.fail("Event not found");


      // write all backend data
      File harFile = new File("events/Quiz.har");
      har.writeTo(harFile);
    }
    catch (Exception e){
      e.printStackTrace();

    }
  }

  @FrameworkAnnotation(author = "User-1", category = {CategoryType.REGRESSION})
  @Test
  public void test01() throws IOException, CsvException, InterruptedException {
    proxy = getBMPObj();

    proxy.newHar("Quiz");
    test = extentLogger.startTest("Quiz");
    Thread.sleep(5000);
    i=0;
    onBoardingActivity = new OnBoardActivityIOS(getDriver());
    objBottomMenu=new BottomMenuIOS(getDriver());
    objStoreActivity=new StoreActivity(getDriver());
    StoreSetupIOS storeSetup = new StoreSetupIOS(getDriver());
    storesActivityIOS = new StoresActivityIOS(getDriver());
    personalizeExperienceIOS = new PersonalizeExperienceIOS(getDriver());
    signUp = new SignUp(getDriver());

    //Enter Username and Password and click on SignIn Link
    signUp.login(i);
    test.info("User Enter Username and Password Then click on Sign in Link", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "CommunityGalleryTabClick")).build());
    logger.info("User Enter Username and Password Then click on Sign in Link");

    storeSetup.createStore();
    test.info("User Perform store setup", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Quiz")).build());
    logger.info("User Perform store setup");
    objBottomMenu.clickOnCommunityNavIcon();

    objBottomMenu.clickOnStoresNavIcon();

    objBottomMenu.clickOnStoresNavIcon();
    test.info("click On StoresNavIcon", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Quiz")).build());

    storesActivityIOS.clickOnStoreModeLink();
    test.info("User click on store mode", MediaEntityBuilder.createScreenCaptureFromPath(
      ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Quiz")).build());
    logger.info("User click on store mode");

    // accepting allow notification pop-up
    if(storesActivityIOS.checkAllowNotification())
    {
      storesActivityIOS.clickOnAllowNotifications();

    }

   objStoreActivity.ClickQuizzes();
    test.info("Click Quizzes", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Quiz")).build());

   objStoreActivity.FragranceQuizz();
    test.info("Fragrance Quiz", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Quiz")).build());

   objStoreActivity.GetStartedQuizz();
    test.info("Get Started Quiz", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Quiz")).build());

   objStoreActivity.ClickonAns();
    test.info("Click on Ans", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Quiz")).build());

   objStoreActivity.VerifyResult();
    test.info("Verify Result", MediaEntityBuilder.createScreenCaptureFromPath
      (ScreenshotUtils.captureScreenshotAsFile(getDriver(), "Quiz")).build());



  }

}
