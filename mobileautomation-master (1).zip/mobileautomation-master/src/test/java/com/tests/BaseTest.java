package com.tests;

import com.automate.driver.manager.MITMProxyManager;
import com.automate.utils.EventsStoreHandler;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.automate.driver.factory.DriverFactory;
import com.automate.driver.manager.BrowserMobProxyManager;
import com.automate.driver.manager.DriverManager;
import com.automate.driver.manager.ProxyManager;
import com.automate.enums.MobilePlatformName;
import com.automate.reports.tg.ExtentReportManager;
import com.automate.utils.AppiumServerManager;
import com.automate.utils.screenrecording.ScreenRecordingService;

public class BaseTest extends DriverManager {

	public BaseTest() {
		super();
	}
	
	
	@BeforeSuite
	public void beforeSuite()
	{
    EventsStoreHandler.generateEventStore();
    ExtentReportManager.setupExtentReport();
	}

	@Parameters({ "platformName","platformVersion", "udid", "deviceName", "systemPort", "chromeDriverPort", "emulator", "wdaLocalPort",
			"webkitDebugProxyPort","fullReset"})
	@BeforeMethod(alwaysRun = true)
	 public void setUp(String platformName,String platformVersion, String udid, String deviceName,
			@Optional("androidOnly") String systemPort, @Optional("androidOnly") String chromeDriverPort,
			@Optional("androidOnly") String emulator, @Optional("iOSOnly") String wdaLocalPort,
			@Optional("iOSOnly") String webkitDebugProxyPort, @Optional Boolean fullReset) throws InterruptedException {

		
		try {
			int freePort = AppiumServerManager.getFreePort();
			setPort(freePort);
			
			if(!platformName.contains("browser_stack"))
			{
				new AppiumServerManager().startAppiumServer(freePort);;
			} 
			
			if(platformName.contains("proxy"))
			{
				setBMPObj(BrowserMobProxyManager.getBMP());
				setProxy(ProxyManager.getProxy(getBMPObj()));

        //setThreadLocalMITMProxy(MITMProxyManager.enableMITMProxy());
			}	
			
			setAppiumDriver( DriverFactory.initializeDriver(MobilePlatformName.valueOf(platformName.toUpperCase()),platformVersion, deviceName, udid,
					Integer.parseInt(chromeDriverPort), emulator,freePort,getProxy()));

			ScreenRecordingService.startRecording(getDriver());
		}catch(Exception e) 
		{
			e.printStackTrace();
		}
		
	}

	@AfterMethod(alwaysRun = true)
	protected void tearDown(ITestResult result) {
		ScreenRecordingService.stopRecording(getDriver(), result.getName());
		getDriver().quit();
		
	}

	@AfterSuite(alwaysRun = true)
	public void suiteTearDown()
	{
      getBMPObj().stop();
    System.out.println("#################### After Suite called  ########################");
    ExtentReportManager.writeExtentReport();
	}

}
